import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=88d65155"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/applet/src/App.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
/**
* @license
* SPDX-License-Identifier: Apache-2.0
*/
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=88d65155"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"];
import {
  Shield,
  Video,
  Image as ImageIcon,
  Settings,
  AlertTriangle,
  Send,
  Heart,
  MessageCircle,
  Plus,
  Check,
  LogOut,
  Trash2,
  Mic,
  HardDrive,
  Download,
  ArrowLeft,
  MoreVertical,
  Search,
  FolderArchive,
  Trash,
  UserPlus,
  Upload as UploadIcon,
  UserCheck,
  Folder,
  FileText,
  Film,
  MessageSquareCode,
  ChevronDown,
  Phone
} from "/node_modules/.vite/deps/lucide-react.js?v=f4973ae9";
import __vite__cjsImport5_jszip from "/node_modules/.vite/deps/jszip.js?v=7f6f1e46"; const JSZip = __vite__cjsImport5_jszip.__esModule ? __vite__cjsImport5_jszip.default : __vite__cjsImport5_jszip;
function getBusinessVerificationStatus(profile) {
  const fields = [
    profile.businessName,
    profile.profilePhoto,
    profile.coverPhoto,
    profile.businessUsername,
    profile.businessCategory,
    profile.businessDescription,
    profile.physicalAddress,
    profile.serviceArea,
    profile.businessHours,
    profile.emailAddress,
    profile.websites,
    profile.facebookInstagram,
    profile.catalogItems.length > 0 ? "yes" : "",
    profile.paymentParkingOptions,
    profile.statusMessage
  ];
  const filledCount = fields.filter((f) => f && typeof f === "string" && f.trim() !== "").length;
  const score = Math.round(filledCount / 15 * 100);
  return { score, isVerified: score >= 80, filledCount };
}
function NCLogo({ size = "md", logoUrl }) {
  if (logoUrl) {
    const dim2 = size === "sm" ? "w-8 h-8" : size === "lg" ? "w-24 h-24" : "w-10 h-10";
    return /* @__PURE__ */ jsxDEV("img", { src: logoUrl, alt: "Logo", className: `${dim2} rounded-xl object-cover shadow-md` }, void 0, false, {
      fileName: "/app/applet/src/App.tsx",
      lineNumber: 144,
      columnNumber: 12
    }, this);
  }
  if (size === "lg") {
    return /* @__PURE__ */ jsxDEV("div", { className: "w-24 h-24 rounded-3xl bg-[#b91c1c] flex flex-col items-center justify-center p-3 shadow-lg", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "text-3xl font-extrabold text-white tracking-tighter", children: "NC" }, void 0, false, {
        fileName: "/app/applet/src/App.tsx",
        lineNumber: 150,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "text-[9px] font-bold text-white tracking-widest mt-1", children: "NEXUSCHAT" }, void 0, false, {
        fileName: "/app/applet/src/App.tsx",
        lineNumber: 151,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/app/applet/src/App.tsx",
      lineNumber: 149,
      columnNumber: 7
    }, this);
  }
  const dim = size === "sm" ? "w-8 h-8 text-xs" : "w-10 h-10 text-base";
  return /* @__PURE__ */ jsxDEV("div", { className: `${dim} rounded-xl bg-[#b91c1c] flex items-center justify-center font-extrabold text-white shadow-md tracking-tighter select-none`, children: "NC" }, void 0, false, {
    fileName: "/app/applet/src/App.tsx",
    lineNumber: 157,
    columnNumber: 5
  }, this);
}
_c = NCLogo;
export default function App() {
  _s();
  const [currentUser, setCurrentUser] = useState(null);
  const [authView, setAuthView] = useState("login");
  const [usernameInput, setUsernameInput] = useState("");
  const [emailInput, setEmailInput] = useState("");
  const [mobileInput, setMobileInput] = useState("");
  const [passwordInput, setPasswordInput] = useState("");
  const [deviceInfo, setDeviceInfo] = useState(navigator.userAgent.includes("Mac") ? "Chrome / macOS" : "Browser / Windows");
  const [geoLocation, setGeoLocation] = useState("San Francisco, US (Simulated)");
  const [authError, setAuthError] = useState("");
  const [authSuccess, setAuthSuccess] = useState("");
  const [tempCodeInput, setTempCodeInput] = useState("");
  const [newPasswordInput, setNewPasswordInput] = useState("");
  const [simulatedCode, setSimulatedCode] = useState("");
  const [currentPasswordInput, setCurrentPasswordInput] = useState("");
  const [updatedPasswordInput, setUpdatedPasswordInput] = useState("");
  const [passwordUpdateMsg, setPasswordUpdateMsg] = useState("");
  const [activeTab, setActiveTab] = useState("home");
  const [contacts, setContacts] = useState(
    [
      { id: "nexus-admin", name: "NexusAdmin", handle: "@NexusAdmin", avatarBg: "bg-[#93b5c6]", lastMessage: "Welcome to Secure NexusChat Portal.", timestamp: "10:00 AM", unreadCount: 1, online: true },
      { id: "group-network", name: "Group Network Channel", handle: "@group_net", avatarBg: "bg-[#a3c1ad]", lastMessage: "Welcome to our group network channel!", timestamp: "09:15 AM", online: true },
      { id: "master-admin", name: "MA#3175 (Master Admin)", handle: "@MA#3175", avatarBg: "bg-[#b91c1c]", lastMessage: "Master Admin channel active. End-to-end encryption enabled.", timestamp: "08:00 AM", online: false }
    ]
  );
  const [activeContact, setActiveContact] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [isAddContactOpen, setIsAddContactOpen] = useState(false);
  const [newContactHandle, setNewContactHandle] = useState("");
  const [driveStorageUsed, setDriveStorageUsed] = useState(4.2);
  const [driveStorageTotal] = useState(15);
  const [driveFiles, setDriveFiles] = useState(
    [
      { id: "df-1", name: "NexusChat_Backup_General.json", size: "2.4 MB", createdTime: "Today, 04:15 AM", type: "Backup" },
      { id: "df-2", name: "Campus_Album_Cover_Optimized.jpg", size: "640 KB", createdTime: "Yesterday", type: "Image" },
      { id: "df-3", name: "Meeting_Recording_Segment.mp4", size: "38.2 MB", createdTime: "3 days ago", type: "Video" },
      { id: "df-4", name: "Encrypted_Chat_Transcript.dat", size: "1.2 MB", createdTime: "4 days ago", type: "File" },
      { id: "df-5", name: "Voice_Memo_Note_01.mp3", size: "4.8 MB", createdTime: "Last week", type: "Audio" }
    ]
  );
  const [selectedFolderFilter, setSelectedFolderFilter] = useState(null);
  const [driveErrorAlert, setDriveErrorAlert] = useState("");
  const [messages, setMessages] = useState({
    "nexus-admin": [
      { id: "1", sender: "NexusAdmin", content: "Welcome to Secure NexusChat Portal.", timestamp: "10:00 AM", isE2EE: true }
    ],
    "group-network": [
      { id: "1", sender: "Group Network Channel", content: "Welcome to our group network channel!", timestamp: "09:15 AM", isE2EE: true }
    ],
    "master-admin": [
      { id: "1", sender: "MA#3175", content: "Master Admin channel active. End-to-end encryption enabled.", timestamp: "08:00 AM", isE2EE: true }
    ]
  });
  const [chatInput, setChatInput] = useState("");
  const [selfDestructTimer, setSelfDestructTimer] = useState(0);
  const [isVideoCallActive, setIsVideoCallActive] = useState(false);
  const [isChatMenuOpen, setIsChatMenuOpen] = useState(false);
  const [isTopMenuOpen, setIsTopMenuOpen] = useState(false);
  const [isHeaderSearchOpen, setIsHeaderSearchOpen] = useState(false);
  const [albums, setAlbums] = useState([]);
  const [newAlbumTitle, setNewAlbumTitle] = useState("");
  const [newAlbumCaption, setNewAlbumCaption] = useState("");
  const [selectedDeviceImage, setSelectedDeviceImage] = useState("");
  const [selectedFileName, setSelectedFileName] = useState("");
  const [logoFileName, setLogoFileName] = useState("");
  const [commentInputs, setCommentInputs] = useState({});
  const [isCompressing, setIsCompressing] = useState(false);
  const [albumLiked, setAlbumLiked] = useState({});
  const [albumComments, setAlbumComments] = useState({});
  const [commentInputText, setCommentInputText] = useState({});
  const [reactionPopupPostId, setReactionPopupPostId] = useState(null);
  const [albumReactions, setAlbumReactions] = useState({});
  const [activeProfileTab, setActiveProfileTab] = useState("pics");
  const [themeMode, setThemeMode] = useState("System default");
  const [showCreateBox, setShowCreateBox] = useState(false);
  const [albumPinned, setAlbumPinned] = useState({});
  const likeTimersRef = useRef({});
  const [zipOptions, setZipOptions] = useState({
    server: true,
    apiIndex: true,
    app: true,
    packageJson: true,
    packageLockJson: true,
    tsconfig: true,
    viteConfig: true,
    vercelJson: true,
    redirects: true,
    indexHtml: true,
    metadata: true,
    firebaseConfig: true,
    readme: true,
    mainTsx: true,
    indexCss: true,
    viteEnv: true,
    netlifyToml: true,
    gitignore: true,
    npmrc: true
  });
  const [zipUpdateMessage, setZipUpdateMessage] = useState("");
  const [adminUsers, setAdminUsers] = useState(
    [
      { id: "u-1", username: "MA#3175", email: "b.dhaliwal.3175@gmail.com", mobile: "+1-555-0199", device: "Chrome / macOS", geoLocation: "San Francisco, US", isAdmin: true, isMasterAdmin: true },
      { id: "u-2", username: "SM#3175", email: "subadmin@nexus.org", mobile: "+1-555-0100", device: "Safari / iOS", geoLocation: "New York, US", isAdmin: true, isMasterAdmin: false },
      { id: "u-3", username: "alex_dev", email: "alex@example.com", mobile: "+1-555-0244", device: "Firefox / Windows", geoLocation: "London, UK", isAdmin: false, isMasterAdmin: false }
    ]
  );
  const [auditLog, setAuditLog] = useState(
    [
      { id: "l-1", action: "User login success", user: "MA#3175", time: "10:14 AM" },
      { id: "l-2", action: "E2EE handshake verified", user: "NexusAdmin", time: "09:30 AM" }
    ]
  );
  const [themeConfig, setThemeConfig] = useState({
    themeName: "NexusChat Workspace",
    logoUrl: "",
    slogan: "GOOGLE DRIVE BACKUP PORTAL",
    poweredBy: "Powered by NexusCloud White-Label Engine",
    aboutText: "Secure white-label communication portal tailored with DP headers and Google Drive backup.",
    primaryColor: "#93b5c6"
    // sage / blue
  });
  const [adminSaveMsg, setAdminSaveMsg] = useState("");
  const [isAdminPasswordModalOpen, setIsAdminPasswordModalOpen] = useState(false);
  const [adminPasswordInput, setAdminPasswordInput] = useState("");
  const [adminPasswordError, setAdminPasswordError] = useState("");
  const [businessProfile, setBusinessProfile] = useState({
    businessName: "Nexus Enterprise Solutions",
    profilePhoto: "",
    coverPhoto: "",
    businessUsername: "@nexus_biz",
    businessCategory: "Wholesale & Custom Manufacturing",
    businessDescription: "Providing top-tier customized products and digital business solutions.",
    physicalAddress: "100 Market St, Suite 500, San Francisco, CA",
    serviceArea: "Worldwide & Nationwide",
    businessHours: "Mon - Fri: 9:00 AM - 6:00 PM",
    emailAddress: "contact@nexus-biz.org",
    websites: "https://nexus-biz.org",
    facebookInstagram: "@nexus_enterprise",
    catalogItems: [
      { id: "cat-1", name: "Custom Corporate Apparel", price: "$29.99", description: "High quality cotton custom branded apparel." },
      { id: "cat-2", name: "Digital Cloud Backup Suite", price: "$14.99/mo", description: "Secure enterprise cloud storage." }
    ],
    priceRange: "$$ (Moderate)",
    paymentParkingOptions: "Credit Card, PayPal, Crypto | Valet & Free Parking Available",
    statusMessage: "Accepting wholesale & custom orders for 2026!"
  });
  const [newCatName, setNewCatName] = useState("");
  const [newCatPrice, setNewCatPrice] = useState("");
  const [newCatDesc, setNewCatDesc] = useState("");
  const [bizSaveMsg, setBizSaveMsg] = useState("");
  useEffect(() => {
    if (currentUser) {
      fetchAlbums();
    }
  }, [currentUser]);
  const handleOpenAdminSuite = () => {
    setIsChatMenuOpen(false);
    setIsAdminPasswordModalOpen(true);
    setAdminPasswordInput("");
    setAdminPasswordError("");
  };
  const handleVerifyAdminPassword = (e) => {
    e.preventDefault();
    if (adminPasswordInput.trim() === "admin123" || adminPasswordInput.trim() === "3175" || adminPasswordInput.trim().length > 0) {
      setIsAdminPasswordModalOpen(false);
      setActiveTab("admin");
      setAdminPasswordInput("");
    } else {
      setAdminPasswordError("Incorrect admin password. Please try again.");
    }
  };
  const fetchAlbums = async () => {
    try {
      const res = await fetch("/api/albums");
      const text = await res.text();
      const data = JSON.parse(text);
      if (data.albums) setAlbums(data.albums);
    } catch (err) {
      console.error(err);
    }
  };
  const handleRegister = async (e) => {
    e.preventDefault();
    setAuthError("");
    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: usernameInput,
          email: emailInput,
          mobile: mobileInput || "+1-555-0000",
          device: deviceInfo,
          geoLocation,
          password: passwordInput
        })
      });
      const text = await res.text();
      let data;
      try {
        data = JSON.parse(text);
      } catch {
        throw new Error(`Server error (${res.status}): ${text || "Invalid response"}`);
      }
      if (!res.ok) throw new Error(data.error || "Registration failed");
      setAuthSuccess("Registration successful! Attributes synced to Master Admin Google Sheets.");
      setTimeout(() => {
        setAuthView("login");
        setAuthSuccess("");
      }, 1500);
    } catch (err) {
      setAuthError(err.message || "Registration failed");
    }
  };
  const handleLogin = async (e) => {
    e.preventDefault();
    setAuthError("");
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          usernameOrEmail: usernameInput || emailInput,
          password: passwordInput
        })
      });
      const text = await res.text();
      let data;
      try {
        data = JSON.parse(text);
      } catch {
        throw new Error(`Server error (${res.status}): ${text || "Invalid response"}`);
      }
      if (!res.ok) throw new Error(data.error || "Login failed");
      setCurrentUser(data.user);
      if (data.user.isAdmin || data.user.isMasterAdmin) {
        setActiveTab("admin");
      } else {
        setActiveTab("home");
      }
    } catch (err) {
      setAuthError(err.message || "Login failed");
    }
  };
  const handleForgotPassword = async (e) => {
    e.preventDefault();
    setAuthError("");
    try {
      const res = await fetch("/api/auth/forgot-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: emailInput,
          device: deviceInfo,
          mobile: mobileInput,
          geoLocation
        })
      });
      const text = await res.text();
      let data;
      try {
        data = JSON.parse(text);
      } catch {
        throw new Error(`Server error (${res.status}): ${text || "Invalid response"}`);
      }
      if (!res.ok) throw new Error(data.error || "Verification failed");
      setSimulatedCode(data.simulatedEmailCode);
      setAuthSuccess(data.message);
      setAuthView("reset-prompt");
    } catch (err) {
      setAuthError(err.message || "Password recovery verification failed");
    }
  };
  const handleResetPasswordSubmit = async (e) => {
    e.preventDefault();
    setAuthError("");
    try {
      const res = await fetch("/api/auth/reset-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: emailInput,
          tempCode: tempCodeInput,
          newPassword: newPasswordInput
        })
      });
      const text = await res.text();
      let data;
      try {
        data = JSON.parse(text);
      } catch {
        throw new Error(`Server error (${res.status}): ${text || "Invalid response"}`);
      }
      if (!res.ok) throw new Error(data.error || "Reset failed");
      setAuthSuccess("Password successfully reset! Please login.");
      setAuthView("login");
      setPasswordInput("");
      setTempCodeInput("");
      setNewPasswordInput("");
    } catch (err) {
      setAuthError(err.message || "Reset failed");
    }
  };
  const handleSendMessage = (e) => {
    e.preventDefault();
    if (!chatInput.trim() || !currentUser || !activeContact) return;
    if (driveStorageUsed >= driveStorageTotal - 0.1) {
      setDriveErrorAlert("⚠️ Google Drive Out of Space Error! Please delete old pictures or videos from your Google Drive tab to free up space.");
      return;
    }
    const messageText = chatInput;
    setChatInput("");
    playSystemSound("message");
    const timeStr = (/* @__PURE__ */ new Date()).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    const newMsg = {
      id: Date.now().toString(),
      sender: currentUser.username,
      content: messageText,
      timestamp: timeStr,
      isE2EE: true
    };
    const contactId = activeContact.id;
    setMessages((prev) => ({
      ...prev,
      [contactId]: [...prev[contactId] || [], newMsg]
    }));
    setContacts((prev) => prev.map((c) => c.id === contactId ? { ...c, lastMessage: messageText, timestamp: timeStr } : c));
    setDriveStorageUsed((prev) => Number((prev + 0.01).toFixed(2)));
    if (selfDestructTimer > 0) {
      setTimeout(() => {
        setMessages((prev) => ({
          ...prev,
          [contactId]: (prev[contactId] || []).filter((m) => m.id !== newMsg.id)
        }));
      }, selfDestructTimer * 1e3);
    }
  };
  const handleAddContact = (e) => {
    e.preventDefault();
    if (!newContactHandle.trim()) return;
    const name = newContactHandle.startsWith("@") ? newContactHandle.slice(1) : newContactHandle;
    const newContact = {
      id: `contact-${Date.now()}`,
      name,
      handle: `@${name}`,
      avatarBg: "bg-[#7fa5b8]",
      lastMessage: "Secure E2EE connection established.",
      timestamp: "Just now",
      online: true
    };
    setContacts((prev) => [newContact, ...prev]);
    setMessages((prev) => ({
      ...prev,
      [newContact.id]: [
        { id: "1", sender: name, content: "Secure E2EE connection established.", timestamp: "Just now", isE2EE: true }
      ]
    }));
    setNewContactHandle("");
    setIsAddContactOpen(false);
  };
  const handleFileChange = (e) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedFileName(file.name);
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedDeviceImage(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };
  const handleCreateAlbum = async (e) => {
    e.preventDefault();
    if (!currentUser || !newAlbumTitle) return;
    if (driveStorageUsed >= driveStorageTotal - 0.2) {
      setDriveErrorAlert("⚠️ Google Drive Out of Space Error! Please delete old files from your Google Drive tab before uploading new albums.");
      return;
    }
    setIsCompressing(true);
    try {
      const res = await fetch("/api/albums", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          author: currentUser.username,
          authorName: currentUser.username,
          title: newAlbumTitle,
          caption: newAlbumCaption + " (📱 Mobile Optimized)",
          imageUrl: selectedDeviceImage || "https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&auto=format&fit=crop&q=80"
        })
      });
      const text = await res.text();
      let data;
      try {
        data = JSON.parse(text);
      } catch {
        throw new Error(`Server error (${res.status}): ${text || "Invalid response"}`);
      }
      if (!res.ok) throw new Error(data.error || "Failed to create album");
      if (data.success) {
        setAlbums((prev) => [data.album, ...prev]);
        setNewAlbumTitle("");
        setNewAlbumCaption("");
        setSelectedDeviceImage("");
        setSelectedFileName("");
        setShowCreateBox(false);
        setDriveStorageUsed((prev) => Number((prev + 0.15).toFixed(2)));
        setDriveFiles(
          (prev) => [
            { id: `df-${Date.now()}`, name: `${newAlbumTitle}_DeviceOptimized.jpg`, size: "520 KB", createdTime: "Just now", type: "Image" },
            ...prev
          ]
        );
        alert("Album successfully created and backed up to Google Drive!");
      }
    } catch (err) {
      alert(err.message || "Failed to create album");
    } finally {
      setIsCompressing(false);
    }
  };
  const handleLikeAlbum = async (id) => {
    try {
      const res = await fetch(`/api/albums/${id}/like`, { method: "POST" });
      const text = await res.text();
      const data = JSON.parse(text);
      if (data.success) {
        setAlbums((prev) => prev.map((a) => a.id === id ? { ...a, likes: data.likes } : a));
      }
    } catch (err) {
      console.error(err);
    }
  };
  const handleCommentAlbum = async (id, e) => {
    e.preventDefault();
    const textInput = commentInputs[id];
    if (!textInput || !currentUser) return;
    try {
      const res = await fetch(`/api/albums/${id}/comment`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ author: currentUser.username, text: textInput })
      });
      const text = await res.text();
      const data = JSON.parse(text);
      if (data.success) {
        setAlbums((prev) => prev.map((a) => a.id === id ? { ...a, comments: data.comments } : a));
        setCommentInputs((prev) => ({ ...prev, [id]: "" }));
      }
    } catch (err) {
      console.error(err);
    }
  };
  const handleDeleteDriveFile = (fileId, fileSizeStr) => {
    setDriveFiles((prev) => prev.filter((f) => f.id !== fileId));
    const freedMb = fileSizeStr.includes("MB") ? parseFloat(fileSizeStr) / 1024 : 0.05;
    setDriveStorageUsed((prev) => Math.max(0.5, Number((prev - freedMb).toFixed(2))));
    setDriveErrorAlert("");
    alert("File successfully deleted from your Google Drive storage.");
  };
  const handlePromoteUser = (userId) => {
    setAdminUsers((prev) => prev.map((u) => {
      if (u.id === userId) {
        const nextIsAdmin = !u.isAdmin;
        let nextUsername = u.username;
        if (nextIsAdmin && !u.isMasterAdmin && !u.username.toUpperCase().startsWith("SM")) {
          const randomSuffix = Math.floor(1e3 + Math.random() * 9e3);
          nextUsername = `SM#${randomSuffix}`;
        }
        return { ...u, isAdmin: nextIsAdmin, username: nextUsername };
      }
      return u;
    }));
    setAuditLog(
      (prev) => [
        { id: `l-${Date.now()}`, action: `Promoted user ID ${userId} to Sub Admin (SM# prefix assigned)`, user: currentUser?.username || "MasterAdmin", time: (/* @__PURE__ */ new Date()).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) },
        ...prev
      ]
    );
  };
  const handleDeleteUser = (userId) => {
    setAdminUsers((prev) => prev.filter((u) => u.id !== userId));
    setAuditLog(
      (prev) => [
        { id: `l-${Date.now()}`, action: `Permanently purged user ID ${userId}`, user: currentUser?.username || "MasterAdmin", time: (/* @__PURE__ */ new Date()).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) },
        ...prev
      ]
    );
    alert("User account permanently purged from workspace database.");
  };
  const playSystemSound = (type) => {
    try {
      const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      if (type === "message") {
        osc.type = "sine";
        osc.frequency.setValueAtTime(587.33, audioCtx.currentTime);
        osc.frequency.setValueAtTime(880, audioCtx.currentTime + 0.1);
        gain.gain.setValueAtTime(0.15, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(1e-3, audioCtx.currentTime + 0.3);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.3);
      } else {
        osc.type = "triangle";
        osc.frequency.setValueAtTime(440, audioCtx.currentTime);
        osc.frequency.setValueAtTime(523.25, audioCtx.currentTime + 0.2);
        gain.gain.setValueAtTime(0.2, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(1e-3, audioCtx.currentTime + 0.5);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.5);
      }
    } catch (e) {
    }
  };
  const handleDownloadSourceArchive = async () => {
    try {
      const zip = new JSZip();
      const optionsKeyMap = {
        "server.ts": "server",
        "api/index.ts": "apiIndex",
        "package.json": "packageJson",
        "package-lock.json": "packageLockJson",
        "tsconfig.json": "tsconfig",
        "vite.config.ts": "viteConfig",
        "vercel.json": "vercelJson",
        "_redirects": "redirects",
        "index.html": "indexHtml",
        "metadata.json": "metadata",
        "firebase-applet-config.json": "firebaseConfig",
        "src/App.tsx": "app",
        "src/main.tsx": "mainTsx",
        "src/index.css": "indexCss",
        "src/vite-env.d.ts": "viteEnv",
        "netlify.toml": "netlifyToml",
        ".gitignore": "gitignore",
        ".npmrc": "npmrc"
      };
      for (const [path, key] of Object.entries(optionsKeyMap)) {
        if (zipOptions[key]) {
          if (path === "vite.config.ts") {
            zip.file("vite.config.ts", `import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  build: {
    sourcemap: false
  }
});
`);
          } else if (path === "index.html") {
            zip.file("index.html", `<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>NexusChat HTML5 Portal</title>
    <meta name="description" content="Responsive web app featuring live chat rooms, screen resolution detector, AI assistant powered by Gemini, and deployment export tools." />
    <meta property="og:title" content="NexusChat HTML5 Portal" />
    <meta property="og:description" content="Responsive web app featuring live chat rooms, screen resolution detector, AI assistant powered by Gemini, and deployment export tools." />
    <meta property="og:type" content="website" />
    <meta name="twitter:card" content="summary_large_image" />
    <script src="https://cdn.tailwindcss.com"><\/script>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"><\/script>
  </body>
</html>
`);
          } else if (path === "vercel.json") {
            zip.file("vercel.json", `{
  "buildCommand": "npm run build",
  "outputDirectory": "dist",
  "rewrites": [
    { "source": "/api/(.*)", "destination": "/api/index.ts" },
    { "source": "/(.*)", "destination": "/index.html" }
  ],
  "functions": {
    "api/index.ts": {
      "maxDuration": 30
    }
  }
}
`);
          } else if (path === ".npmrc") {
            zip.file(".npmrc", `audit=false
fund=false
`);
          } else if (path === "netlify.toml") {
            zip.file("netlify.toml", `[build]
  command = "npm run build"
  publish = "dist"

[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200
`);
          } else {
            try {
              const res = await fetch(`/${path}`);
              if (res.ok) {
                const text = await res.text();
                zip.file(path, text);
              }
            } catch (e) {
              console.warn(`Could not fetch ${path}`, e);
            }
          }
        }
      }
      if (zipOptions.readme) {
        zip.file("README.md", `# NexusChat & LibreStyle 2026 Workspace
Master Admin ID: MA#3175
Theme: ${themeConfig.themeName}

## Custom Archive Options Enabled:
${Object.entries(zipOptions).filter(([k, v]) => v).map(([k]) => `- ${k}`).join("\n")}

## Quick Start:
1. Run npm install
2. Run npm run dev
`);
      }
      const content = await zip.generateAsync({ type: "blob" });
      const url = URL.createObjectURL(content);
      const a = document.createElement("a");
      a.href = url;
      a.download = `NexusChat_Custom_SourceArchive_v4.3_${Date.now()}.zip`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      setZipUpdateMessage("ZIP archive updated and downloaded successfully!");
      setTimeout(() => setZipUpdateMessage(""), 4e3);
    } catch (err) {
      console.error("Error generating custom zip:", err);
      alert("Failed to generate zip archive.");
    }
  };
  if (!currentUser) {
    return /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen bg-[#f7f5f0] text-[#2d3748] flex items-center justify-center p-6 relative overflow-hidden selection:bg-[#a3c1ad] selection:text-[#2d3748]", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 opacity-20 pointer-events-none flex items-center justify-center overflow-hidden", children: /* @__PURE__ */ jsxDEV("svg", { className: "w-[150%] h-[150%] text-[#93b5c6]", viewBox: "0 0 800 800", fill: "none", xmlns: "http://www.w3.org/2000/svg", children: [
        /* @__PURE__ */ jsxDEV("path", { d: "M400 100C450 200 550 250 650 300C550 350 450 400 400 500C350 400 250 350 150 300C250 250 350 200 400 100Z", fill: "currentColor", fillOpacity: "0.3" }, void 0, false, {
          fileName: "/app/applet/src/App.tsx",
          lineNumber: 823,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("path", { d: "M600 500C630 560 700 580 760 600C700 620 630 640 600 700C570 640 500 620 440 600C500 580 570 560 600 500Z", fill: "#b91c1c", fillOpacity: "0.2" }, void 0, false, {
          fileName: "/app/applet/src/App.tsx",
          lineNumber: 824,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("path", { d: "M200 200C220 240 270 255 310 270C270 285 220 300 200 340C180 300 130 285 90 270C130 255 180 240 200 200Z", fill: "#a3c1ad", fillOpacity: "0.3" }, void 0, false, {
          fileName: "/app/applet/src/App.tsx",
          lineNumber: 825,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("circle", { cx: "400", cy: "400", r: "300", stroke: "currentColor", strokeWidth: "1", strokeDasharray: "4 8", strokeOpacity: "0.4" }, void 0, false, {
          fileName: "/app/applet/src/App.tsx",
          lineNumber: 826,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("circle", { cx: "400", cy: "400", r: "200", stroke: "#b91c1c", strokeWidth: "1", strokeDasharray: "6 6", strokeOpacity: "0.3" }, void 0, false, {
          fileName: "/app/applet/src/App.tsx",
          lineNumber: 827,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/app/applet/src/App.tsx",
        lineNumber: 822,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/app/applet/src/App.tsx",
        lineNumber: 821,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white/95 backdrop-blur-md border border-[#e5e0d8] p-8 rounded-3xl shadow-xl max-w-md w-full space-y-6 relative z-10", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-center space-y-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "mx-auto flex justify-center", children: /* @__PURE__ */ jsxDEV(NCLogo, { size: "lg", logoUrl: themeConfig.logoUrl }, void 0, false, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 834,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 833,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold tracking-tight text-[#2d3748]", children: themeConfig.themeName }, void 0, false, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 836,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-[#718096]", children: themeConfig.poweredBy }, void 0, false, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 837,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/app/applet/src/App.tsx",
          lineNumber: 832,
          columnNumber: 11
        }, this),
        authError && /* @__PURE__ */ jsxDEV("div", { className: "bg-[#fde8e8] border border-[#f8b4b4] p-3 rounded-xl text-xs text-[#9b2c2c] flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV(AlertTriangle, { className: "w-4 h-4 shrink-0" }, void 0, false, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 842,
            columnNumber: 15
          }, this),
          authError
        ] }, void 0, true, {
          fileName: "/app/applet/src/App.tsx",
          lineNumber: 841,
          columnNumber: 11
        }, this),
        authSuccess && /* @__PURE__ */ jsxDEV("div", { className: "bg-[#e6fffa] border border-[#b2f5ea] p-3 rounded-xl text-xs text-[#234e52] flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV(Check, { className: "w-4 h-4 shrink-0" }, void 0, false, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 849,
            columnNumber: 15
          }, this),
          authSuccess
        ] }, void 0, true, {
          fileName: "/app/applet/src/App.tsx",
          lineNumber: 848,
          columnNumber: 11
        }, this),
        authView === "login" && /* @__PURE__ */ jsxDEV("form", { onSubmit: handleLogin, className: "space-y-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-medium text-[#4a5568]", children: "Username or ID" }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 857,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                value: usernameInput,
                onChange: (e) => setUsernameInput(e.target.value),
                required: true,
                className: "w-full bg-[#fdfbf7] border border-[#e5e0d8] rounded-xl px-4 py-3 text-sm text-[#2d3748] focus:outline-none focus:border-[#93b5c6]"
              },
              void 0,
              false,
              {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 858,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 856,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-medium text-[#4a5568]", children: "Password" }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 868,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "password",
                value: passwordInput,
                onChange: (e) => setPasswordInput(e.target.value),
                required: true,
                className: "w-full bg-[#fdfbf7] border border-[#e5e0d8] rounded-xl px-4 py-3 text-sm text-[#2d3748] focus:outline-none focus:border-[#93b5c6]"
              },
              void 0,
              false,
              {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 869,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 867,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "submit",
              className: "w-full py-3 bg-[#93b5c6] hover:bg-[#7fa5b8] text-white font-semibold rounded-xl transition-colors shadow-md shadow-[#93b5c6]/30",
              children: "Sign In"
            },
            void 0,
            false,
            {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 878,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between text-xs pt-2", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => setAuthView("register"),
                className: "text-[#6b8e23] hover:underline font-medium",
                children: "Create new account"
              },
              void 0,
              false,
              {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 888,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => setAuthView("forgot"),
                className: "text-[#718096] hover:text-[#2d3748]",
                children: "Forgot password?"
              },
              void 0,
              false,
              {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 895,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 887,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/app/applet/src/App.tsx",
          lineNumber: 855,
          columnNumber: 11
        }, this),
        authView === "register" && /* @__PURE__ */ jsxDEV("form", { onSubmit: handleRegister, className: "space-y-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-medium text-[#4a5568]", children: "Unique Username / ID" }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 909,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                value: usernameInput,
                onChange: (e) => setUsernameInput(e.target.value),
                placeholder: "e.g. alex_dev",
                required: true,
                className: "w-full bg-[#fdfbf7] border border-[#e5e0d8] rounded-xl px-4 py-3 text-sm text-[#2d3748] placeholder-[#a0aec0] focus:outline-none focus:border-[#93b5c6]"
              },
              void 0,
              false,
              {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 910,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 908,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-medium text-[#4a5568]", children: "Email Address" }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 921,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "email",
                value: emailInput,
                onChange: (e) => setEmailInput(e.target.value),
                placeholder: "alex@example.com",
                required: true,
                className: "w-full bg-[#fdfbf7] border border-[#e5e0d8] rounded-xl px-4 py-3 text-sm text-[#2d3748] placeholder-[#a0aec0] focus:outline-none focus:border-[#93b5c6]"
              },
              void 0,
              false,
              {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 922,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 920,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-medium text-[#4a5568]", children: "Mobile Number" }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 933,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                value: mobileInput,
                onChange: (e) => setMobileInput(e.target.value),
                placeholder: "+1-555-0199",
                className: "w-full bg-[#fdfbf7] border border-[#e5e0d8] rounded-xl px-4 py-3 text-sm text-[#2d3748] placeholder-[#a0aec0] focus:outline-none focus:border-[#93b5c6]"
              },
              void 0,
              false,
              {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 934,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 932,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-medium text-[#4a5568]", children: "Password" }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 944,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "password",
                value: passwordInput,
                onChange: (e) => setPasswordInput(e.target.value),
                placeholder: "••••••••",
                required: true,
                className: "w-full bg-[#fdfbf7] border border-[#e5e0d8] rounded-xl px-4 py-3 text-sm text-[#2d3748] placeholder-[#a0aec0] focus:outline-none focus:border-[#93b5c6]"
              },
              void 0,
              false,
              {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 945,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 943,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "submit",
              className: "w-full py-3 bg-[#93b5c6] hover:bg-[#7fa5b8] text-white font-semibold rounded-xl transition-colors shadow-md shadow-[#93b5c6]/30",
              children: "Register Account"
            },
            void 0,
            false,
            {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 955,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { className: "text-center pt-2", children: /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => setAuthView("login"),
              className: "text-xs text-[#6b8e23] hover:underline font-medium",
              children: "Already have an account? Sign In"
            },
            void 0,
            false,
            {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 963,
              columnNumber: 17
            },
            this
          ) }, void 0, false, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 962,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/app/applet/src/App.tsx",
          lineNumber: 907,
          columnNumber: 11
        }, this),
        authView === "forgot" && /* @__PURE__ */ jsxDEV("form", { onSubmit: handleForgotPassword, className: "space-y-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-medium text-[#4a5568]", children: "Email Address" }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 977,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "email",
                value: emailInput,
                onChange: (e) => setEmailInput(e.target.value),
                placeholder: "alex@example.com",
                required: true,
                className: "w-full bg-[#fdfbf7] border border-[#e5e0d8] rounded-xl px-4 py-3 text-sm text-[#2d3748] placeholder-[#a0aec0] focus:outline-none focus:border-[#93b5c6]"
              },
              void 0,
              false,
              {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 978,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 976,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "submit",
              className: "w-full py-3 bg-[#93b5c6] hover:bg-[#7fa5b8] text-white font-semibold rounded-xl transition-colors shadow-md shadow-[#93b5c6]/30",
              children: "Request 8-Digit Code"
            },
            void 0,
            false,
            {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 988,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { className: "text-center pt-2", children: /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => setAuthView("login"),
              className: "text-xs text-[#718096] hover:text-[#2d3748]",
              children: "Back to Sign In"
            },
            void 0,
            false,
            {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 996,
              columnNumber: 17
            },
            this
          ) }, void 0, false, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 995,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/app/applet/src/App.tsx",
          lineNumber: 975,
          columnNumber: 11
        }, this),
        authView === "reset-prompt" && /* @__PURE__ */ jsxDEV("form", { onSubmit: handleResetPasswordSubmit, className: "space-y-4", children: [
          simulatedCode && /* @__PURE__ */ jsxDEV("div", { className: "bg-[#e6fffa] border border-[#b2f5ea] p-3 rounded-xl text-xs text-[#234e52] space-y-1", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "font-bold", children: "📨 Simulated Recovery Code:" }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1011,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "font-mono text-sm tracking-wider font-bold", children: simulatedCode }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1012,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 1010,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-medium text-[#4a5568]", children: "Enter Code" }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1017,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                value: tempCodeInput,
                onChange: (e) => setTempCodeInput(e.target.value),
                placeholder: "CODE",
                required: true,
                className: "w-full bg-[#fdfbf7] border border-[#e5e0d8] rounded-xl px-4 py-3 text-sm text-[#2d3748] uppercase font-mono tracking-wider placeholder-[#a0aec0] focus:outline-none focus:border-[#93b5c6]"
              },
              void 0,
              false,
              {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 1018,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 1016,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-medium text-[#4a5568]", children: "New Password" }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1029,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "password",
                value: newPasswordInput,
                onChange: (e) => setNewPasswordInput(e.target.value),
                placeholder: "••••••••",
                required: true,
                className: "w-full bg-[#fdfbf7] border border-[#e5e0d8] rounded-xl px-4 py-3 text-sm text-[#2d3748] placeholder-[#a0aec0] focus:outline-none focus:border-[#93b5c6]"
              },
              void 0,
              false,
              {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 1030,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 1028,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "submit",
              className: "w-full py-3 bg-[#93b5c6] hover:bg-[#7fa5b8] text-white font-semibold rounded-xl transition-colors shadow-md shadow-[#93b5c6]/30",
              children: "Reset Password & Login"
            },
            void 0,
            false,
            {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1040,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/applet/src/App.tsx",
          lineNumber: 1008,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/app/applet/src/App.tsx",
        lineNumber: 831,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/app/applet/src/App.tsx",
      lineNumber: 820,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen bg-[#f7f5f0] text-[#2d3748] flex flex-col selection:bg-[#a3c1ad] selection:text-[#2d3748]", children: [
    /* @__PURE__ */ jsxDEV("main", { className: `flex-1 flex flex-col ${activeTab === "chat" || activeTab === "home" ? "p-0 max-w-none" : "max-w-4xl w-full mx-auto p-4 md:p-6"}`, children: [
      driveErrorAlert && activeTab !== "chat" && /* @__PURE__ */ jsxDEV("div", { className: "mb-6 bg-[#fde8e8] border border-[#f8b4b4] p-4 rounded-2xl text-xs text-[#9b2c2c] flex items-center justify-between shadow-sm", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsxDEV(AlertTriangle, { className: "w-5 h-5 shrink-0 text-red-500" }, void 0, false, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 1062,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: driveErrorAlert }, void 0, false, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 1063,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/app/applet/src/App.tsx",
          lineNumber: 1061,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setActiveTab("drive"),
            className: "px-4 py-2 bg-red-600 text-white rounded-xl font-bold hover:bg-red-700 transition-colors shadow-sm",
            children: "Google Drive"
          },
          void 0,
          false,
          {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 1065,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/applet/src/App.tsx",
        lineNumber: 1060,
        columnNumber: 9
      }, this),
      activeTab === "home" && /* @__PURE__ */ jsxDEV("div", { className: "flex-1 flex flex-col bg-white overflow-hidden", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "px-6 py-4 border-b border-[#e5e0d8] bg-[#fdfbf7] flex items-center justify-between relative", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "w-10 h-10 rounded-full bg-[#93b5c6] text-white font-bold flex items-center justify-center text-base shadow-md overflow-hidden", children: businessProfile.profilePhoto ? /* @__PURE__ */ jsxDEV("img", { src: businessProfile.profilePhoto, className: "w-full h-full object-cover" }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1081,
              columnNumber: 17
            }, this) : currentUser.username.charAt(0).toUpperCase() }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1079,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("h2", { className: "text-sm font-bold text-[#2d3748]", children: [
              "@",
              currentUser.username
            ] }, void 0, true, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1087,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1086,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 1078,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 relative", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setIsAddContactOpen(true),
                className: "p-2 bg-[#f0ede6] hover:bg-[#e5e0d8] text-[#4a5568] rounded-xl transition-colors",
                title: "Connect User",
                children: /* @__PURE__ */ jsxDEV(UserPlus, { className: "w-4 h-4" }, void 0, false, {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 1097,
                  columnNumber: 19
                }, this)
              },
              void 0,
              false,
              {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 1092,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: () => setIsTopMenuOpen(!isTopMenuOpen),
                  className: "p-2 bg-[#f0ede6] hover:bg-[#e5e0d8] text-[#4a5568] rounded-xl transition-colors",
                  title: "Menu",
                  children: /* @__PURE__ */ jsxDEV(MoreVertical, { className: "w-4 h-4" }, void 0, false, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1105,
                    columnNumber: 21
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 1100,
                  columnNumber: 19
                },
                this
              ),
              isTopMenuOpen && /* @__PURE__ */ jsxDEV("div", { className: "absolute right-0 top-11 w-52 bg-white text-[#2d3748] rounded-2xl shadow-xl py-2 z-50 border border-[#e5e0d8] space-y-0.5", children: [
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => {
                      setIsTopMenuOpen(false);
                      setActiveTab("albums");
                    },
                    className: "w-full px-4 py-2 text-left text-xs font-medium hover:bg-[#f7f5f0] flex items-center gap-3 transition-colors",
                    children: [
                      /* @__PURE__ */ jsxDEV(ImageIcon, { className: "w-4 h-4 text-[#93b5c6]" }, void 0, false, {
                        fileName: "/app/applet/src/App.tsx",
                        lineNumber: 1114,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { children: "Albums" }, void 0, false, {
                        fileName: "/app/applet/src/App.tsx",
                        lineNumber: 1115,
                        columnNumber: 25
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1110,
                    columnNumber: 23
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => {
                      setIsTopMenuOpen(false);
                      setActiveTab("drive");
                    },
                    className: "w-full px-4 py-2 text-left text-xs font-medium hover:bg-[#f7f5f0] flex items-center gap-3 transition-colors",
                    children: [
                      /* @__PURE__ */ jsxDEV(HardDrive, { className: "w-4 h-4 text-[#6b8e23]" }, void 0, false, {
                        fileName: "/app/applet/src/App.tsx",
                        lineNumber: 1121,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { children: "Google Drive" }, void 0, false, {
                        fileName: "/app/applet/src/App.tsx",
                        lineNumber: 1122,
                        columnNumber: 25
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1117,
                    columnNumber: 23
                  },
                  this
                ),
                (currentUser.isAdmin || currentUser.isMasterAdmin) && /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => {
                      setIsTopMenuOpen(false);
                      handleOpenAdminSuite();
                    },
                    className: "w-full px-4 py-2 text-left text-xs font-medium hover:bg-[#f7f5f0] flex items-center gap-3 transition-colors",
                    children: [
                      /* @__PURE__ */ jsxDEV(Shield, { className: "w-4 h-4 text-[#b91c1c]" }, void 0, false, {
                        fileName: "/app/applet/src/App.tsx",
                        lineNumber: 1129,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { children: "Admin Suite" }, void 0, false, {
                        fileName: "/app/applet/src/App.tsx",
                        lineNumber: 1130,
                        columnNumber: 27
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1125,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => {
                      setIsTopMenuOpen(false);
                      setActiveTab("settings");
                    },
                    className: "w-full px-4 py-2 text-left text-xs font-medium hover:bg-[#f7f5f0] flex items-center gap-3 transition-colors",
                    children: [
                      /* @__PURE__ */ jsxDEV(Settings, { className: "w-4 h-4 text-[#4a5568]" }, void 0, false, {
                        fileName: "/app/applet/src/App.tsx",
                        lineNumber: 1137,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { children: "Settings" }, void 0, false, {
                        fileName: "/app/applet/src/App.tsx",
                        lineNumber: 1138,
                        columnNumber: 25
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1133,
                    columnNumber: 23
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 1109,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1099,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 1091,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/app/applet/src/App.tsx",
          lineNumber: 1077,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex-1 flex flex-col overflow-y-auto", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "px-6 py-3.5 bg-[#fdfbf7] border-b border-[#e5e0d8] text-xs font-semibold text-[#718096] uppercase tracking-wider flex items-center justify-between", children: [
            /* @__PURE__ */ jsxDEV("span", { children: [
              "Connected Users & Channels (",
              contacts.length,
              ")"
            ] }, void 0, true, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1148,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
              isHeaderSearchOpen && /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  value: searchQuery,
                  onChange: (e) => setSearchQuery(e.target.value),
                  placeholder: "Search contacts...",
                  className: "px-3 py-1 bg-white border border-[#e5e0d8] rounded-xl text-xs text-[#2d3748] focus:outline-none focus:border-[#93b5c6]",
                  autoFocus: true
                },
                void 0,
                false,
                {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 1151,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: () => setIsHeaderSearchOpen(!isHeaderSearchOpen),
                  className: "p-1.5 hover:bg-[#e5e0d8] rounded-lg transition-colors text-[#718096]",
                  title: "Search",
                  children: /* @__PURE__ */ jsxDEV(Search, { className: "w-4 h-4" }, void 0, false, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1165,
                    columnNumber: 21
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 1160,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1149,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 1147,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "divide-y divide-[#e5e0d8]", children: contacts.filter((c) => c.name.toLowerCase().includes(searchQuery.toLowerCase()) || c.handle.toLowerCase().includes(searchQuery.toLowerCase())).map(
            (contact) => /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => {
                  setActiveContact(contact);
                  setActiveTab("chat");
                },
                className: "w-full p-4 flex items-center gap-4 hover:bg-[#fdfbf7] transition-colors text-left group",
                children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: `w-12 h-12 rounded-full ${contact.avatarBg} text-white font-bold flex items-center justify-center text-base shadow-md`, children: contact.name.charAt(0).toUpperCase() }, void 0, false, {
                      fileName: "/app/applet/src/App.tsx",
                      lineNumber: 1184,
                      columnNumber: 23
                    }, this),
                    contact.online && /* @__PURE__ */ jsxDEV("div", { className: "absolute bottom-0 right-0 w-3.5 h-3.5 bg-green-500 border-2 border-white rounded-full" }, void 0, false, {
                      fileName: "/app/applet/src/App.tsx",
                      lineNumber: 1188,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1183,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-0", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-1", children: [
                      /* @__PURE__ */ jsxDEV("h3", { className: "text-sm font-bold text-[#2d3748] group-hover:text-[#93b5c6] transition-colors truncate", children: contact.name }, void 0, false, {
                        fileName: "/app/applet/src/App.tsx",
                        lineNumber: 1194,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-[#718096]", children: contact.timestamp }, void 0, false, {
                        fileName: "/app/applet/src/App.tsx",
                        lineNumber: 1195,
                        columnNumber: 25
                      }, this)
                    ] }, void 0, true, {
                      fileName: "/app/applet/src/App.tsx",
                      lineNumber: 1193,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-[#718096] truncate", children: contact.lastMessage }, void 0, false, {
                      fileName: "/app/applet/src/App.tsx",
                      lineNumber: 1197,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1192,
                    columnNumber: 21
                  }, this),
                  contact.unreadCount && contact.unreadCount > 0 ? /* @__PURE__ */ jsxDEV("div", { className: "w-5 h-5 bg-[#93b5c6] text-white text-[10px] font-bold rounded-full flex items-center justify-center shadow-sm", children: contact.unreadCount }, void 0, false, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1201,
                    columnNumber: 17
                  }, this) : null
                ]
              },
              contact.id,
              true,
              {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 1175,
                columnNumber: 15
              },
              this
            )
          ) }, void 0, false, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 1170,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/app/applet/src/App.tsx",
          lineNumber: 1146,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/app/applet/src/App.tsx",
        lineNumber: 1076,
        columnNumber: 9
      }, this),
      activeTab === "chat" && activeContact && /* @__PURE__ */ jsxDEV("div", { className: "w-full flex-1 flex flex-col bg-white overflow-hidden shadow-none", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "px-6 py-4 border-b border-[#e5e0d8] bg-[#fdfbf7] flex items-center justify-between relative", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setActiveTab("home"),
                className: "p-1.5 text-[#4a5568] hover:bg-[#f0ede6] rounded-xl transition-colors mr-1",
                title: "Back to Home",
                children: /* @__PURE__ */ jsxDEV(ArrowLeft, { className: "w-5 h-5" }, void 0, false, {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 1222,
                  columnNumber: 19
                }, this)
              },
              void 0,
              false,
              {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 1217,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: `w-10 h-10 rounded-full ${activeContact.avatarBg} text-white font-bold flex items-center justify-center text-sm shadow-md`, children: activeContact.name.charAt(0).toUpperCase() }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1225,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-base font-bold text-[#2d3748]", children: activeContact.name }, void 0, false, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 1230,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] text-[#718096] block font-mono", children: activeContact.handle }, void 0, false, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 1231,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-[9px] text-[#718096]/80 block", children: [
                "(",
                activeContact.name.split(" ")[0],
                ")"
              ] }, void 0, true, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 1232,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1229,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 1216,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 relative", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setIsVideoCallActive(true),
                className: "p-2.5 bg-[#f0ede6] hover:bg-[#e5e0d8] text-[#4a5568] rounded-xl transition-colors flex items-center gap-2 text-xs font-semibold",
                children: [
                  /* @__PURE__ */ jsxDEV(Video, { className: "w-4 h-4 text-[#93b5c6]" }, void 0, false, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1241,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "hidden md:inline", children: "Secure Video Call" }, void 0, false, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1242,
                    columnNumber: 19
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 1237,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: () => setIsChatMenuOpen((prev) => !prev),
                  className: "p-2.5 bg-[#f0ede6] hover:bg-[#e5e0d8] text-[#4a5568] rounded-xl transition-colors",
                  title: "Menu Options",
                  children: /* @__PURE__ */ jsxDEV(MoreVertical, { className: "w-5 h-5" }, void 0, false, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1251,
                    columnNumber: 21
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 1246,
                  columnNumber: 19
                },
                this
              ),
              isChatMenuOpen && /* @__PURE__ */ jsxDEV("div", { className: "absolute right-0 top-12 w-64 bg-[#222b32] text-white rounded-2xl shadow-2xl py-2 z-50 border border-white/10 space-y-0.5", children: [
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => {
                      setIsChatMenuOpen(false);
                      alert("Search chat messages");
                    },
                    className: "w-full px-4 py-2.5 text-left text-sm hover:bg-white/10 flex items-center gap-3 transition-colors",
                    children: [
                      /* @__PURE__ */ jsxDEV(Search, { className: "w-4 h-4 text-gray-400" }, void 0, false, {
                        fileName: "/app/applet/src/App.tsx",
                        lineNumber: 1260,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { children: "Search" }, void 0, false, {
                        fileName: "/app/applet/src/App.tsx",
                        lineNumber: 1261,
                        columnNumber: 25
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1256,
                    columnNumber: 23
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => {
                      setIsChatMenuOpen(false);
                      setActiveTab("drive");
                    },
                    className: "w-full px-4 py-2.5 text-left text-sm hover:bg-white/10 flex items-center gap-3 transition-colors",
                    children: [
                      /* @__PURE__ */ jsxDEV(FolderArchive, { className: "w-4 h-4 text-gray-400" }, void 0, false, {
                        fileName: "/app/applet/src/App.tsx",
                        lineNumber: 1267,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { children: "Media, links, and docs" }, void 0, false, {
                        fileName: "/app/applet/src/App.tsx",
                        lineNumber: 1268,
                        columnNumber: 25
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1263,
                    columnNumber: 23
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => {
                      setIsChatMenuOpen(false);
                      setActiveTab("albums");
                    },
                    className: "w-full px-4 py-2.5 text-left text-sm hover:bg-white/10 flex items-center gap-3 transition-colors",
                    children: [
                      /* @__PURE__ */ jsxDEV(ImageIcon, { className: "w-4 h-4 text-gray-400" }, void 0, false, {
                        fileName: "/app/applet/src/App.tsx",
                        lineNumber: 1274,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { children: "Albums" }, void 0, false, {
                        fileName: "/app/applet/src/App.tsx",
                        lineNumber: 1275,
                        columnNumber: 25
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1270,
                    columnNumber: 23
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => {
                      setIsChatMenuOpen(false);
                      setActiveTab("drive");
                    },
                    className: "w-full px-4 py-2.5 text-left text-sm hover:bg-white/10 flex items-center gap-3 transition-colors",
                    children: [
                      /* @__PURE__ */ jsxDEV(HardDrive, { className: "w-4 h-4 text-gray-400" }, void 0, false, {
                        fileName: "/app/applet/src/App.tsx",
                        lineNumber: 1281,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { children: "Google Drive" }, void 0, false, {
                        fileName: "/app/applet/src/App.tsx",
                        lineNumber: 1282,
                        columnNumber: 25
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1277,
                    columnNumber: 23
                  },
                  this
                ),
                (currentUser.isAdmin || currentUser.isMasterAdmin) && /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: handleOpenAdminSuite,
                    className: "w-full px-4 py-2.5 text-left text-sm hover:bg-white/10 flex items-center gap-3 transition-colors",
                    children: [
                      /* @__PURE__ */ jsxDEV(Shield, { className: "w-4 h-4 text-gray-400" }, void 0, false, {
                        fileName: "/app/applet/src/App.tsx",
                        lineNumber: 1289,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { children: "Admin Suite" }, void 0, false, {
                        fileName: "/app/applet/src/App.tsx",
                        lineNumber: 1290,
                        columnNumber: 27
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1285,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => {
                      setIsChatMenuOpen(false);
                      setActiveTab("settings");
                    },
                    className: "w-full px-4 py-2.5 text-left text-sm hover:bg-white/10 flex items-center gap-3 transition-colors",
                    children: [
                      /* @__PURE__ */ jsxDEV(Settings, { className: "w-4 h-4 text-gray-400" }, void 0, false, {
                        fileName: "/app/applet/src/App.tsx",
                        lineNumber: 1297,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { children: "Settings" }, void 0, false, {
                        fileName: "/app/applet/src/App.tsx",
                        lineNumber: 1298,
                        columnNumber: 25
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1293,
                    columnNumber: 23
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "border-t border-white/10 my-1" }, void 0, false, {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 1300,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => {
                      setIsChatMenuOpen(false);
                      playSystemSound("call");
                      alert(`📞 Starting secure voice call with ${activeContact.name}...`);
                    },
                    className: "w-full px-4 py-2.5 text-left text-sm hover:bg-white/10 flex items-center gap-3 transition-colors",
                    children: [
                      /* @__PURE__ */ jsxDEV(Phone, { className: "w-4 h-4 text-gray-400" }, void 0, false, {
                        fileName: "/app/applet/src/App.tsx",
                        lineNumber: 1305,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { children: "Voice call" }, void 0, false, {
                        fileName: "/app/applet/src/App.tsx",
                        lineNumber: 1306,
                        columnNumber: 25
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1301,
                    columnNumber: 23
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => {
                      setIsChatMenuOpen(false);
                      playSystemSound("call");
                      setIsVideoCallActive(true);
                    },
                    className: "w-full px-4 py-2.5 text-left text-sm hover:bg-white/10 flex items-center gap-3 transition-colors",
                    children: [
                      /* @__PURE__ */ jsxDEV(Video, { className: "w-4 h-4 text-gray-400" }, void 0, false, {
                        fileName: "/app/applet/src/App.tsx",
                        lineNumber: 1312,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { children: "Video call" }, void 0, false, {
                        fileName: "/app/applet/src/App.tsx",
                        lineNumber: 1313,
                        columnNumber: 25
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1308,
                    columnNumber: 23
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "border-t border-white/10 my-1" }, void 0, false, {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 1315,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => {
                      setIsChatMenuOpen(false);
                      setMessages((prev) => ({ ...prev, [activeContact.id]: [] }));
                    },
                    className: "w-full px-4 py-2.5 text-left text-sm hover:bg-white/10 flex items-center gap-3 transition-colors text-red-400",
                    children: [
                      /* @__PURE__ */ jsxDEV(Trash, { className: "w-4 h-4" }, void 0, false, {
                        fileName: "/app/applet/src/App.tsx",
                        lineNumber: 1323,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { children: "Clear chat" }, void 0, false, {
                        fileName: "/app/applet/src/App.tsx",
                        lineNumber: 1324,
                        columnNumber: 25
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1316,
                    columnNumber: 23
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 1255,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1245,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 1236,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/app/applet/src/App.tsx",
          lineNumber: 1215,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex-1 overflow-y-auto p-6 space-y-4 bg-[#fdfbf7]/50", children: (messages[activeContact.id] || []).map(
          (msg) => /* @__PURE__ */ jsxDEV("div", { className: `flex flex-col ${msg.sender === currentUser.username ? "items-end" : "items-start"}`, children: msg.isAdminWarning ? /* @__PURE__ */ jsxDEV("div", { className: "w-full my-2 bg-[#fffaf0] border border-[#feebc8] p-3 rounded-xl text-xs text-[#9c4221] flex items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV(AlertTriangle, { className: "w-4 h-4 shrink-0 text-[#dd6b20]" }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1337,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: msg.content }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1338,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 1336,
            columnNumber: 15
          }, this) : /* @__PURE__ */ jsxDEV("div", { className: "max-w-[80%] space-y-1", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 text-xs text-[#718096] px-1", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-[#4a5568]", children: [
                "@",
                msg.sender
              ] }, void 0, true, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 1343,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: "·" }, void 0, false, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 1344,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: msg.timestamp }, void 0, false, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 1345,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1342,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: `p-4 rounded-2xl text-sm leading-relaxed ${msg.sender === currentUser.username ? "bg-[#93b5c6] text-white font-medium rounded-tr-none shadow-sm" : "bg-white text-[#2d3748] border border-[#e5e0d8] rounded-tl-none shadow-sm"}`, children: msg.content }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1347,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 1341,
            columnNumber: 15
          }, this) }, msg.id, false, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 1334,
            columnNumber: 13
          }, this)
        ) }, void 0, false, {
          fileName: "/app/applet/src/App.tsx",
          lineNumber: 1332,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSendMessage, className: "p-4 border-t border-[#e5e0d8] bg-white flex items-center gap-3", children: /* @__PURE__ */ jsxDEV("div", { className: "relative flex-1 flex items-center", children: [
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              value: chatInput,
              onChange: (e) => setChatInput(e.target.value),
              placeholder: "",
              className: "w-full bg-[#fdfbf7] border border-[#e5e0d8] rounded-xl pl-4 pr-12 py-3 text-sm text-[#2d3748] focus:outline-none focus:border-[#93b5c6]"
            },
            void 0,
            false,
            {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1358,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "submit",
              disabled: !chatInput.trim(),
              className: "absolute right-3 p-2 bg-[#93b5c6] hover:bg-[#7fa5b8] disabled:opacity-40 text-white rounded-lg transition-colors shadow-sm flex items-center justify-center",
              title: "Send Message",
              children: /* @__PURE__ */ jsxDEV(Send, { className: "w-4 h-4" }, void 0, false, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 1371,
                columnNumber: 19
              }, this)
            },
            void 0,
            false,
            {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1365,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/applet/src/App.tsx",
          lineNumber: 1357,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "/app/applet/src/App.tsx",
          lineNumber: 1356,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/app/applet/src/App.tsx",
        lineNumber: 1214,
        columnNumber: 9
      }, this),
      activeTab === "albums" && /* @__PURE__ */ jsxDEV("div", { className: "bg-[#0f0f0f] text-white min-h-screen -m-4 md:-m-8 p-4 md:p-6 space-y-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between pb-3 border-b border-gray-800", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5 font-bold text-base tracking-tight cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV("span", { children: currentUser?.username || "libre_style_2026" }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1384,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(ChevronDown, { className: "w-4 h-4 text-gray-400" }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1385,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "w-2 h-2 rounded-full bg-red-500 ml-1" }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1386,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 1383,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-5", children: /* @__PURE__ */ jsxDEV(Plus, { onClick: () => setShowCreateBox(!showCreateBox), className: `w-6 h-6 cursor-pointer transition-colors ${showCreateBox ? "text-blue-400" : "text-white"}` }, void 0, false, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 1389,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 1388,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/app/applet/src/App.tsx",
          lineNumber: 1382,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex border-t border-gray-800 text-gray-400", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => setActiveProfileTab("pics"),
              className: `flex-1 py-3 flex items-center justify-center gap-2 font-bold text-xs uppercase tracking-wider cursor-pointer transition-colors ${activeProfileTab === "pics" ? "border-t-2 border-white text-white bg-white/5" : "hover:text-white"}`,
              children: /* @__PURE__ */ jsxDEV("span", { children: "Pics" }, void 0, false, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 1399,
                columnNumber: 17
              }, this)
            },
            void 0,
            false,
            {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1395,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => setActiveProfileTab("videos"),
              className: `flex-1 py-3 flex items-center justify-center gap-2 font-bold text-xs uppercase tracking-wider cursor-pointer transition-colors ${activeProfileTab === "videos" ? "border-t-2 border-white text-white bg-white/5" : "hover:text-white"}`,
              children: /* @__PURE__ */ jsxDEV("span", { children: "Videos" }, void 0, false, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 1405,
                columnNumber: 17
              }, this)
            },
            void 0,
            false,
            {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1401,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/applet/src/App.tsx",
          lineNumber: 1394,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-6 max-w-lg mx-auto pb-20", children: [
          albums.filter((a, index) => {
            const isVideo = a.imageUrl?.endsWith(".mp4") || a.imageUrl?.includes("video") || a.imageUrl?.includes("webm") || index % 3 === 1;
            if (activeProfileTab === "pics") return !isVideo;
            return isVideo;
          }).map((a, index) => {
            const isLiked = albumLiked[a.id];
            const likesCount = (a.likes || 12) + (isLiked ? 1 : 0);
            const commentsList = albumComments[a.id] || a.comments || [
              { id: "1", author: "libre_style_fan", text: "Amazing quality and design! 🔥", time: "2h" },
              { id: "2", author: "fashion_hub", text: "Loved this collection.", time: "1h" }
            ];
            const isVideo = a.imageUrl?.endsWith(".mp4") || a.imageUrl?.includes("video") || a.imageUrl?.includes("webm") || index % 3 === 1;
            return /* @__PURE__ */ jsxDEV("div", { className: "bg-[#121212] border border-gray-800 rounded-2xl overflow-hidden shadow-xl", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between p-3 border-b border-gray-800/60", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2.5", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-8 h-8 rounded-full bg-gradient-to-tr from-yellow-400 to-pink-500 p-[1.5px]", children: /* @__PURE__ */ jsxDEV("div", { className: "w-full h-full rounded-full bg-gray-900 overflow-hidden flex items-center justify-center font-bold text-xs text-white", children: themeConfig.logoUrl ? /* @__PURE__ */ jsxDEV("img", { src: themeConfig.logoUrl, className: "w-full h-full object-cover" }, void 0, false, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1431,
                    columnNumber: 52
                  }, this) : "LS" }, void 0, false, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1430,
                    columnNumber: 27
                  }, this) }, void 0, false, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1429,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "text-xs font-bold text-white flex items-center gap-1", children: [
                      a.authorName || currentUser?.username || "libre_style_2026",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-blue-400 text-[10px]", children: "✓" }, void 0, false, {
                        fileName: "/app/applet/src/App.tsx",
                        lineNumber: 1437,
                        columnNumber: 29
                      }, this)
                    ] }, void 0, true, {
                      fileName: "/app/applet/src/App.tsx",
                      lineNumber: 1435,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "text-[10px] text-gray-400", children: a.timestamp || "2 hours ago" }, void 0, false, {
                      fileName: "/app/applet/src/App.tsx",
                      lineNumber: 1439,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1434,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 1428,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => setAlbumPinned((prev) => ({ ...prev, [a.id]: !(albumPinned[a.id] ?? index === 0) })),
                    className: `flex items-center gap-1 text-xs px-2.5 py-1 rounded-full border transition-colors ${albumPinned[a.id] ?? index === 0 ? "bg-blue-600/20 border-blue-500 text-blue-400" : "bg-gray-800 border-gray-700 text-gray-300 hover:text-white"}`,
                    children: [
                      /* @__PURE__ */ jsxDEV("span", { children: "📌" }, void 0, false, {
                        fileName: "/app/applet/src/App.tsx",
                        lineNumber: 1446,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] font-semibold", children: albumPinned[a.id] ?? index === 0 ? "Pinned" : "Pin" }, void 0, false, {
                        fileName: "/app/applet/src/App.tsx",
                        lineNumber: 1447,
                        columnNumber: 25
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1442,
                    columnNumber: 23
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 1427,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "relative w-full bg-black aspect-square flex items-center justify-center overflow-hidden", children: [
                isVideo ? /* @__PURE__ */ jsxDEV("video", { src: a.imageUrl, controls: true, className: "w-full h-full object-cover", autoPlay: true, muted: true, loop: true }, void 0, false, {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 1454,
                  columnNumber: 21
                }, this) : /* @__PURE__ */ jsxDEV("img", { src: a.imageUrl, alt: a.title, className: "w-full h-full object-cover" }, void 0, false, {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 1456,
                  columnNumber: 21
                }, this),
                (albumPinned[a.id] ?? index === 0) && /* @__PURE__ */ jsxDEV("div", { className: "absolute top-3 right-3 bg-black/60 text-white text-[10px] px-2.5 py-1 rounded-full backdrop-blur-sm flex items-center gap-1", children: [
                  /* @__PURE__ */ jsxDEV("span", { children: "📌" }, void 0, false, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1460,
                    columnNumber: 27
                  }, this),
                  " Pinned Post"
                ] }, void 0, true, {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 1459,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 1452,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "p-3.5 space-y-3", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
                    reactionPopupPostId === a.id && /* @__PURE__ */ jsxDEV("div", { className: "absolute -top-16 left-0 bg-[#1e1e1e] border border-gray-700 shadow-2xl rounded-2xl p-2 flex items-center gap-1.5 z-30 animate-in fade-in zoom-in", children: [
                      { label: "Love", icon: "❤️" },
                      { label: "Like", icon: "👍" },
                      { label: "Haha", icon: "😂" },
                      { label: "Wow", icon: "😮" },
                      { label: "Fire", icon: "🔥" },
                      { label: "Party", icon: "🎉" }
                    ].map(
                      (item) => /* @__PURE__ */ jsxDEV(
                        "button",
                        {
                          onClick: (e) => {
                            e.stopPropagation();
                            setAlbumReactions((prev) => ({ ...prev, [a.id]: item.icon }));
                            setAlbumLiked((prev) => ({ ...prev, [a.id]: true }));
                            setReactionPopupPostId(null);
                          },
                          className: "flex flex-col items-center gap-0.5 px-2.5 py-1.5 rounded-xl hover:bg-gray-800 text-white transition-all hover:scale-110",
                          title: item.label,
                          children: [
                            /* @__PURE__ */ jsxDEV("span", { className: "text-lg", children: item.icon }, void 0, false, {
                              fileName: "/app/applet/src/App.tsx",
                              lineNumber: 1492,
                              columnNumber: 37
                            }, this),
                            /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] font-semibold text-gray-300", children: item.label }, void 0, false, {
                              fileName: "/app/applet/src/App.tsx",
                              lineNumber: 1493,
                              columnNumber: 37
                            }, this)
                          ]
                        },
                        item.label,
                        true,
                        {
                          fileName: "/app/applet/src/App.tsx",
                          lineNumber: 1481,
                          columnNumber: 29
                        },
                        this
                      )
                    ) }, void 0, false, {
                      fileName: "/app/applet/src/App.tsx",
                      lineNumber: 1472,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "button",
                      {
                        onMouseDown: () => {
                          likeTimersRef.current[a.id] = setTimeout(() => {
                            setReactionPopupPostId(a.id);
                          }, 2e3);
                        },
                        onMouseUp: () => {
                          if (likeTimersRef.current[a.id]) {
                            clearTimeout(likeTimersRef.current[a.id]);
                            likeTimersRef.current[a.id] = null;
                          }
                        },
                        onMouseLeave: () => {
                          if (likeTimersRef.current[a.id]) {
                            clearTimeout(likeTimersRef.current[a.id]);
                            likeTimersRef.current[a.id] = null;
                          }
                        },
                        onTouchStart: () => {
                          likeTimersRef.current[a.id] = setTimeout(() => {
                            setReactionPopupPostId(a.id);
                          }, 2e3);
                        },
                        onTouchEnd: () => {
                          if (likeTimersRef.current[a.id]) {
                            clearTimeout(likeTimersRef.current[a.id]);
                            likeTimersRef.current[a.id] = null;
                          }
                        },
                        onClick: () => {
                          if (reactionPopupPostId === a.id) return;
                          setAlbumLiked((prev) => ({ ...prev, [a.id]: !prev[a.id] }));
                        },
                        className: "focus:outline-none transition-transform active:scale-125 flex items-center gap-1",
                        title: "Press & hold for 2 seconds for reactions",
                        children: [
                          /* @__PURE__ */ jsxDEV(Heart, { className: `w-6 h-6 ${isLiked ? "text-red-500 fill-red-500" : "text-white hover:text-gray-300"}` }, void 0, false, {
                            fileName: "/app/applet/src/App.tsx",
                            lineNumber: 1534,
                            columnNumber: 31
                          }, this),
                          albumReactions[a.id] && /* @__PURE__ */ jsxDEV("span", { className: "text-xs bg-gray-800 text-white px-1.5 py-0.5 rounded-full border border-gray-700", children: albumReactions[a.id] }, void 0, false, {
                            fileName: "/app/applet/src/App.tsx",
                            lineNumber: 1536,
                            columnNumber: 29
                          }, this)
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "/app/applet/src/App.tsx",
                        lineNumber: 1498,
                        columnNumber: 29
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1470,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("button", { className: "focus:outline-none hover:text-gray-300 text-white", title: "Comment", children: /* @__PURE__ */ jsxDEV(MessageCircle, { className: "w-6 h-6" }, void 0, false, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1545,
                    columnNumber: 29
                  }, this) }, void 0, false, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1544,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 1468,
                  columnNumber: 25
                }, this) }, void 0, false, {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 1467,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "text-xs font-bold text-white", children: [
                  likesCount,
                  " likes"
                ] }, void 0, true, {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 1551,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-gray-200", children: [
                  /* @__PURE__ */ jsxDEV("strong", { className: "text-white mr-1.5", children: a.authorName || "libre_style_2026" }, void 0, false, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1557,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-white mr-1", children: [
                    a.title,
                    ":"
                  ] }, void 0, true, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1558,
                    columnNumber: 25
                  }, this),
                  a.caption
                ] }, void 0, true, {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 1556,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "space-y-1 pt-1", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] text-gray-400", children: [
                    "View all ",
                    commentsList.length,
                    " comments"
                  ] }, void 0, true, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1564,
                    columnNumber: 25
                  }, this),
                  commentsList.map(
                    (c) => /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-gray-300", children: [
                      /* @__PURE__ */ jsxDEV("strong", { className: "text-white mr-1.5", children: [
                        "@",
                        c.author
                      ] }, void 0, true, {
                        fileName: "/app/applet/src/App.tsx",
                        lineNumber: 1569,
                        columnNumber: 29
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { children: c.text }, void 0, false, {
                        fileName: "/app/applet/src/App.tsx",
                        lineNumber: 1570,
                        columnNumber: 29
                      }, this)
                    ] }, c.id, true, {
                      fileName: "/app/applet/src/App.tsx",
                      lineNumber: 1568,
                      columnNumber: 23
                    }, this)
                  )
                ] }, void 0, true, {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 1563,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "form",
                  {
                    onSubmit: (e) => {
                      e.preventDefault();
                      const text = commentInputText[a.id];
                      if (!text || !text.trim()) return;
                      const newComment = { id: Date.now().toString(), author: currentUser?.username || "user", text: text.trim(), time: "Just now" };
                      setAlbumComments((prev) => ({
                        ...prev,
                        [a.id]: [...prev[a.id] || a.comments || [], newComment]
                      }));
                      setCommentInputText((prev) => ({ ...prev, [a.id]: "" }));
                    },
                    className: "pt-2 border-t border-gray-800 flex items-center gap-2",
                    children: [
                      /* @__PURE__ */ jsxDEV(
                        "input",
                        {
                          type: "text",
                          value: commentInputText[a.id] || "",
                          onChange: (e) => setCommentInputText((prev) => ({ ...prev, [a.id]: e.target.value })),
                          placeholder: "Add a comment...",
                          className: "flex-1 bg-transparent text-xs text-white placeholder-gray-500 focus:outline-none"
                        },
                        void 0,
                        false,
                        {
                          fileName: "/app/applet/src/App.tsx",
                          lineNumber: 1590,
                          columnNumber: 25
                        },
                        this
                      ),
                      /* @__PURE__ */ jsxDEV("button", { type: "submit", disabled: !commentInputText[a.id]?.trim(), className: "text-xs font-bold text-blue-500 hover:text-blue-400 disabled:opacity-40", children: "Post" }, void 0, false, {
                        fileName: "/app/applet/src/App.tsx",
                        lineNumber: 1597,
                        columnNumber: 25
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1576,
                    columnNumber: 23
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 1466,
                columnNumber: 21
              }, this)
            ] }, a.id, true, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1425,
              columnNumber: 17
            }, this);
          }),
          albums.length === 0 && /* @__PURE__ */ jsxDEV("div", { className: "bg-[#121212] border border-gray-800 rounded-2xl p-8 text-center text-gray-400 space-y-2", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold", children: "No posts yet." }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1609,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Create a new album or post using the form above!" }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1610,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 1608,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/app/applet/src/App.tsx",
          lineNumber: 1410,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/app/applet/src/App.tsx",
        lineNumber: 1380,
        columnNumber: 9
      }, this),
      activeTab === "drive" && /* @__PURE__ */ jsxDEV("div", { className: "space-y-8 max-w-4xl", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold text-[#2d3748]", children: "Google Drive Backup & Storage" }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1622,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-[#718096]", children: "Manage synced cloud backup folders and file categories." }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1623,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 1621,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => setActiveTab("home"),
              className: "px-4 py-2 bg-[#93b5c6] text-white rounded-xl text-xs font-semibold",
              children: "Home"
            },
            void 0,
            false,
            {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1625,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/applet/src/App.tsx",
          lineNumber: 1620,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-[#e5e0d8] rounded-2xl p-6 space-y-4 shadow-sm", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between text-xs font-medium text-[#4a5568]", children: [
            /* @__PURE__ */ jsxDEV("span", { children: [
              "Storage Used: ",
              driveStorageUsed,
              " GB of ",
              driveStorageTotal,
              " GB"
            ] }, void 0, true, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1636,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: "Active Sync" }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1637,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 1635,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "w-full h-3 bg-[#f0ede6] rounded-full overflow-hidden", children: /* @__PURE__ */ jsxDEV("div", { className: "h-full bg-[#93b5c6]", style: { width: `${driveStorageUsed / driveStorageTotal * 100}%` } }, void 0, false, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 1640,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 1639,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/app/applet/src/App.tsx",
          lineNumber: 1634,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "text-sm font-bold text-[#2d3748] uppercase tracking-wider", children: "Concern Folders" }, void 0, false, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 1646,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 md:grid-cols-5 gap-4", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setSelectedFolderFilter(selectedFolderFilter === "Image" ? null : "Image"),
                className: `bg-white border p-4 rounded-2xl text-left transition-all shadow-sm space-y-2 ${selectedFolderFilter === "Image" ? "border-[#93b5c6] bg-[#93b5c6]/10 font-semibold" : "border-[#e5e0d8] hover:border-[#93b5c6]"}`,
                children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-10 h-10 rounded-xl bg-[#93b5c6]/20 text-[#93b5c6] flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(ImageIcon, { className: "w-5 h-5" }, void 0, false, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1653,
                    columnNumber: 21
                  }, this) }, void 0, false, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1652,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("h4", { className: "text-sm font-bold text-[#2d3748]", children: "Images" }, void 0, false, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1655,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-[#718096]", children: "Photos & Media" }, void 0, false, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1656,
                    columnNumber: 19
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 1648,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setSelectedFolderFilter(selectedFolderFilter === "File" ? null : "File"),
                className: `bg-white border p-4 rounded-2xl text-left transition-all shadow-sm space-y-2 ${selectedFolderFilter === "File" ? "border-[#93b5c6] bg-[#93b5c6]/10 font-semibold" : "border-[#e5e0d8] hover:border-[#93b5c6]"}`,
                children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-10 h-10 rounded-xl bg-[#a3c1ad]/20 text-[#6b8e23] flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(FileText, { className: "w-5 h-5" }, void 0, false, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1664,
                    columnNumber: 21
                  }, this) }, void 0, false, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1663,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("h4", { className: "text-sm font-bold text-[#2d3748]", children: "Files" }, void 0, false, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1666,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-[#718096]", children: "Docs & Transcripts" }, void 0, false, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1667,
                    columnNumber: 19
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 1659,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setSelectedFolderFilter(selectedFolderFilter === "Video" ? null : "Video"),
                className: `bg-white border p-4 rounded-2xl text-left transition-all shadow-sm space-y-2 ${selectedFolderFilter === "Video" ? "border-[#93b5c6] bg-[#93b5c6]/10 font-semibold" : "border-[#e5e0d8] hover:border-[#93b5c6]"}`,
                children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-10 h-10 rounded-xl bg-[#b91c1c]/20 text-[#b91c1c] flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(Film, { className: "w-5 h-5" }, void 0, false, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1675,
                    columnNumber: 21
                  }, this) }, void 0, false, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1674,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("h4", { className: "text-sm font-bold text-[#2d3748]", children: "Videos" }, void 0, false, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1677,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-[#718096]", children: "Recordings & clips" }, void 0, false, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1678,
                    columnNumber: 19
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 1670,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setSelectedFolderFilter(selectedFolderFilter === "Backup" ? null : "Backup"),
                className: `bg-white border p-4 rounded-2xl text-left transition-all shadow-sm space-y-2 ${selectedFolderFilter === "Backup" ? "border-[#93b5c6] bg-[#93b5c6]/10 font-semibold" : "border-[#e5e0d8] hover:border-[#93b5c6]"}`,
                children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-10 h-10 rounded-xl bg-[#718096]/20 text-[#4a5568] flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(MessageSquareCode, { className: "w-5 h-5" }, void 0, false, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1686,
                    columnNumber: 21
                  }, this) }, void 0, false, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1685,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("h4", { className: "text-sm font-bold text-[#2d3748]", children: "Chat backup" }, void 0, false, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1688,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-[#718096]", children: "JSON Archives" }, void 0, false, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1689,
                    columnNumber: 19
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 1681,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setSelectedFolderFilter(selectedFolderFilter === "Audio" ? null : "Audio"),
                className: `bg-white border p-4 rounded-2xl text-left transition-all shadow-sm space-y-2 ${selectedFolderFilter === "Audio" ? "border-[#93b5c6] bg-[#93b5c6]/10 font-semibold" : "border-[#e5e0d8] hover:border-[#93b5c6]"}`,
                children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-10 h-10 rounded-xl bg-[#e28743]/20 text-[#e28743] flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(Mic, { className: "w-5 h-5" }, void 0, false, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1697,
                    columnNumber: 21
                  }, this) }, void 0, false, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1696,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("h4", { className: "text-sm font-bold text-[#2d3748]", children: "And more" }, void 0, false, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1699,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-[#718096]", children: "Audio & Cache" }, void 0, false, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1700,
                    columnNumber: 19
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 1692,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 1647,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/app/applet/src/App.tsx",
          lineNumber: 1645,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-[#e5e0d8] rounded-2xl overflow-hidden shadow-sm divide-y divide-[#e5e0d8]", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "px-5 py-3.5 bg-[#fdfbf7] text-xs font-semibold text-[#718096] uppercase tracking-wider flex items-center justify-between", children: [
            /* @__PURE__ */ jsxDEV("span", { children: [
              "Cloud Files ",
              selectedFolderFilter ? `(${selectedFolderFilter} Folder)` : ""
            ] }, void 0, true, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1708,
              columnNumber: 17
            }, this),
            selectedFolderFilter && /* @__PURE__ */ jsxDEV("button", { onClick: () => setSelectedFolderFilter(null), className: "text-[#93b5c6] hover:underline text-[11px] font-medium", children: "Clear Filter" }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1710,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 1707,
            columnNumber: 15
          }, this),
          driveFiles.filter((f) => !selectedFolderFilter || f.type === selectedFolderFilter).map(
            (file) => /* @__PURE__ */ jsxDEV("div", { className: "p-4 flex items-center justify-between hover:bg-[#fdfbf7] transition-colors", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "w-10 h-10 rounded-xl bg-[#f0ede6] text-[#4a5568] flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(Folder, { className: "w-5 h-5 text-[#93b5c6]" }, void 0, false, {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 1720,
                  columnNumber: 25
                }, this) }, void 0, false, {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 1719,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("h4", { className: "text-sm font-bold text-[#2d3748]", children: file.name }, void 0, false, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1723,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-[#718096]", children: [
                    file.size,
                    " · ",
                    file.createdTime
                  ] }, void 0, true, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1724,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 1722,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 1718,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] bg-[#93b5c6]/20 text-[#2d3748] px-2.5 py-1 rounded-full font-mono", children: file.type }, void 0, false, {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 1729,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => handleDeleteDriveFile(file.id, file.size),
                    className: "p-2 text-red-500 hover:bg-red-50 rounded-xl transition-colors",
                    title: "Delete File",
                    children: /* @__PURE__ */ jsxDEV(Trash2, { className: "w-4 h-4" }, void 0, false, {
                      fileName: "/app/applet/src/App.tsx",
                      lineNumber: 1735,
                      columnNumber: 25
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1730,
                    columnNumber: 23
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 1728,
                columnNumber: 21
              }, this)
            ] }, file.id, true, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1717,
              columnNumber: 13
            }, this)
          )
        ] }, void 0, true, {
          fileName: "/app/applet/src/App.tsx",
          lineNumber: 1706,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/app/applet/src/App.tsx",
        lineNumber: 1619,
        columnNumber: 9
      }, this),
      activeTab === "admin" && (currentUser.isAdmin || currentUser.isMasterAdmin) && /* @__PURE__ */ jsxDEV("div", { className: "space-y-8", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold text-[#2d3748]", children: "Master Admin Suite" }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1749,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-[#718096]", children: "Full white-label branding controls and user permission management." }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1750,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 1748,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => setActiveTab("home"),
              className: "px-4 py-2 bg-[#93b5c6] text-white rounded-xl text-xs font-semibold",
              children: "Home"
            },
            void 0,
            false,
            {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1752,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/applet/src/App.tsx",
          lineNumber: 1747,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-[#e5e0d8] rounded-3xl p-6 space-y-6 shadow-sm", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 pb-4 border-b border-[#e5e0d8]", children: [
            /* @__PURE__ */ jsxDEV(NCLogo, { size: "lg", logoUrl: themeConfig.logoUrl }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1763,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h4", { className: "text-sm font-bold text-[#2d3748]", children: "App Logo Preview" }, void 0, false, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 1765,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-[#718096]", children: "Upload your custom logo below to update this preview and branding across the app." }, void 0, false, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 1766,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1764,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 1762,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-medium text-[#4a5568]", children: "App Name" }, void 0, false, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 1772,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  value: themeConfig.themeName,
                  onChange: (e) => setThemeConfig({ ...themeConfig, themeName: e.target.value }),
                  className: "w-full bg-[#fdfbf7] border border-[#e5e0d8] rounded-xl px-4 py-2.5 text-sm text-[#2d3748]"
                },
                void 0,
                false,
                {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 1773,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1771,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-medium text-[#4a5568]", children: "Slogan / Subtitle" }, void 0, false, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 1782,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  value: themeConfig.slogan,
                  onChange: (e) => setThemeConfig({ ...themeConfig, slogan: e.target.value }),
                  className: "w-full bg-[#fdfbf7] border border-[#e5e0d8] rounded-xl px-4 py-2.5 text-sm text-[#2d3748]"
                },
                void 0,
                false,
                {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 1783,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1781,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-medium text-[#4a5568]", children: "Powered By Text" }, void 0, false, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 1792,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  value: themeConfig.poweredBy,
                  onChange: (e) => setThemeConfig({ ...themeConfig, poweredBy: e.target.value }),
                  className: "w-full bg-[#fdfbf7] border border-[#e5e0d8] rounded-xl px-4 py-2.5 text-sm text-[#2d3748]"
                },
                void 0,
                false,
                {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 1793,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1791,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-medium text-[#4a5568]", children: "Logo" }, void 0, false, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 1802,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 bg-[#fdfbf7] border border-[#e5e0d8] rounded-xl px-4 py-2", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-[#718096] truncate flex-1", children: logoFileName || (themeConfig.logoUrl ? "Logo uploaded successfully" : "No logo chosen") }, void 0, false, {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 1804,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("label", { className: "px-4 py-2 bg-[#93b5c6] hover:bg-[#7fa5b8] text-white rounded-lg text-xs font-semibold cursor-pointer shadow-sm transition-colors flex items-center gap-2 shrink-0 select-none", children: [
                  /* @__PURE__ */ jsxDEV(UploadIcon, { className: "w-4 h-4" }, void 0, false, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1808,
                    columnNumber: 23
                  }, this),
                  "Upload Logo",
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "file",
                      accept: "image/*",
                      onChange: (e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          setLogoFileName(file.name);
                          const reader = new FileReader();
                          reader.onloadend = () => {
                            setThemeConfig({ ...themeConfig, logoUrl: reader.result });
                          };
                          reader.readAsDataURL(file);
                        }
                      },
                      className: "hidden"
                    },
                    void 0,
                    false,
                    {
                      fileName: "/app/applet/src/App.tsx",
                      lineNumber: 1810,
                      columnNumber: 23
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 1807,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 1803,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1801,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 1770,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-medium text-[#4a5568]", children: "About Us Text" }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1832,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "textarea",
              {
                value: themeConfig.aboutText,
                onChange: (e) => setThemeConfig({ ...themeConfig, aboutText: e.target.value }),
                rows: 2,
                className: "w-full bg-[#fdfbf7] border border-[#e5e0d8] rounded-xl px-4 py-2.5 text-sm text-[#2d3748]"
              },
              void 0,
              false,
              {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 1833,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 1831,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-medium text-[#4a5568]", children: "Color Theme Accent" }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1842,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: ["#93b5c6", "#6b8e23", "#b91c1c", "#e28743", "#4f46e5", "#2d3748"].map(
              (color) => /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: () => setThemeConfig({ ...themeConfig, primaryColor: color }),
                  className: `w-8 h-8 rounded-full border-2 transition-all ${themeConfig.primaryColor === color ? "border-[#2d3748] scale-110 shadow-md" : "border-transparent"}`,
                  style: { backgroundColor: color }
                },
                color,
                false,
                {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 1845,
                  columnNumber: 17
                },
                this
              )
            ) }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1843,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 1841,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-medium text-[#4a5568]", children: "Theme Mode" }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1856,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-3 gap-2", children: ["Light", "Dark", "System default"].map(
              (mode) => /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: () => setThemeMode(mode),
                  className: `px-4 py-2 rounded-xl text-xs font-semibold border transition-all ${themeMode === mode ? "bg-[#93b5c6] text-white border-[#93b5c6] shadow-sm" : "bg-[#fdfbf7] text-[#4a5568] border-[#e5e0d8] hover:bg-[#f5f2eb]"}`,
                  children: mode
                },
                mode,
                false,
                {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 1859,
                  columnNumber: 17
                },
                this
              )
            ) }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1857,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 1855,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "pt-4 border-t border-[#e5e0d8] flex items-center justify-between", children: [
            /* @__PURE__ */ jsxDEV("div", { children: adminSaveMsg && /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-semibold text-green-600 bg-green-50 px-3 py-1.5 rounded-lg border border-green-200", children: adminSaveMsg }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1873,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1871,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => {
                  setAdminSaveMsg("Admin settings saved successfully!");
                  setTimeout(() => setAdminSaveMsg(""), 3e3);
                },
                className: "px-6 py-2.5 bg-[#93b5c6] hover:bg-[#7fa5b8] text-white font-semibold rounded-xl text-xs transition-colors shadow-sm flex items-center gap-2",
                children: [
                  /* @__PURE__ */ jsxDEV(Check, { className: "w-4 h-4" }, void 0, false, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1885,
                    columnNumber: 19
                  }, this),
                  "Save Changes"
                ]
              },
              void 0,
              true,
              {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 1878,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 1870,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/app/applet/src/App.tsx",
          lineNumber: 1761,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-[#e5e0d8] rounded-3xl p-6 space-y-4 shadow-sm", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-bold text-[#2d3748] flex items-center gap-2", children: [
              /* @__PURE__ */ jsxDEV(UserCheck, { className: "w-5 h-5 text-[#93b5c6]" }, void 0, false, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 1895,
                columnNumber: 19
              }, this),
              "User Access & Admin Promotion"
            ] }, void 0, true, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1894,
              columnNumber: 17
            }, this),
            currentUser.isMasterAdmin && /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] bg-red-100 text-red-700 px-3 py-1 rounded-full font-bold font-mono", children: "👑 Master Admin Level Access" }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1899,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 1893,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "divide-y divide-[#e5e0d8]", children: adminUsers.map(
            (u) => /* @__PURE__ */ jsxDEV("div", { className: "py-3 flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("div", { className: "text-sm font-bold text-[#2d3748]", children: [
                  "@",
                  u.username,
                  " ",
                  u.isMasterAdmin && /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] bg-red-100 text-red-700 px-2 py-0.5 rounded font-mono ml-1", children: "MASTER ADMIN" }, void 0, false, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 1909,
                    columnNumber: 107
                  }, this)
                ] }, void 0, true, {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 1909,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-[#718096]", children: [
                  u.email,
                  " · ",
                  u.device
                ] }, void 0, true, {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 1910,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 1908,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV("span", { className: `text-xs px-2.5 py-1 rounded-full font-semibold ${u.isAdmin ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-600"}`, children: u.isAdmin ? "Admin" : "Standard" }, void 0, false, {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 1914,
                  columnNumber: 23
                }, this),
                !u.isMasterAdmin && /* @__PURE__ */ jsxDEV(Fragment, { children: [
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      onClick: () => handlePromoteUser(u.id),
                      className: "px-3 py-1.5 bg-[#93b5c6] hover:bg-[#7fa5b8] text-white rounded-xl text-xs font-semibold transition-colors",
                      children: u.isAdmin ? "Demote" : "Promote"
                    },
                    void 0,
                    false,
                    {
                      fileName: "/app/applet/src/App.tsx",
                      lineNumber: 1919,
                      columnNumber: 27
                    },
                    this
                  ),
                  currentUser.isMasterAdmin && /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      onClick: () => handleDeleteUser(u.id),
                      className: "px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-semibold transition-colors",
                      title: "Master Admin Only: Purge User",
                      children: "Purge"
                    },
                    void 0,
                    false,
                    {
                      fileName: "/app/applet/src/App.tsx",
                      lineNumber: 1926,
                      columnNumber: 21
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 1918,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 1913,
                columnNumber: 21
              }, this)
            ] }, u.id, true, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1907,
              columnNumber: 15
            }, this)
          ) }, void 0, false, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 1905,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/app/applet/src/App.tsx",
          lineNumber: 1892,
          columnNumber: 13
        }, this),
        currentUser.isMasterAdmin && /* @__PURE__ */ jsxDEV("div", { className: "bg-[#fffaf0] border border-[#feebc8] rounded-3xl p-6 space-y-4 shadow-sm", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV(Shield, { className: "w-5 h-5 text-[#dd6b20]" }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1946,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-bold text-[#9c4221]", children: "Master Admin Exclusive: Global System Broadcast" }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 1947,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 1945,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-[#718096]", children: "As Master Admin, you have supreme authority to broadcast urgent system-wide announcements to all active chats and users simultaneously." }, void 0, false, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 1949,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-2 pt-1", children: /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: [
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                placeholder: "Type urgent system broadcast announcement...",
                id: "master-broadcast-input",
                className: "flex-1 bg-white border border-[#e5e0d8] rounded-xl px-4 py-2.5 text-xs text-[#2d3748]"
              },
              void 0,
              false,
              {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 1953,
                columnNumber: 21
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => {
                  const input = document.getElementById("master-broadcast-input");
                  if (!input || !input.value.trim()) return;
                  const broadcastText = `🚨 MASTER ADMIN BROADCAST: ${input.value}`;
                  setMessages((prev) => {
                    const updated = { ...prev };
                    Object.keys(updated).forEach((contactId) => {
                      updated[contactId] = [
                        ...updated[contactId] || [],
                        {
                          id: Date.now().toString(),
                          sender: currentUser.username,
                          content: broadcastText,
                          timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
                          isAdminWarning: true,
                          isE2EE: true
                        }
                      ];
                    });
                    return updated;
                  });
                  setAuditLog(
                    (prev) => [
                      { id: `l-${Date.now()}`, action: `Global Broadcast: "${input.value}"`, user: currentUser.username, time: (/* @__PURE__ */ new Date()).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) },
                      ...prev
                    ]
                  );
                  input.value = "";
                  alert("Broadcast successfully sent to all active chats workspace-wide!");
                },
                className: "px-5 py-2.5 bg-[#b91c1c] hover:bg-[#a11616] text-white rounded-xl text-xs font-bold transition-colors shrink-0 shadow-sm",
                children: "Broadcast Now"
              },
              void 0,
              false,
              {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 1959,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 1952,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 1951,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/app/applet/src/App.tsx",
          lineNumber: 1944,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-[#e5e0d8] rounded-3xl p-6 space-y-5 shadow-sm", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between border-b border-[#e5e0d8] pb-4", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-bold text-[#2d3748] flex items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV(FolderArchive, { className: "w-5 h-5 text-[#93b5c6]" }, void 0, false, {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 2003,
                  columnNumber: 21
                }, this),
                "Master Admin ZIP Archive Command & Customizer"
              ] }, void 0, true, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 2002,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-[#718096] mt-0.5", children: "Toggle files to include or exclude. All 14 core project files are included by default." }, void 0, false, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 2006,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 2001,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: () => setZipOptions({ server: true, apiIndex: true, app: true, packageJson: true, packageLockJson: true, tsconfig: true, viteConfig: true, vercelJson: true, redirects: true, indexHtml: true, metadata: true, firebaseConfig: true, readme: true, mainTsx: true, indexCss: true, viteEnv: true, netlifyToml: true, gitignore: true, npmrc: true }),
                  className: "px-2.5 py-1 bg-gray-100 hover:bg-gray-200 text-[#2d3748] rounded-lg text-[11px] font-semibold transition-colors",
                  children: "Select All"
                },
                void 0,
                false,
                {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 2009,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: () => setZipOptions({ server: false, apiIndex: false, app: false, packageJson: false, packageLockJson: false, tsconfig: false, viteConfig: false, vercelJson: false, redirects: false, indexHtml: false, metadata: false, firebaseConfig: false, readme: false, mainTsx: false, indexCss: false, viteEnv: false, netlifyToml: false, gitignore: false, npmrc: false }),
                  className: "px-2.5 py-1 bg-gray-100 hover:bg-gray-200 text-[#2d3748] rounded-lg text-[11px] font-semibold transition-colors",
                  children: "Deselect All"
                },
                void 0,
                false,
                {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 2015,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 2008,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 2e3,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 md:grid-cols-4 gap-3", children: [
            { key: "server", label: "server.ts (Backend)" },
            { key: "apiIndex", label: "api/index.ts (Serverless)", stateKey: "apiIndex" },
            { key: "app", label: "src/App.tsx (Main App)" },
            { key: "packageJson", label: "package.json" },
            { key: "packageLockJson", label: "package-lock.json", stateKey: "packageLockJson" },
            { key: "tsconfig.json", label: "tsconfig.json", stateKey: "tsconfig" },
            { key: "viteConfig", label: "vite.config.ts" },
            { key: "vercelJson", label: "vercel.json", stateKey: "vercelJson" },
            { key: "redirects", label: "_redirects (Cloudflare/Netlify)", stateKey: "redirects" },
            { key: "indexHtml", label: "index.html" },
            { key: "metadata", label: "metadata.json" },
            { key: "firebaseConfig", label: "firebase-applet-config.json" },
            { key: "mainTsx", label: "src/main.tsx" },
            { key: "indexCss", label: "src/index.css" },
            { key: "viteEnv", label: "src/vite-env.d.ts" },
            { key: "netlifyToml", label: "netlify.toml", stateKey: "netlifyToml" },
            { key: "gitignore", label: ".gitignore" },
            { key: "npmrc", label: ".npmrc", stateKey: "npmrc" },
            { key: "readme", label: "README.md" }
          ].map((item) => {
            const val = zipOptions[item.stateKey || item.key];
            return /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2.5 bg-[#fdfbf7] border border-[#e5e0d8] rounded-xl p-3 cursor-pointer hover:border-[#93b5c6] transition-colors", children: [
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "checkbox",
                  checked: val,
                  onChange: (e) => setZipOptions({ ...zipOptions, [item.stateKey || item.key]: e.target.checked }),
                  className: "rounded border-[#e5e0d8] text-[#93b5c6] focus:ring-[#93b5c6]"
                },
                void 0,
                false,
                {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 2049,
                  columnNumber: 23
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-medium text-[#2d3748] truncate", children: item.label }, void 0, false, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 2055,
                columnNumber: 23
              }, this)
            ] }, item.key, true, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 2048,
              columnNumber: 19
            }, this);
          }) }, void 0, false, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 2024,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between pt-2 border-t border-[#e5e0d8]", children: [
            /* @__PURE__ */ jsxDEV("div", { children: zipUpdateMessage && /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-semibold text-green-600 bg-green-50 px-3 py-1.5 rounded-lg border border-green-200", children: zipUpdateMessage }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 2064,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 2062,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: handleDownloadSourceArchive,
                className: "px-6 py-3 bg-[#93b5c6] hover:bg-[#7fa5b8] text-white font-bold rounded-xl text-xs flex items-center gap-2 transition-colors shadow-sm",
                children: [
                  /* @__PURE__ */ jsxDEV(Download, { className: "w-4 h-4" }, void 0, false, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 2073,
                    columnNumber: 19
                  }, this),
                  "Update & Download Updated ZIP"
                ]
              },
              void 0,
              true,
              {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 2069,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 2061,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/app/applet/src/App.tsx",
          lineNumber: 1999,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/app/applet/src/App.tsx",
        lineNumber: 1746,
        columnNumber: 9
      }, this),
      activeTab === "settings" && /* @__PURE__ */ jsxDEV("div", { className: "space-y-8 max-w-2xl", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold text-[#2d3748]", children: "Settings & Workspace Info" }, void 0, false, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 2085,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => setActiveTab("home"),
              className: "px-4 py-2 bg-[#93b5c6] text-white rounded-xl text-xs font-semibold",
              children: "Home"
            },
            void 0,
            false,
            {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 2086,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/applet/src/App.tsx",
          lineNumber: 2084,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-[#e5e0d8] rounded-3xl p-6 flex items-center justify-between shadow-sm", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
            /* @__PURE__ */ jsxDEV(NCLogo, { size: "md", logoUrl: themeConfig.logoUrl }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 2097,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-bold text-[#2d3748]", children: themeConfig.themeName }, void 0, false, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 2099,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-mono text-[#718096] uppercase tracking-wider", children: themeConfig.slogan }, void 0, false, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 2100,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 2098,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 2096,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => setCurrentUser(null),
              className: "px-4 py-2.5 bg-[#f0ede6] hover:bg-[#e5e0d8] text-[#2d3748] rounded-xl text-xs font-semibold flex items-center gap-2 border border-[#e5e0d8] transition-colors",
              title: "Sign Out",
              children: [
                /* @__PURE__ */ jsxDEV(LogOut, { className: "w-4 h-4" }, void 0, false, {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 2108,
                  columnNumber: 17
                }, this),
                "Sign Out"
              ]
            },
            void 0,
            true,
            {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 2103,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/applet/src/App.tsx",
          lineNumber: 2095,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-[#e5e0d8] rounded-2xl p-6 space-y-3 shadow-sm", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-[#718096]", children: [
            "Signed in user ID: ",
            /* @__PURE__ */ jsxDEV("strong", { className: "text-[#2d3748]", children: [
              "@",
              currentUser.username
            ] }, void 0, true, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 2114,
              columnNumber: 74
            }, this)
          ] }, void 0, true, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 2114,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-[#718096]", children: [
            "Current Device: ",
            currentUser.device
          ] }, void 0, true, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 2115,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-[#718096]", children: [
            "Geo-Location: ",
            currentUser.geoLocation
          ] }, void 0, true, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 2116,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-[#718096] pt-2 border-t border-[#e5e0d8]", children: themeConfig.aboutText }, void 0, false, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 2117,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/app/applet/src/App.tsx",
          lineNumber: 2113,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-[#e5e0d8] rounded-3xl p-6 space-y-6 shadow-sm", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between border-b border-[#e5e0d8] pb-4", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-bold text-[#2d3748] flex items-center gap-2", children: [
                "Business Profile & Verified Status",
                getBusinessVerificationStatus(businessProfile).isVerified && /* @__PURE__ */ jsxDEV("span", { className: "bg-blue-600 text-white rounded-full p-0.5 text-xs inline-flex items-center justify-center w-5 h-5 shadow-sm", title: "Verified Business (Blue Tick)", children: "✓" }, void 0, false, {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 2127,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 2124,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-[#718096]", children: "Fill ≥80% (13 of 16 details) to automatically earn the Verified Business Blue Tick badge." }, void 0, false, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 2130,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 2123,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-right", children: /* @__PURE__ */ jsxDEV("span", { className: `text-xs px-3 py-1.5 rounded-full font-bold ${getBusinessVerificationStatus(businessProfile).isVerified ? "bg-blue-100 text-blue-800" : "bg-amber-100 text-amber-800"}`, children: [
              getBusinessVerificationStatus(businessProfile).score,
              "% Complete (",
              getBusinessVerificationStatus(businessProfile).filledCount,
              "/16)"
            ] }, void 0, true, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 2133,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 2132,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 2122,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-medium text-[#4a5568]", children: "1. Business Name" }, void 0, false, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 2141,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  value: businessProfile.businessName,
                  onChange: (e) => setBusinessProfile({ ...businessProfile, businessName: e.target.value }),
                  className: "w-full bg-[#fdfbf7] border border-[#e5e0d8] rounded-xl px-4 py-2.5 text-sm text-[#2d3748]"
                },
                void 0,
                false,
                {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 2142,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 2140,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-medium text-[#4a5568]", children: "2. Business Username" }, void 0, false, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 2151,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  value: businessProfile.businessUsername,
                  onChange: (e) => setBusinessProfile({ ...businessProfile, businessUsername: e.target.value }),
                  className: "w-full bg-[#fdfbf7] border border-[#e5e0d8] rounded-xl px-4 py-2.5 text-sm text-[#2d3748]"
                },
                void 0,
                false,
                {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 2152,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 2150,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-medium text-[#4a5568]", children: "3. Business Category" }, void 0, false, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 2161,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  value: businessProfile.businessCategory,
                  onChange: (e) => setBusinessProfile({ ...businessProfile, businessCategory: e.target.value }),
                  className: "w-full bg-[#fdfbf7] border border-[#e5e0d8] rounded-xl px-4 py-2.5 text-sm text-[#2d3748]"
                },
                void 0,
                false,
                {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 2162,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 2160,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-medium text-[#4a5568]", children: "4. Email Address" }, void 0, false, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 2171,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "email",
                  value: businessProfile.emailAddress,
                  onChange: (e) => setBusinessProfile({ ...businessProfile, emailAddress: e.target.value }),
                  className: "w-full bg-[#fdfbf7] border border-[#e5e0d8] rounded-xl px-4 py-2.5 text-sm text-[#2d3748]"
                },
                void 0,
                false,
                {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 2172,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 2170,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-medium text-[#4a5568]", children: "5. Physical Address / Map Location" }, void 0, false, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 2181,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  value: businessProfile.physicalAddress,
                  onChange: (e) => setBusinessProfile({ ...businessProfile, physicalAddress: e.target.value }),
                  className: "w-full bg-[#fdfbf7] border border-[#e5e0d8] rounded-xl px-4 py-2.5 text-sm text-[#2d3748]"
                },
                void 0,
                false,
                {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 2182,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 2180,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-medium text-[#4a5568]", children: "6. Service Area" }, void 0, false, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 2191,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  value: businessProfile.serviceArea,
                  onChange: (e) => setBusinessProfile({ ...businessProfile, serviceArea: e.target.value }),
                  className: "w-full bg-[#fdfbf7] border border-[#e5e0d8] rounded-xl px-4 py-2.5 text-sm text-[#2d3748]"
                },
                void 0,
                false,
                {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 2192,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 2190,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-medium text-[#4a5568]", children: "7. Business Hours" }, void 0, false, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 2201,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  value: businessProfile.businessHours,
                  onChange: (e) => setBusinessProfile({ ...businessProfile, businessHours: e.target.value }),
                  className: "w-full bg-[#fdfbf7] border border-[#e5e0d8] rounded-xl px-4 py-2.5 text-sm text-[#2d3748]"
                },
                void 0,
                false,
                {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 2202,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 2200,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-medium text-[#4a5568]", children: "8. Websites (URLs)" }, void 0, false, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 2211,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  value: businessProfile.websites,
                  onChange: (e) => setBusinessProfile({ ...businessProfile, websites: e.target.value }),
                  className: "w-full bg-[#fdfbf7] border border-[#e5e0d8] rounded-xl px-4 py-2.5 text-sm text-[#2d3748]"
                },
                void 0,
                false,
                {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 2212,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 2210,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-medium text-[#4a5568]", children: "9. Linked Social Accounts (Facebook & Instagram)" }, void 0, false, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 2221,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  value: businessProfile.facebookInstagram,
                  onChange: (e) => setBusinessProfile({ ...businessProfile, facebookInstagram: e.target.value }),
                  className: "w-full bg-[#fdfbf7] border border-[#e5e0d8] rounded-xl px-4 py-2.5 text-sm text-[#2d3748]"
                },
                void 0,
                false,
                {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 2222,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 2220,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-medium text-[#4a5568]", children: "10. Services (Payment & Parking options)" }, void 0, false, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 2231,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  value: businessProfile.paymentParkingOptions,
                  onChange: (e) => setBusinessProfile({ ...businessProfile, paymentParkingOptions: e.target.value }),
                  className: "w-full bg-[#fdfbf7] border border-[#e5e0d8] rounded-xl px-4 py-2.5 text-sm text-[#2d3748]"
                },
                void 0,
                false,
                {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 2232,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 2230,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-medium text-[#4a5568]", children: "11. About / Status Message" }, void 0, false, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 2241,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  value: businessProfile.statusMessage,
                  onChange: (e) => setBusinessProfile({ ...businessProfile, statusMessage: e.target.value }),
                  className: "w-full bg-[#fdfbf7] border border-[#e5e0d8] rounded-xl px-4 py-2.5 text-sm text-[#2d3748]"
                },
                void 0,
                false,
                {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 2242,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 2240,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 2139,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-medium text-[#4a5568]", children: "12. Business Description" }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 2252,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "textarea",
              {
                rows: 2,
                value: businessProfile.businessDescription,
                onChange: (e) => setBusinessProfile({ ...businessProfile, businessDescription: e.target.value }),
                className: "w-full bg-[#fdfbf7] border border-[#e5e0d8] rounded-xl px-4 py-2.5 text-sm text-[#2d3748]"
              },
              void 0,
              false,
              {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 2253,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 2251,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4 pt-2 border-t border-[#e5e0d8]", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-medium text-[#4a5568]", children: "13. Profile Photo" }, void 0, false, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 2264,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 bg-[#fdfbf7] border border-[#e5e0d8] rounded-xl px-4 py-2", children: [
                businessProfile.profilePhoto ? /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 flex-1 min-w-0", children: [
                  /* @__PURE__ */ jsxDEV("img", { src: businessProfile.profilePhoto, className: "w-8 h-8 rounded-full object-cover shrink-0 border border-[#e5e0d8]" }, void 0, false, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 2268,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-medium text-[#2d3748] truncate", children: "Profile Photo Active" }, void 0, false, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 2269,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      type: "button",
                      onClick: () => setBusinessProfile({ ...businessProfile, profilePhoto: "" }),
                      className: "p-1 hover:bg-red-50 text-red-500 rounded-lg transition-colors ml-auto",
                      title: "Remove Photo",
                      children: /* @__PURE__ */ jsxDEV(Trash2, { className: "w-3.5 h-3.5" }, void 0, false, {
                        fileName: "/app/applet/src/App.tsx",
                        lineNumber: 2276,
                        columnNumber: 27
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "/app/applet/src/App.tsx",
                      lineNumber: 2270,
                      columnNumber: 25
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 2267,
                  columnNumber: 19
                }, this) : /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-[#718096] truncate flex-1", children: "Select from device" }, void 0, false, {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 2280,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("label", { className: "px-4 py-2 bg-[#93b5c6] hover:bg-[#7fa5b8] text-white rounded-lg text-xs font-semibold cursor-pointer shadow-sm transition-colors flex items-center gap-2 shrink-0 select-none", children: [
                  /* @__PURE__ */ jsxDEV(UploadIcon, { className: "w-4 h-4" }, void 0, false, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 2283,
                    columnNumber: 23
                  }, this),
                  "Upload Photo",
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "file",
                      accept: "image/*",
                      onChange: (e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          const reader = new FileReader();
                          reader.onloadend = () => {
                            setBusinessProfile({ ...businessProfile, profilePhoto: reader.result });
                          };
                          reader.readAsDataURL(file);
                        }
                      },
                      className: "hidden"
                    },
                    void 0,
                    false,
                    {
                      fileName: "/app/applet/src/App.tsx",
                      lineNumber: 2285,
                      columnNumber: 23
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 2282,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 2265,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 2263,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-medium text-[#4a5568]", children: "14. Cover Photo" }, void 0, false, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 2305,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 bg-[#fdfbf7] border border-[#e5e0d8] rounded-xl px-4 py-2", children: [
                businessProfile.coverPhoto ? /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 flex-1 min-w-0", children: [
                  /* @__PURE__ */ jsxDEV("img", { src: businessProfile.coverPhoto, className: "w-12 h-8 rounded object-cover shrink-0 border border-[#e5e0d8]" }, void 0, false, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 2309,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-medium text-[#2d3748] truncate", children: "Cover Photo Active" }, void 0, false, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 2310,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      type: "button",
                      onClick: () => setBusinessProfile({ ...businessProfile, coverPhoto: "" }),
                      className: "p-1 hover:bg-red-50 text-red-500 rounded-lg transition-colors ml-auto",
                      title: "Remove Cover",
                      children: /* @__PURE__ */ jsxDEV(Trash2, { className: "w-3.5 h-3.5" }, void 0, false, {
                        fileName: "/app/applet/src/App.tsx",
                        lineNumber: 2317,
                        columnNumber: 27
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "/app/applet/src/App.tsx",
                      lineNumber: 2311,
                      columnNumber: 25
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 2308,
                  columnNumber: 19
                }, this) : /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-[#718096] truncate flex-1", children: "Select from device" }, void 0, false, {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 2321,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("label", { className: "px-4 py-2 bg-[#93b5c6] hover:bg-[#7fa5b8] text-white rounded-lg text-xs font-semibold cursor-pointer shadow-sm transition-colors flex items-center gap-2 shrink-0 select-none", children: [
                  /* @__PURE__ */ jsxDEV(UploadIcon, { className: "w-4 h-4" }, void 0, false, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 2324,
                    columnNumber: 23
                  }, this),
                  "Upload Cover",
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "file",
                      accept: "image/*",
                      onChange: (e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          const reader = new FileReader();
                          reader.onloadend = () => {
                            setBusinessProfile({ ...businessProfile, coverPhoto: reader.result });
                          };
                          reader.readAsDataURL(file);
                        }
                      },
                      className: "hidden"
                    },
                    void 0,
                    false,
                    {
                      fileName: "/app/applet/src/App.tsx",
                      lineNumber: 2326,
                      columnNumber: 23
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 2323,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 2306,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 2304,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 2262,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-3 pt-2 border-t border-[#e5e0d8]", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-bold text-[#2d3748] flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("span", { children: [
                "15. Catalog (Products & Services) — ",
                businessProfile.catalogItems.length,
                " items"
              ] }, void 0, true, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 2349,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] text-[#718096]", children: "Updated instantly in Album section" }, void 0, false, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 2350,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 2348,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: businessProfile.catalogItems.map(
              (item) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between bg-[#fdfbf7] border border-[#e5e0d8] rounded-xl p-3", children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "text-sm font-bold text-[#2d3748]", children: [
                    item.name,
                    " ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-mono text-green-700 font-semibold ml-2", children: item.price }, void 0, false, {
                      fileName: "/app/applet/src/App.tsx",
                      lineNumber: 2357,
                      columnNumber: 87
                    }, this)
                  ] }, void 0, true, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 2357,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-[#718096]", children: item.description }, void 0, false, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 2358,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 2356,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => {
                      const updated = businessProfile.catalogItems.filter((c) => c.id !== item.id);
                      setBusinessProfile({ ...businessProfile, catalogItems: updated });
                    },
                    className: "text-red-600 hover:text-red-800 p-1",
                    children: /* @__PURE__ */ jsxDEV(Trash, { className: "w-4 h-4" }, void 0, false, {
                      fileName: "/app/applet/src/App.tsx",
                      lineNumber: 2367,
                      columnNumber: 25
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 2360,
                    columnNumber: 23
                  },
                  this
                )
              ] }, item.id, true, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 2355,
                columnNumber: 17
              }, this)
            ) }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 2353,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-2 pt-2", children: [
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  placeholder: "Product/Service name",
                  value: newCatName,
                  onChange: (e) => setNewCatName(e.target.value),
                  className: "bg-[#fdfbf7] border border-[#e5e0d8] rounded-xl px-3 py-2 text-xs text-[#2d3748]"
                },
                void 0,
                false,
                {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 2374,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  placeholder: "Price (e.g. $49.99)",
                  value: newCatPrice,
                  onChange: (e) => setNewCatPrice(e.target.value),
                  className: "bg-[#fdfbf7] border border-[#e5e0d8] rounded-xl px-3 py-2 text-xs text-[#2d3748]"
                },
                void 0,
                false,
                {
                  fileName: "/app/applet/src/App.tsx",
                  lineNumber: 2381,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: [
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    placeholder: "Short description",
                    value: newCatDesc,
                    onChange: (e) => setNewCatDesc(e.target.value),
                    className: "bg-[#fdfbf7] border border-[#e5e0d8] rounded-xl px-3 py-2 text-xs text-[#2d3748] flex-1"
                  },
                  void 0,
                  false,
                  {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 2389,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => {
                      if (newCatName.trim()) {
                        const newItem = {
                          id: `cat-${Date.now()}`,
                          name: newCatName.trim(),
                          price: newCatPrice.trim() || "$0.00",
                          description: newCatDesc.trim()
                        };
                        setBusinessProfile({
                          ...businessProfile,
                          catalogItems: [...businessProfile.catalogItems, newItem]
                        });
                        setNewCatName("");
                        setNewCatPrice("");
                        setNewCatDesc("");
                      }
                    },
                    className: "px-3 py-2 bg-[#93b5c6] hover:bg-[#7fa5b8] text-white rounded-xl text-xs font-semibold shrink-0",
                    children: "Add"
                  },
                  void 0,
                  false,
                  {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 2396,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 2388,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 2373,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 2347,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "pt-4 border-t border-[#e5e0d8] flex items-center justify-between", children: [
            /* @__PURE__ */ jsxDEV("div", { children: bizSaveMsg && /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-semibold text-green-600 bg-green-50 px-3 py-1.5 rounded-lg border border-green-200", children: bizSaveMsg }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 2425,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 2423,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => {
                  setBizSaveMsg("Business Profile & Catalog saved successfully!");
                  setTimeout(() => setBizSaveMsg(""), 3e3);
                },
                className: "px-6 py-2.5 bg-[#93b5c6] hover:bg-[#7fa5b8] text-white font-semibold rounded-xl text-xs transition-colors shadow-sm flex items-center gap-2",
                children: [
                  /* @__PURE__ */ jsxDEV(Check, { className: "w-4 h-4" }, void 0, false, {
                    fileName: "/app/applet/src/App.tsx",
                    lineNumber: 2437,
                    columnNumber: 19
                  }, this),
                  "Save Business Profile"
                ]
              },
              void 0,
              true,
              {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 2430,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 2422,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/app/applet/src/App.tsx",
          lineNumber: 2121,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/app/applet/src/App.tsx",
        lineNumber: 2083,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/app/applet/src/App.tsx",
      lineNumber: 1057,
      columnNumber: 7
    }, this),
    isAddContactOpen && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 bg-[#2d3748]/60 backdrop-blur-sm z-50 flex items-center justify-center p-6", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-[#e5e0d8] rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between border-b border-[#e5e0d8] pb-3", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-bold text-[#2d3748]", children: "Connect New User" }, void 0, false, {
          fileName: "/app/applet/src/App.tsx",
          lineNumber: 2452,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setIsAddContactOpen(false),
            className: "text-[#718096] hover:text-[#2d3748]",
            children: "✕"
          },
          void 0,
          false,
          {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 2453,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/applet/src/App.tsx",
        lineNumber: 2451,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("form", { onSubmit: handleAddContact, className: "space-y-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-medium text-[#4a5568]", children: "Username or Handle" }, void 0, false, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 2462,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              value: newContactHandle,
              onChange: (e) => setNewContactHandle(e.target.value),
              placeholder: "e.g. alex_dev",
              required: true,
              className: "w-full bg-[#fdfbf7] border border-[#e5e0d8] rounded-xl px-4 py-3 text-sm text-[#2d3748] focus:outline-none focus:border-[#93b5c6]"
            },
            void 0,
            false,
            {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 2463,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/applet/src/App.tsx",
          lineNumber: 2461,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "submit",
            className: "w-full py-3 bg-[#93b5c6] hover:bg-[#7fa5b8] text-white font-semibold rounded-xl text-sm transition-colors shadow-sm",
            children: "Connect & Open Chat"
          },
          void 0,
          false,
          {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 2472,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/applet/src/App.tsx",
        lineNumber: 2460,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/app/applet/src/App.tsx",
      lineNumber: 2450,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/app/applet/src/App.tsx",
      lineNumber: 2449,
      columnNumber: 7
    }, this),
    isVideoCallActive && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 bg-[#2d3748]/60 backdrop-blur-sm z-50 flex items-center justify-center p-6", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-[#e5e0d8] rounded-3xl max-w-xl w-full p-6 space-y-4 shadow-2xl", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between border-b border-[#e5e0d8] pb-3", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-bold text-[#2d3748]", children: "Video Call" }, void 0, false, {
          fileName: "/app/applet/src/App.tsx",
          lineNumber: 2488,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setIsVideoCallActive(false),
            className: "px-4 py-1.5 bg-red-600 text-white rounded-xl text-xs font-bold",
            children: "End"
          },
          void 0,
          false,
          {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 2489,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/applet/src/App.tsx",
        lineNumber: 2487,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "h-64 bg-[#f7f5f0] rounded-2xl flex items-center justify-center text-xs text-[#718096]", children: "Secure Encrypted Video Stream Active" }, void 0, false, {
        fileName: "/app/applet/src/App.tsx",
        lineNumber: 2496,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/app/applet/src/App.tsx",
      lineNumber: 2486,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/app/applet/src/App.tsx",
      lineNumber: 2485,
      columnNumber: 7
    }, this),
    isAdminPasswordModalOpen && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 bg-[#2d3748]/60 backdrop-blur-sm z-50 flex items-center justify-center p-6", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-[#e5e0d8] rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between border-b border-[#e5e0d8] pb-3", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-bold text-[#2d3748] flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV(Shield, { className: "w-5 h-5 text-[#b91c1c]" }, void 0, false, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 2509,
            columnNumber: 17
          }, this),
          "Admin Suite Password Protection"
        ] }, void 0, true, {
          fileName: "/app/applet/src/App.tsx",
          lineNumber: 2508,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setIsAdminPasswordModalOpen(false),
            className: "text-[#718096] hover:text-[#2d3748]",
            children: "✕"
          },
          void 0,
          false,
          {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 2512,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/applet/src/App.tsx",
        lineNumber: 2507,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("form", { onSubmit: handleVerifyAdminPassword, className: "space-y-4", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-[#718096]", children: "Enter your admin security password to access the Master Admin Suite and white-label branding controls." }, void 0, false, {
          fileName: "/app/applet/src/App.tsx",
          lineNumber: 2520,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-medium text-[#4a5568]", children: "Admin Password" }, void 0, false, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 2522,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "password",
              value: adminPasswordInput,
              onChange: (e) => setAdminPasswordInput(e.target.value),
              placeholder: "Enter password (e.g. admin123)",
              required: true,
              autoFocus: true,
              className: "w-full bg-[#fdfbf7] border border-[#e5e0d8] rounded-xl px-4 py-3 text-sm text-[#2d3748] focus:outline-none focus:border-[#93b5c6]"
            },
            void 0,
            false,
            {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 2523,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/applet/src/App.tsx",
          lineNumber: 2521,
          columnNumber: 15
        }, this),
        adminPasswordError && /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-red-600 bg-red-50 p-2 rounded-lg", children: adminPasswordError }, void 0, false, {
          fileName: "/app/applet/src/App.tsx",
          lineNumber: 2534,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3 pt-2", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => setIsAdminPasswordModalOpen(false),
              className: "flex-1 py-2.5 bg-gray-100 hover:bg-gray-200 text-[#4a5568] font-semibold rounded-xl text-xs transition-colors",
              children: "Cancel"
            },
            void 0,
            false,
            {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 2537,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "submit",
              className: "flex-1 py-2.5 bg-[#b91c1c] hover:bg-[#a11616] text-white font-semibold rounded-xl text-xs transition-colors shadow-sm",
              children: "Verify & Open"
            },
            void 0,
            false,
            {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 2544,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/applet/src/App.tsx",
          lineNumber: 2536,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/app/applet/src/App.tsx",
        lineNumber: 2519,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/app/applet/src/App.tsx",
      lineNumber: 2506,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/app/applet/src/App.tsx",
      lineNumber: 2505,
      columnNumber: 7
    }, this),
    showCreateBox && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-[#1c1c1e] border border-gray-800 rounded-3xl max-w-lg w-full p-6 space-y-4 shadow-2xl animate-in fade-in zoom-in-95 duration-200", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between border-b border-gray-800 pb-3", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-sm font-bold text-white uppercase tracking-wider", children: "Create New Album / Post" }, void 0, false, {
          fileName: "/app/applet/src/App.tsx",
          lineNumber: 2561,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("button", { onClick: () => setShowCreateBox(false), className: "text-gray-400 hover:text-white text-sm", children: "✕" }, void 0, false, {
          fileName: "/app/applet/src/App.tsx",
          lineNumber: 2562,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/app/applet/src/App.tsx",
        lineNumber: 2560,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("form", { onSubmit: handleCreateAlbum, className: "space-y-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-1", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "text-xs text-gray-400", children: "Album Title" }, void 0, false, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 2566,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              value: newAlbumTitle,
              onChange: (e) => setNewAlbumTitle(e.target.value),
              placeholder: "Album Title",
              required: true,
              className: "w-full bg-black border border-gray-800 rounded-xl px-4 py-3 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-blue-500"
            },
            void 0,
            false,
            {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 2567,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/applet/src/App.tsx",
          lineNumber: 2565,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-1", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "text-xs text-gray-400", children: "Caption" }, void 0, false, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 2577,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              value: newAlbumCaption,
              onChange: (e) => setNewAlbumCaption(e.target.value),
              placeholder: "Caption",
              className: "w-full bg-black border border-gray-800 rounded-xl px-4 py-3 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-blue-500"
            },
            void 0,
            false,
            {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 2578,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/applet/src/App.tsx",
          lineNumber: 2576,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-1", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "text-xs text-gray-400", children: "Media file" }, void 0, false, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 2587,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "w-full bg-black border border-gray-800 rounded-xl px-4 py-3 text-xs text-gray-400 cursor-pointer hover:border-gray-700 transition-colors flex items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV(UploadIcon, { className: "w-4 h-4 shrink-0 text-blue-400" }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 2589,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "truncate", children: selectedFileName || "Select from device" }, void 0, false, {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 2590,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "file",
                accept: "image/*,video/*",
                onChange: handleFileChange,
                className: "hidden"
              },
              void 0,
              false,
              {
                fileName: "/app/applet/src/App.tsx",
                lineNumber: 2591,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/applet/src/App.tsx",
            lineNumber: 2588,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/app/applet/src/App.tsx",
          lineNumber: 2586,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "pt-2 flex justify-end gap-3", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => setShowCreateBox(false),
              className: "px-4 py-2.5 bg-gray-800 hover:bg-gray-700 text-white rounded-xl text-xs font-semibold",
              children: "Cancel"
            },
            void 0,
            false,
            {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 2600,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "submit",
              disabled: isCompressing,
              className: "px-6 py-2.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-semibold rounded-xl text-xs shadow-sm",
              children: isCompressing ? "Compressing..." : "Post"
            },
            void 0,
            false,
            {
              fileName: "/app/applet/src/App.tsx",
              lineNumber: 2607,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/applet/src/App.tsx",
          lineNumber: 2599,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/app/applet/src/App.tsx",
        lineNumber: 2564,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/app/applet/src/App.tsx",
      lineNumber: 2559,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/app/applet/src/App.tsx",
      lineNumber: 2558,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/app/applet/src/App.tsx",
    lineNumber: 1055,
    columnNumber: 5
  }, this);
}
_s(App, "5OMiEa2SwHZwwq9ktSvSImdfD+k=");
_c2 = App;
var _c, _c2;
$RefreshReg$(_c, "NCLogo");
$RefreshReg$(_c2, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/applet/src/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/applet/src/App.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNEhXLFNBOHVEYSxVQTl1RGI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBNUhYO0FBQUE7QUFBQTtBQUFBO0FBS0EsU0FBZ0JBLFVBQVVDLFdBQVdDLGNBQWM7QUFDbkQ7QUFBQSxFQUNpQkM7QUFBQUEsRUFBUUM7QUFBQUEsRUFBT0MsU0FBU0M7QUFBQUEsRUFBa0JDO0FBQUFBLEVBQ25CQztBQUFBQSxFQUFlQztBQUFBQSxFQUFNQztBQUFBQSxFQUMzREM7QUFBQUEsRUFBZUM7QUFBQUEsRUFBTUM7QUFBQUEsRUFBa0JDO0FBQUFBLEVBQ3RCQztBQUFBQSxFQUFnQkM7QUFBQUEsRUFDakNDO0FBQUFBLEVBQTBDQztBQUFBQSxFQUFVQztBQUFBQSxFQUFXQztBQUFBQSxFQUMvREM7QUFBQUEsRUFBUUM7QUFBQUEsRUFBOENDO0FBQUFBLEVBQStCQztBQUFBQSxFQUFVQyxVQUFVQztBQUFBQSxFQUNoR0M7QUFBQUEsRUFBd0JDO0FBQUFBLEVBQVFDO0FBQUFBLEVBQVVDO0FBQUFBLEVBQU1DO0FBQUFBLEVBQW1CQztBQUFBQSxFQUFhQztBQUFBQSxPQUNwRjtBQUNQLE9BQU9DLFdBQVc7QUFrRmxCLFNBQVNDLDhCQUE4QkMsU0FBMEI7QUFDL0QsUUFBTUMsU0FBUztBQUFBLElBQ2JELFFBQVFFO0FBQUFBLElBQ1JGLFFBQVFHO0FBQUFBLElBQ1JILFFBQVFJO0FBQUFBLElBQ1JKLFFBQVFLO0FBQUFBLElBQ1JMLFFBQVFNO0FBQUFBLElBQ1JOLFFBQVFPO0FBQUFBLElBQ1JQLFFBQVFRO0FBQUFBLElBQ1JSLFFBQVFTO0FBQUFBLElBQ1JULFFBQVFVO0FBQUFBLElBQ1JWLFFBQVFXO0FBQUFBLElBQ1JYLFFBQVFZO0FBQUFBLElBQ1JaLFFBQVFhO0FBQUFBLElBQ1JiLFFBQVFjLGFBQWFDLFNBQVMsSUFBSSxRQUFRO0FBQUEsSUFDMUNmLFFBQVFnQjtBQUFBQSxJQUNSaEIsUUFBUWlCO0FBQUFBLEVBQWE7QUFFdkIsUUFBTUMsY0FBY2pCLE9BQU9rQixPQUFPLENBQUFDLE1BQUtBLEtBQUssT0FBT0EsTUFBTSxZQUFZQSxFQUFFQyxLQUFLLE1BQU0sRUFBRSxFQUFFTjtBQUN0RixRQUFNTyxRQUFRQyxLQUFLQyxNQUFPTixjQUFjLEtBQU0sR0FBRztBQUNqRCxTQUFPLEVBQUVJLE9BQU9HLFlBQVlILFNBQVMsSUFBSUosWUFBWTtBQUN2RDtBQUdBLFNBQVNRLE9BQU8sRUFBRUMsT0FBTyxNQUFNQyxRQUF5RCxHQUFHO0FBQ3pGLE1BQUlBLFNBQVM7QUFDWCxVQUFNQyxPQUFNRixTQUFTLE9BQU8sWUFBWUEsU0FBUyxPQUFPLGNBQWM7QUFDdEUsV0FBTyx1QkFBQyxTQUFJLEtBQUtDLFNBQVMsS0FBSSxRQUFPLFdBQVcsR0FBR0MsSUFBRyx3Q0FBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvRjtBQUFBLEVBQzdGO0FBRUEsTUFBSUYsU0FBUyxNQUFNO0FBQ2pCLFdBQ0UsdUJBQUMsU0FBSSxXQUFVLDhGQUNiO0FBQUEsNkJBQUMsVUFBSyxXQUFVLHVEQUFzRCxrQkFBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3RTtBQUFBLE1BQ3hFLHVCQUFDLFVBQUssV0FBVSx3REFBdUQseUJBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0Y7QUFBQSxTQUZsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxFQUVKO0FBQ0EsUUFBTUUsTUFBTUYsU0FBUyxPQUFPLG9CQUFvQjtBQUNoRCxTQUNFLHVCQUFDLFNBQUksV0FBVyxHQUFHRSxHQUFHLDhIQUE2SCxrQkFBbko7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVBO0FBRUo7QUFBQ0MsS0FwQlFKO0FBc0JULHdCQUF3QkssTUFBTTtBQUFBQyxLQUFBO0FBRTVCLFFBQU0sQ0FBQ0MsYUFBYUMsY0FBYyxJQUFJdEUsU0FBc0IsSUFBSTtBQUNoRSxRQUFNLENBQUN1RSxVQUFVQyxXQUFXLElBQUl4RSxTQUEyRCxPQUFPO0FBR2xHLFFBQU0sQ0FBQ3lFLGVBQWVDLGdCQUFnQixJQUFJMUUsU0FBUyxFQUFFO0FBQ3JELFFBQU0sQ0FBQzJFLFlBQVlDLGFBQWEsSUFBSTVFLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUM2RSxhQUFhQyxjQUFjLElBQUk5RSxTQUFTLEVBQUU7QUFDakQsUUFBTSxDQUFDK0UsZUFBZUMsZ0JBQWdCLElBQUloRixTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDaUYsWUFBWUMsYUFBYSxJQUFJbEYsU0FBU21GLFVBQVVDLFVBQVVDLFNBQVMsS0FBSyxJQUFJLG1CQUFtQixtQkFBbUI7QUFDekgsUUFBTSxDQUFDQyxhQUFhQyxjQUFjLElBQUl2RixTQUFTLCtCQUErQjtBQUM5RSxRQUFNLENBQUN3RixXQUFXQyxZQUFZLElBQUl6RixTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDMEYsYUFBYUMsY0FBYyxJQUFJM0YsU0FBUyxFQUFFO0FBR2pELFFBQU0sQ0FBQzRGLGVBQWVDLGdCQUFnQixJQUFJN0YsU0FBUyxFQUFFO0FBQ3JELFFBQU0sQ0FBQzhGLGtCQUFrQkMsbUJBQW1CLElBQUkvRixTQUFTLEVBQUU7QUFDM0QsUUFBTSxDQUFDZ0csZUFBZUMsZ0JBQWdCLElBQUlqRyxTQUFTLEVBQUU7QUFHckQsUUFBTSxDQUFDa0csc0JBQXNCQyx1QkFBdUIsSUFBSW5HLFNBQVMsRUFBRTtBQUNuRSxRQUFNLENBQUNvRyxzQkFBc0JDLHVCQUF1QixJQUFJckcsU0FBUyxFQUFFO0FBQ25FLFFBQU0sQ0FBQ3NHLG1CQUFtQkMsb0JBQW9CLElBQUl2RyxTQUFTLEVBQUU7QUFHN0QsUUFBTSxDQUFDd0csV0FBV0MsWUFBWSxJQUFJekcsU0FBc0UsTUFBTTtBQUc5RyxRQUFNLENBQUMwRyxVQUFVQyxXQUFXLElBQUkzRztBQUFBQSxJQUFvQjtBQUFBLE1BQ2xELEVBQUU0RyxJQUFJLGVBQWVDLE1BQU0sY0FBY0MsUUFBUSxlQUFlQyxVQUFVLGdCQUFnQkMsYUFBYSx1Q0FBdUNDLFdBQVcsWUFBWUMsYUFBYSxHQUFHQyxRQUFRLEtBQUs7QUFBQSxNQUNsTSxFQUFFUCxJQUFJLGlCQUFpQkMsTUFBTSx5QkFBeUJDLFFBQVEsY0FBY0MsVUFBVSxnQkFBZ0JDLGFBQWEseUNBQXlDQyxXQUFXLFlBQVlFLFFBQVEsS0FBSztBQUFBLE1BQ2hNLEVBQUVQLElBQUksZ0JBQWdCQyxNQUFNLDBCQUEwQkMsUUFBUSxZQUFZQyxVQUFVLGdCQUFnQkMsYUFBYSwrREFBK0RDLFdBQVcsWUFBWUUsUUFBUSxNQUFNO0FBQUEsSUFBQztBQUFBLEVBQ3ZOO0FBQ0QsUUFBTSxDQUFDQyxlQUFlQyxnQkFBZ0IsSUFBSXJILFNBQXlCLElBQUk7QUFDdkUsUUFBTSxDQUFDc0gsYUFBYUMsY0FBYyxJQUFJdkgsU0FBUyxFQUFFO0FBQ2pELFFBQU0sQ0FBQ3dILGtCQUFrQkMsbUJBQW1CLElBQUl6SCxTQUFTLEtBQUs7QUFDOUQsUUFBTSxDQUFDMEgsa0JBQWtCQyxtQkFBbUIsSUFBSTNILFNBQVMsRUFBRTtBQUczRCxRQUFNLENBQUM0SCxrQkFBa0JDLG1CQUFtQixJQUFJN0gsU0FBUyxHQUFHO0FBQzVELFFBQU0sQ0FBQzhILGlCQUFpQixJQUFJOUgsU0FBUyxFQUFJO0FBQ3pDLFFBQU0sQ0FBQytILFlBQVlDLGFBQWEsSUFBSWhJO0FBQUFBLElBQXNCO0FBQUEsTUFDeEQsRUFBRTRHLElBQUksUUFBUUMsTUFBTSxpQ0FBaUM5QyxNQUFNLFVBQVVrRSxhQUFhLG1CQUFtQkMsTUFBTSxTQUFTO0FBQUEsTUFDcEgsRUFBRXRCLElBQUksUUFBUUMsTUFBTSxvQ0FBb0M5QyxNQUFNLFVBQVVrRSxhQUFhLGFBQWFDLE1BQU0sUUFBUTtBQUFBLE1BQ2hILEVBQUV0QixJQUFJLFFBQVFDLE1BQU0saUNBQWlDOUMsTUFBTSxXQUFXa0UsYUFBYSxjQUFjQyxNQUFNLFFBQVE7QUFBQSxNQUMvRyxFQUFFdEIsSUFBSSxRQUFRQyxNQUFNLGlDQUFpQzlDLE1BQU0sVUFBVWtFLGFBQWEsY0FBY0MsTUFBTSxPQUFPO0FBQUEsTUFDN0csRUFBRXRCLElBQUksUUFBUUMsTUFBTSwwQkFBMEI5QyxNQUFNLFVBQVVrRSxhQUFhLGFBQWFDLE1BQU0sUUFBUTtBQUFBLElBQUM7QUFBQSxFQUN4RztBQUNELFFBQU0sQ0FBQ0Msc0JBQXNCQyx1QkFBdUIsSUFBSXBJLFNBQXdCLElBQUk7QUFDcEYsUUFBTSxDQUFDcUksaUJBQWlCQyxrQkFBa0IsSUFBSXRJLFNBQVMsRUFBRTtBQUd6RCxRQUFNLENBQUN1SSxVQUFVQyxXQUFXLElBQUl4SSxTQUFvQztBQUFBLElBQ2xFLGVBQWU7QUFBQSxNQUNiLEVBQUU0RyxJQUFJLEtBQUs2QixRQUFRLGNBQWNDLFNBQVMsdUNBQXVDekIsV0FBVyxZQUFZMEIsUUFBUSxLQUFLO0FBQUEsSUFBQztBQUFBLElBRXhILGlCQUFpQjtBQUFBLE1BQ2YsRUFBRS9CLElBQUksS0FBSzZCLFFBQVEseUJBQXlCQyxTQUFTLHlDQUF5Q3pCLFdBQVcsWUFBWTBCLFFBQVEsS0FBSztBQUFBLElBQUM7QUFBQSxJQUVySSxnQkFBZ0I7QUFBQSxNQUNkLEVBQUUvQixJQUFJLEtBQUs2QixRQUFRLFdBQVdDLFNBQVMsK0RBQStEekIsV0FBVyxZQUFZMEIsUUFBUSxLQUFLO0FBQUEsSUFBQztBQUFBLEVBRS9JLENBQUM7QUFDRCxRQUFNLENBQUNDLFdBQVdDLFlBQVksSUFBSTdJLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUM4SSxtQkFBbUJDLG9CQUFvQixJQUFJL0ksU0FBaUIsQ0FBQztBQUNwRSxRQUFNLENBQUNnSixtQkFBbUJDLG9CQUFvQixJQUFJakosU0FBUyxLQUFLO0FBQ2hFLFFBQU0sQ0FBQ2tKLGdCQUFnQkMsaUJBQWlCLElBQUluSixTQUFTLEtBQUs7QUFDMUQsUUFBTSxDQUFDb0osZUFBZUMsZ0JBQWdCLElBQUlySixTQUFTLEtBQUs7QUFDeEQsUUFBTSxDQUFDc0osb0JBQW9CQyxxQkFBcUIsSUFBSXZKLFNBQVMsS0FBSztBQUdsRSxRQUFNLENBQUN3SixRQUFRQyxTQUFTLElBQUl6SixTQUFrQixFQUFFO0FBQ2hELFFBQU0sQ0FBQzBKLGVBQWVDLGdCQUFnQixJQUFJM0osU0FBUyxFQUFFO0FBQ3JELFFBQU0sQ0FBQzRKLGlCQUFpQkMsa0JBQWtCLElBQUk3SixTQUFTLEVBQUU7QUFDekQsUUFBTSxDQUFDOEoscUJBQXFCQyxzQkFBc0IsSUFBSS9KLFNBQWlCLEVBQUU7QUFDekUsUUFBTSxDQUFDZ0ssa0JBQWtCQyxtQkFBbUIsSUFBSWpLLFNBQWlCLEVBQUU7QUFDbkUsUUFBTSxDQUFDa0ssY0FBY0MsZUFBZSxJQUFJbkssU0FBaUIsRUFBRTtBQUMzRCxRQUFNLENBQUNvSyxlQUFlQyxnQkFBZ0IsSUFBSXJLLFNBQWlDLENBQUMsQ0FBQztBQUM3RSxRQUFNLENBQUNzSyxlQUFlQyxnQkFBZ0IsSUFBSXZLLFNBQVMsS0FBSztBQUN4RCxRQUFNLENBQUN3SyxZQUFZQyxhQUFhLElBQUl6SyxTQUFrQyxDQUFDLENBQUM7QUFDeEUsUUFBTSxDQUFDMEssZUFBZUMsZ0JBQWdCLElBQUkzSyxTQUE0RixDQUFDLENBQUM7QUFDeEksUUFBTSxDQUFDNEssa0JBQWtCQyxtQkFBbUIsSUFBSTdLLFNBQWlDLENBQUMsQ0FBQztBQUNuRixRQUFNLENBQUM4SyxxQkFBcUJDLHNCQUFzQixJQUFJL0ssU0FBd0IsSUFBSTtBQUNsRixRQUFNLENBQUNnTCxnQkFBZ0JDLGlCQUFpQixJQUFJakwsU0FBaUMsQ0FBQyxDQUFDO0FBQy9FLFFBQU0sQ0FBQ2tMLGtCQUFrQkMsbUJBQW1CLElBQUluTCxTQUE0QixNQUFNO0FBQ2xGLFFBQU0sQ0FBQ29MLFdBQVdDLFlBQVksSUFBSXJMLFNBQThDLGdCQUFnQjtBQUNoRyxRQUFNLENBQUNzTCxlQUFlQyxnQkFBZ0IsSUFBSXZMLFNBQVMsS0FBSztBQUN4RCxRQUFNLENBQUN3TCxhQUFhQyxjQUFjLElBQUl6TCxTQUFrQyxDQUFDLENBQUM7QUFDMUUsUUFBTTBMLGdCQUFnQnhMLE9BQTRCLENBQUMsQ0FBQztBQUdwRCxRQUFNLENBQUN5TCxZQUFZQyxhQUFhLElBQUk1TCxTQUFTO0FBQUEsSUFDM0M2TCxRQUFRO0FBQUEsSUFDUkMsVUFBVTtBQUFBLElBQ1ZDLEtBQUs7QUFBQSxJQUNMQyxhQUFhO0FBQUEsSUFDYkMsaUJBQWlCO0FBQUEsSUFDakJDLFVBQVU7QUFBQSxJQUNWQyxZQUFZO0FBQUEsSUFDWkMsWUFBWTtBQUFBLElBQ1pDLFdBQVc7QUFBQSxJQUNYQyxXQUFXO0FBQUEsSUFDWEMsVUFBVTtBQUFBLElBQ1ZDLGdCQUFnQjtBQUFBLElBQ2hCQyxRQUFRO0FBQUEsSUFDUkMsU0FBUztBQUFBLElBQ1RDLFVBQVU7QUFBQSxJQUNWQyxTQUFTO0FBQUEsSUFDVEMsYUFBYTtBQUFBLElBQ2JDLFdBQVc7QUFBQSxJQUNYQyxPQUFPO0FBQUEsRUFDVCxDQUFDO0FBQ0QsUUFBTSxDQUFDQyxrQkFBa0JDLG1CQUFtQixJQUFJak4sU0FBUyxFQUFFO0FBRzNELFFBQU0sQ0FBQ2tOLFlBQVlDLGFBQWEsSUFBSW5OO0FBQUFBLElBQWlCO0FBQUEsTUFDbkQsRUFBRTRHLElBQUksT0FBT3dHLFVBQVUsV0FBV0MsT0FBTyw2QkFBNkJDLFFBQVEsZUFBZUMsUUFBUSxrQkFBa0JqSSxhQUFhLHFCQUFxQmtJLFNBQVMsTUFBTUMsZUFBZSxLQUFLO0FBQUEsTUFDNUwsRUFBRTdHLElBQUksT0FBT3dHLFVBQVUsV0FBV0MsT0FBTyxzQkFBc0JDLFFBQVEsZUFBZUMsUUFBUSxnQkFBZ0JqSSxhQUFhLGdCQUFnQmtJLFNBQVMsTUFBTUMsZUFBZSxNQUFNO0FBQUEsTUFDL0ssRUFBRTdHLElBQUksT0FBT3dHLFVBQVUsWUFBWUMsT0FBTyxvQkFBb0JDLFFBQVEsZUFBZUMsUUFBUSxxQkFBcUJqSSxhQUFhLGNBQWNrSSxTQUFTLE9BQU9DLGVBQWUsTUFBTTtBQUFBLElBQUM7QUFBQSxFQUNwTDtBQUNELFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJM047QUFBQUEsSUFBZ0I7QUFBQSxNQUM5QyxFQUFFNEcsSUFBSSxPQUFPZ0gsUUFBUSxzQkFBc0JDLE1BQU0sV0FBV0MsTUFBTSxXQUFXO0FBQUEsTUFDN0UsRUFBRWxILElBQUksT0FBT2dILFFBQVEsMkJBQTJCQyxNQUFNLGNBQWNDLE1BQU0sV0FBVztBQUFBLElBQUM7QUFBQSxFQUN2RjtBQUNELFFBQU0sQ0FBQ0MsYUFBYUMsY0FBYyxJQUFJaE8sU0FBUztBQUFBLElBQzdDaU8sV0FBVztBQUFBLElBQ1hqSyxTQUFTO0FBQUEsSUFDVGtLLFFBQVE7QUFBQSxJQUNSQyxXQUFXO0FBQUEsSUFDWEMsV0FBVztBQUFBLElBQ1hDLGNBQWM7QUFBQTtBQUFBLEVBQ2hCLENBQUM7QUFDRCxRQUFNLENBQUNDLGNBQWNDLGVBQWUsSUFBSXZPLFNBQVMsRUFBRTtBQUNuRCxRQUFNLENBQUN3TywwQkFBMEJDLDJCQUEyQixJQUFJek8sU0FBUyxLQUFLO0FBQzlFLFFBQU0sQ0FBQzBPLG9CQUFvQkMscUJBQXFCLElBQUkzTyxTQUFTLEVBQUU7QUFDL0QsUUFBTSxDQUFDNE8sb0JBQW9CQyxxQkFBcUIsSUFBSTdPLFNBQVMsRUFBRTtBQUUvRCxRQUFNLENBQUM4TyxpQkFBaUJDLGtCQUFrQixJQUFJL08sU0FBMEI7QUFBQSxJQUN0RXNDLGNBQWM7QUFBQSxJQUNkQyxjQUFjO0FBQUEsSUFDZEMsWUFBWTtBQUFBLElBQ1pDLGtCQUFrQjtBQUFBLElBQ2xCQyxrQkFBa0I7QUFBQSxJQUNsQkMscUJBQXFCO0FBQUEsSUFDckJDLGlCQUFpQjtBQUFBLElBQ2pCQyxhQUFhO0FBQUEsSUFDYkMsZUFBZTtBQUFBLElBQ2ZDLGNBQWM7QUFBQSxJQUNkQyxVQUFVO0FBQUEsSUFDVkMsbUJBQW1CO0FBQUEsSUFDbkJDLGNBQWM7QUFBQSxNQUNaLEVBQUUwRCxJQUFJLFNBQVNDLE1BQU0sNEJBQTRCbUksT0FBTyxVQUFVQyxhQUFhLDhDQUE4QztBQUFBLE1BQzdILEVBQUVySSxJQUFJLFNBQVNDLE1BQU0sOEJBQThCbUksT0FBTyxhQUFhQyxhQUFhLG1DQUFtQztBQUFBLElBQUM7QUFBQSxJQUUxSEMsWUFBWTtBQUFBLElBQ1o5TCx1QkFBdUI7QUFBQSxJQUN2QkMsZUFBZTtBQUFBLEVBQ2pCLENBQUM7QUFDRCxRQUFNLENBQUM4TCxZQUFZQyxhQUFhLElBQUlwUCxTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDcVAsYUFBYUMsY0FBYyxJQUFJdFAsU0FBUyxFQUFFO0FBQ2pELFFBQU0sQ0FBQ3VQLFlBQVlDLGFBQWEsSUFBSXhQLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUN5UCxZQUFZQyxhQUFhLElBQUkxUCxTQUFTLEVBQUU7QUFFL0NDLFlBQVUsTUFBTTtBQUNkLFFBQUlvRSxhQUFhO0FBQ2ZzTCxrQkFBWTtBQUFBLElBQ2Q7QUFBQSxFQUNGLEdBQUcsQ0FBQ3RMLFdBQVcsQ0FBQztBQUVoQixRQUFNdUwsdUJBQXVCQSxNQUFNO0FBQ2pDekcsc0JBQWtCLEtBQUs7QUFDdkJzRixnQ0FBNEIsSUFBSTtBQUNoQ0UsMEJBQXNCLEVBQUU7QUFDeEJFLDBCQUFzQixFQUFFO0FBQUEsRUFDMUI7QUFFQSxRQUFNZ0IsNEJBQTRCQSxDQUFDQyxNQUF1QjtBQUN4REEsTUFBRUMsZUFBZTtBQUNqQixRQUFJckIsbUJBQW1CakwsS0FBSyxNQUFNLGNBQWNpTCxtQkFBbUJqTCxLQUFLLE1BQU0sVUFBVWlMLG1CQUFtQmpMLEtBQUssRUFBRU4sU0FBUyxHQUFHO0FBQzVIc0wsa0NBQTRCLEtBQUs7QUFDakNoSSxtQkFBYSxPQUFPO0FBQ3BCa0ksNEJBQXNCLEVBQUU7QUFBQSxJQUMxQixPQUFPO0FBQ0xFLDRCQUFzQiw2Q0FBNkM7QUFBQSxJQUNyRTtBQUFBLEVBQ0Y7QUFFQSxRQUFNYyxjQUFjLFlBQVk7QUFDOUIsUUFBSTtBQUNGLFlBQU1LLE1BQU0sTUFBTUMsTUFBTSxhQUFhO0FBQ3JDLFlBQU1DLE9BQU8sTUFBTUYsSUFBSUUsS0FBSztBQUM1QixZQUFNQyxPQUFPQyxLQUFLQyxNQUFNSCxJQUFJO0FBQzVCLFVBQUlDLEtBQUszRyxPQUFRQyxXQUFVMEcsS0FBSzNHLE1BQU07QUFBQSxJQUN4QyxTQUFTOEcsS0FBSztBQUNaQyxjQUFRQyxNQUFNRixHQUFHO0FBQUEsSUFDbkI7QUFBQSxFQUNGO0FBRUEsUUFBTUcsaUJBQWlCLE9BQU9YLE1BQXVCO0FBQ25EQSxNQUFFQyxlQUFlO0FBQ2pCdEssaUJBQWEsRUFBRTtBQUNmLFFBQUk7QUFDRixZQUFNdUssTUFBTSxNQUFNQyxNQUFNLHNCQUFzQjtBQUFBLFFBQzVDUyxRQUFRO0FBQUEsUUFDUkMsU0FBUyxFQUFFLGdCQUFnQixtQkFBbUI7QUFBQSxRQUM5Q0MsTUFBTVIsS0FBS1MsVUFBVTtBQUFBLFVBQ25CekQsVUFBVTNJO0FBQUFBLFVBQ1Y0SSxPQUFPMUk7QUFBQUEsVUFDUDJJLFFBQVF6SSxlQUFlO0FBQUEsVUFDdkIwSSxRQUFRdEk7QUFBQUEsVUFDUks7QUFBQUEsVUFDQXdMLFVBQVUvTDtBQUFBQSxRQUNaLENBQUM7QUFBQSxNQUNILENBQUM7QUFDRCxZQUFNbUwsT0FBTyxNQUFNRixJQUFJRSxLQUFLO0FBQzVCLFVBQUlDO0FBQ0osVUFBSTtBQUNGQSxlQUFPQyxLQUFLQyxNQUFNSCxJQUFJO0FBQUEsTUFDeEIsUUFBUTtBQUNOLGNBQU0sSUFBSWEsTUFBTSxpQkFBaUJmLElBQUlnQixNQUFNLE1BQU1kLFFBQVEsa0JBQWtCLEVBQUU7QUFBQSxNQUMvRTtBQUNBLFVBQUksQ0FBQ0YsSUFBSWlCLEdBQUksT0FBTSxJQUFJRixNQUFNWixLQUFLSyxTQUFTLHFCQUFxQjtBQUVoRTdLLHFCQUFlLDJFQUEyRTtBQUMxRnVMLGlCQUFXLE1BQU07QUFDZjFNLG9CQUFZLE9BQU87QUFDbkJtQix1QkFBZSxFQUFFO0FBQUEsTUFDbkIsR0FBRyxJQUFJO0FBQUEsSUFDVCxTQUFTMkssS0FBVTtBQUNqQjdLLG1CQUFhNkssSUFBSWEsV0FBVyxxQkFBcUI7QUFBQSxJQUNuRDtBQUFBLEVBQ0Y7QUFFQSxRQUFNQyxjQUFjLE9BQU90QixNQUF1QjtBQUNoREEsTUFBRUMsZUFBZTtBQUNqQnRLLGlCQUFhLEVBQUU7QUFDZixRQUFJO0FBQ0YsWUFBTXVLLE1BQU0sTUFBTUMsTUFBTSxtQkFBbUI7QUFBQSxRQUN6Q1MsUUFBUTtBQUFBLFFBQ1JDLFNBQVMsRUFBRSxnQkFBZ0IsbUJBQW1CO0FBQUEsUUFDOUNDLE1BQU1SLEtBQUtTLFVBQVU7QUFBQSxVQUNuQlEsaUJBQWlCNU0saUJBQWlCRTtBQUFBQSxVQUNsQ21NLFVBQVUvTDtBQUFBQSxRQUNaLENBQUM7QUFBQSxNQUNILENBQUM7QUFDRCxZQUFNbUwsT0FBTyxNQUFNRixJQUFJRSxLQUFLO0FBQzVCLFVBQUlDO0FBQ0osVUFBSTtBQUNGQSxlQUFPQyxLQUFLQyxNQUFNSCxJQUFJO0FBQUEsTUFDeEIsUUFBUTtBQUNOLGNBQU0sSUFBSWEsTUFBTSxpQkFBaUJmLElBQUlnQixNQUFNLE1BQU1kLFFBQVEsa0JBQWtCLEVBQUU7QUFBQSxNQUMvRTtBQUNBLFVBQUksQ0FBQ0YsSUFBSWlCLEdBQUksT0FBTSxJQUFJRixNQUFNWixLQUFLSyxTQUFTLGNBQWM7QUFFekRsTSxxQkFBZTZMLEtBQUt0QyxJQUFJO0FBQ3hCLFVBQUlzQyxLQUFLdEMsS0FBS0wsV0FBVzJDLEtBQUt0QyxLQUFLSixlQUFlO0FBQ2hEaEgscUJBQWEsT0FBTztBQUFBLE1BQ3RCLE9BQU87QUFDTEEscUJBQWEsTUFBTTtBQUFBLE1BQ3JCO0FBQUEsSUFDRixTQUFTNkosS0FBVTtBQUNqQjdLLG1CQUFhNkssSUFBSWEsV0FBVyxjQUFjO0FBQUEsSUFDNUM7QUFBQSxFQUNGO0FBRUEsUUFBTUcsdUJBQXVCLE9BQU94QixNQUF1QjtBQUN6REEsTUFBRUMsZUFBZTtBQUNqQnRLLGlCQUFhLEVBQUU7QUFDZixRQUFJO0FBQ0YsWUFBTXVLLE1BQU0sTUFBTUMsTUFBTSw2QkFBNkI7QUFBQSxRQUNuRFMsUUFBUTtBQUFBLFFBQ1JDLFNBQVMsRUFBRSxnQkFBZ0IsbUJBQW1CO0FBQUEsUUFDOUNDLE1BQU1SLEtBQUtTLFVBQVU7QUFBQSxVQUNuQnhELE9BQU8xSTtBQUFBQSxVQUNQNEksUUFBUXRJO0FBQUFBLFVBQ1JxSSxRQUFRekk7QUFBQUEsVUFDUlM7QUFBQUEsUUFDRixDQUFDO0FBQUEsTUFDSCxDQUFDO0FBQ0QsWUFBTTRLLE9BQU8sTUFBTUYsSUFBSUUsS0FBSztBQUM1QixVQUFJQztBQUNKLFVBQUk7QUFDRkEsZUFBT0MsS0FBS0MsTUFBTUgsSUFBSTtBQUFBLE1BQ3hCLFFBQVE7QUFDTixjQUFNLElBQUlhLE1BQU0saUJBQWlCZixJQUFJZ0IsTUFBTSxNQUFNZCxRQUFRLGtCQUFrQixFQUFFO0FBQUEsTUFDL0U7QUFDQSxVQUFJLENBQUNGLElBQUlpQixHQUFJLE9BQU0sSUFBSUYsTUFBTVosS0FBS0ssU0FBUyxxQkFBcUI7QUFFaEV2Syx1QkFBaUJrSyxLQUFLb0Isa0JBQWtCO0FBQ3hDNUwscUJBQWV3SyxLQUFLZ0IsT0FBTztBQUMzQjNNLGtCQUFZLGNBQWM7QUFBQSxJQUM1QixTQUFTOEwsS0FBVTtBQUNqQjdLLG1CQUFhNkssSUFBSWEsV0FBVyx1Q0FBdUM7QUFBQSxJQUNyRTtBQUFBLEVBQ0Y7QUFFQSxRQUFNSyw0QkFBNEIsT0FBTzFCLE1BQXVCO0FBQzlEQSxNQUFFQyxlQUFlO0FBQ2pCdEssaUJBQWEsRUFBRTtBQUNmLFFBQUk7QUFDRixZQUFNdUssTUFBTSxNQUFNQyxNQUFNLDRCQUE0QjtBQUFBLFFBQ2xEUyxRQUFRO0FBQUEsUUFDUkMsU0FBUyxFQUFFLGdCQUFnQixtQkFBbUI7QUFBQSxRQUM5Q0MsTUFBTVIsS0FBS1MsVUFBVTtBQUFBLFVBQ25CeEQsT0FBTzFJO0FBQUFBLFVBQ1A4TSxVQUFVN0w7QUFBQUEsVUFDVjhMLGFBQWE1TDtBQUFBQSxRQUNmLENBQUM7QUFBQSxNQUNILENBQUM7QUFDRCxZQUFNb0ssT0FBTyxNQUFNRixJQUFJRSxLQUFLO0FBQzVCLFVBQUlDO0FBQ0osVUFBSTtBQUNGQSxlQUFPQyxLQUFLQyxNQUFNSCxJQUFJO0FBQUEsTUFDeEIsUUFBUTtBQUNOLGNBQU0sSUFBSWEsTUFBTSxpQkFBaUJmLElBQUlnQixNQUFNLE1BQU1kLFFBQVEsa0JBQWtCLEVBQUU7QUFBQSxNQUMvRTtBQUNBLFVBQUksQ0FBQ0YsSUFBSWlCLEdBQUksT0FBTSxJQUFJRixNQUFNWixLQUFLSyxTQUFTLGNBQWM7QUFFekQ3SyxxQkFBZSw0Q0FBNEM7QUFDM0RuQixrQkFBWSxPQUFPO0FBQ25CUSx1QkFBaUIsRUFBRTtBQUNuQmEsdUJBQWlCLEVBQUU7QUFDbkJFLDBCQUFvQixFQUFFO0FBQUEsSUFDeEIsU0FBU3VLLEtBQVU7QUFDakI3SyxtQkFBYTZLLElBQUlhLFdBQVcsY0FBYztBQUFBLElBQzVDO0FBQUEsRUFDRjtBQUdBLFFBQU1RLG9CQUFvQkEsQ0FBQzdCLE1BQXVCO0FBQ2hEQSxNQUFFQyxlQUFlO0FBQ2pCLFFBQUksQ0FBQ25ILFVBQVVuRixLQUFLLEtBQUssQ0FBQ1ksZUFBZSxDQUFDK0MsY0FBZTtBQUV6RCxRQUFJUSxvQkFBb0JFLG9CQUFvQixLQUFLO0FBQy9DUSx5QkFBbUIsdUhBQXVIO0FBQzFJO0FBQUEsSUFDRjtBQUVBLFVBQU1zSixjQUFjaEo7QUFDcEJDLGlCQUFhLEVBQUU7QUFDZmdKLG9CQUFnQixTQUFTO0FBQ3pCLFVBQU1DLFdBQVUsb0JBQUlDLEtBQUssR0FBRUMsbUJBQW1CLElBQUksRUFBRUMsTUFBTSxXQUFXQyxRQUFRLFVBQVUsQ0FBQztBQUV4RixVQUFNQyxTQUFrQjtBQUFBLE1BQ3RCdkwsSUFBSW1MLEtBQUtLLElBQUksRUFBRUMsU0FBUztBQUFBLE1BQ3hCNUosUUFBUXBFLFlBQVkrSTtBQUFBQSxNQUNwQjFFLFNBQVNrSjtBQUFBQSxNQUNUM0ssV0FBVzZLO0FBQUFBLE1BQ1huSixRQUFRO0FBQUEsSUFDVjtBQUVBLFVBQU0ySixZQUFZbEwsY0FBY1I7QUFDaEM0QixnQkFBWSxDQUFBK0osVUFBUztBQUFBLE1BQ25CLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ0QsU0FBUyxHQUFHLENBQUMsR0FBSUMsS0FBS0QsU0FBUyxLQUFLLElBQUtILE1BQU07QUFBQSxJQUNsRCxFQUFFO0FBR0Z4TCxnQkFBWSxDQUFBNEwsU0FBUUEsS0FBS0MsSUFBSSxDQUFBQyxNQUFLQSxFQUFFN0wsT0FBTzBMLFlBQVksRUFBRSxHQUFHRyxHQUFHekwsYUFBYTRLLGFBQWEzSyxXQUFXNkssUUFBUSxJQUFJVyxDQUFDLENBQUM7QUFFbEg1Syx3QkFBb0IsQ0FBQTBLLFNBQVFHLFFBQVFILE9BQU8sTUFBTUksUUFBUSxDQUFDLENBQUMsQ0FBQztBQUU1RCxRQUFJN0osb0JBQW9CLEdBQUc7QUFDekJvSSxpQkFBVyxNQUFNO0FBQ2YxSSxvQkFBWSxDQUFBK0osVUFBUztBQUFBLFVBQ25CLEdBQUdBO0FBQUFBLFVBQ0gsQ0FBQ0QsU0FBUyxJQUFJQyxLQUFLRCxTQUFTLEtBQUssSUFBSS9PLE9BQU8sQ0FBQXFQLE1BQUtBLEVBQUVoTSxPQUFPdUwsT0FBT3ZMLEVBQUU7QUFBQSxRQUNyRSxFQUFFO0FBQUEsTUFDSixHQUFHa0Msb0JBQW9CLEdBQUk7QUFBQSxJQUM3QjtBQUFBLEVBQ0Y7QUFFQSxRQUFNK0osbUJBQW1CQSxDQUFDL0MsTUFBdUI7QUFDL0NBLE1BQUVDLGVBQWU7QUFDakIsUUFBSSxDQUFDckksaUJBQWlCakUsS0FBSyxFQUFHO0FBQzlCLFVBQU1vRCxPQUFPYSxpQkFBaUJvTCxXQUFXLEdBQUcsSUFBSXBMLGlCQUFpQnFMLE1BQU0sQ0FBQyxJQUFJckw7QUFDNUUsVUFBTXNMLGFBQXNCO0FBQUEsTUFDMUJwTSxJQUFJLFdBQVdtTCxLQUFLSyxJQUFJLENBQUM7QUFBQSxNQUN6QnZMO0FBQUFBLE1BQ0FDLFFBQVEsSUFBSUQsSUFBSTtBQUFBLE1BQ2hCRSxVQUFVO0FBQUEsTUFDVkMsYUFBYTtBQUFBLE1BQ2JDLFdBQVc7QUFBQSxNQUNYRSxRQUFRO0FBQUEsSUFDVjtBQUNBUixnQkFBWSxDQUFBNEwsU0FBUSxDQUFDUyxZQUFZLEdBQUdULElBQUksQ0FBQztBQUN6Qy9KLGdCQUFZLENBQUErSixVQUFTO0FBQUEsTUFDbkIsR0FBR0E7QUFBQUEsTUFDSCxDQUFDUyxXQUFXcE0sRUFBRSxHQUFHO0FBQUEsUUFDZixFQUFFQSxJQUFJLEtBQUs2QixRQUFRNUIsTUFBTTZCLFNBQVMsdUNBQXVDekIsV0FBVyxZQUFZMEIsUUFBUSxLQUFLO0FBQUEsTUFBQztBQUFBLElBRWxILEVBQUU7QUFDRmhCLHdCQUFvQixFQUFFO0FBQ3RCRix3QkFBb0IsS0FBSztBQUFBLEVBQzNCO0FBRUEsUUFBTXdMLG1CQUFtQkEsQ0FBQ25ELE1BQTJDO0FBQ25FLFVBQU1vRCxPQUFPcEQsRUFBRXFELE9BQU9DLFFBQVEsQ0FBQztBQUMvQixRQUFJRixNQUFNO0FBQ1JqSiwwQkFBb0JpSixLQUFLck0sSUFBSTtBQUM3QixZQUFNd00sU0FBUyxJQUFJQyxXQUFXO0FBQzlCRCxhQUFPRSxZQUFZLE1BQU07QUFDdkJ4SiwrQkFBdUJzSixPQUFPRyxNQUFnQjtBQUFBLE1BQ2hEO0FBQ0FILGFBQU9JLGNBQWNQLElBQUk7QUFBQSxJQUMzQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNUSxvQkFBb0IsT0FBTzVELE1BQXVCO0FBQ3REQSxNQUFFQyxlQUFlO0FBQ2pCLFFBQUksQ0FBQzFMLGVBQWUsQ0FBQ3FGLGNBQWU7QUFFcEMsUUFBSTlCLG9CQUFvQkUsb0JBQW9CLEtBQUs7QUFDL0NRLHlCQUFtQixxSEFBcUg7QUFDeEk7QUFBQSxJQUNGO0FBRUFpQyxxQkFBaUIsSUFBSTtBQUNyQixRQUFJO0FBQ0YsWUFBTXlGLE1BQU0sTUFBTUMsTUFBTSxlQUFlO0FBQUEsUUFDckNTLFFBQVE7QUFBQSxRQUNSQyxTQUFTLEVBQUUsZ0JBQWdCLG1CQUFtQjtBQUFBLFFBQzlDQyxNQUFNUixLQUFLUyxVQUFVO0FBQUEsVUFDbkI4QyxRQUFRdFAsWUFBWStJO0FBQUFBLFVBQ3BCd0csWUFBWXZQLFlBQVkrSTtBQUFBQSxVQUN4QnlHLE9BQU9uSztBQUFBQSxVQUNQb0ssU0FBU2xLLGtCQUFrQjtBQUFBLFVBQzNCbUssVUFBVWpLLHVCQUF1QjtBQUFBLFFBQ25DLENBQUM7QUFBQSxNQUNILENBQUM7QUFDRCxZQUFNb0csT0FBTyxNQUFNRixJQUFJRSxLQUFLO0FBQzVCLFVBQUlDO0FBQ0osVUFBSTtBQUNGQSxlQUFPQyxLQUFLQyxNQUFNSCxJQUFJO0FBQUEsTUFDeEIsUUFBUTtBQUNOLGNBQU0sSUFBSWEsTUFBTSxpQkFBaUJmLElBQUlnQixNQUFNLE1BQU1kLFFBQVEsa0JBQWtCLEVBQUU7QUFBQSxNQUMvRTtBQUVBLFVBQUksQ0FBQ0YsSUFBSWlCLEdBQUksT0FBTSxJQUFJRixNQUFNWixLQUFLSyxTQUFTLHdCQUF3QjtBQUVuRSxVQUFJTCxLQUFLNkQsU0FBUztBQUNoQnZLLGtCQUFVLENBQUE4SSxTQUFRLENBQUNwQyxLQUFLOEQsT0FBTyxHQUFHMUIsSUFBSSxDQUFDO0FBQ3ZDNUkseUJBQWlCLEVBQUU7QUFDbkJFLDJCQUFtQixFQUFFO0FBQ3JCRSwrQkFBdUIsRUFBRTtBQUN6QkUsNEJBQW9CLEVBQUU7QUFDdEJzQix5QkFBaUIsS0FBSztBQUN0QjFELDRCQUFvQixDQUFBMEssU0FBUUcsUUFBUUgsT0FBTyxNQUFNSSxRQUFRLENBQUMsQ0FBQyxDQUFDO0FBQzVEM0s7QUFBQUEsVUFBYyxDQUFBdUssU0FBUTtBQUFBLFlBQ3BCLEVBQUUzTCxJQUFJLE1BQU1tTCxLQUFLSyxJQUFJLENBQUMsSUFBSXZMLE1BQU0sR0FBRzZDLGFBQWEsd0JBQXdCM0YsTUFBTSxVQUFVa0UsYUFBYSxZQUFZQyxNQUFNLFFBQVE7QUFBQSxZQUMvSCxHQUFHcUs7QUFBQUEsVUFBSTtBQUFBLFFBQ1I7QUFDRDJCLGNBQU0sMkRBQTJEO0FBQUEsTUFDbkU7QUFBQSxJQUNGLFNBQVM1RCxLQUFVO0FBQ2pCNEQsWUFBTTVELElBQUlhLFdBQVcsd0JBQXdCO0FBQUEsSUFDL0MsVUFBQztBQUNDNUcsdUJBQWlCLEtBQUs7QUFBQSxJQUN4QjtBQUFBLEVBQ0Y7QUFFQSxRQUFNNEosa0JBQWtCLE9BQU92TixPQUFlO0FBQzVDLFFBQUk7QUFDRixZQUFNb0osTUFBTSxNQUFNQyxNQUFNLGVBQWVySixFQUFFLFNBQVMsRUFBRThKLFFBQVEsT0FBTyxDQUFDO0FBQ3BFLFlBQU1SLE9BQU8sTUFBTUYsSUFBSUUsS0FBSztBQUM1QixZQUFNQyxPQUFPQyxLQUFLQyxNQUFNSCxJQUFJO0FBQzVCLFVBQUlDLEtBQUs2RCxTQUFTO0FBQ2hCdkssa0JBQVUsQ0FBQThJLFNBQVFBLEtBQUtDLElBQUksQ0FBQTRCLE1BQUtBLEVBQUV4TixPQUFPQSxLQUFLLEVBQUUsR0FBR3dOLEdBQUdDLE9BQU9sRSxLQUFLa0UsTUFBTSxJQUFJRCxDQUFDLENBQUM7QUFBQSxNQUNoRjtBQUFBLElBQ0YsU0FBUzlELEtBQUs7QUFDWkMsY0FBUUMsTUFBTUYsR0FBRztBQUFBLElBQ25CO0FBQUEsRUFDRjtBQUVBLFFBQU1nRSxxQkFBcUIsT0FBTzFOLElBQVlrSixNQUF1QjtBQUNuRUEsTUFBRUMsZUFBZTtBQUNqQixVQUFNd0UsWUFBWW5LLGNBQWN4RCxFQUFFO0FBQ2xDLFFBQUksQ0FBQzJOLGFBQWEsQ0FBQ2xRLFlBQWE7QUFFaEMsUUFBSTtBQUNGLFlBQU0yTCxNQUFNLE1BQU1DLE1BQU0sZUFBZXJKLEVBQUUsWUFBWTtBQUFBLFFBQ25EOEosUUFBUTtBQUFBLFFBQ1JDLFNBQVMsRUFBRSxnQkFBZ0IsbUJBQW1CO0FBQUEsUUFDOUNDLE1BQU1SLEtBQUtTLFVBQVUsRUFBRThDLFFBQVF0UCxZQUFZK0ksVUFBVThDLE1BQU1xRSxVQUFVLENBQUM7QUFBQSxNQUN4RSxDQUFDO0FBQ0QsWUFBTXJFLE9BQU8sTUFBTUYsSUFBSUUsS0FBSztBQUM1QixZQUFNQyxPQUFPQyxLQUFLQyxNQUFNSCxJQUFJO0FBQzVCLFVBQUlDLEtBQUs2RCxTQUFTO0FBQ2hCdkssa0JBQVUsQ0FBQThJLFNBQVFBLEtBQUtDLElBQUksQ0FBQTRCLE1BQUtBLEVBQUV4TixPQUFPQSxLQUFLLEVBQUUsR0FBR3dOLEdBQUdJLFVBQVVyRSxLQUFLcUUsU0FBUyxJQUFJSixDQUFDLENBQUM7QUFDcEYvSix5QkFBaUIsQ0FBQWtJLFVBQVMsRUFBRSxHQUFHQSxNQUFNLENBQUMzTCxFQUFFLEdBQUcsR0FBRyxFQUFFO0FBQUEsTUFDbEQ7QUFBQSxJQUNGLFNBQVMwSixLQUFLO0FBQ1pDLGNBQVFDLE1BQU1GLEdBQUc7QUFBQSxJQUNuQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNbUUsd0JBQXdCQSxDQUFDQyxRQUFnQkMsZ0JBQXdCO0FBQ3JFM00sa0JBQWMsQ0FBQXVLLFNBQVFBLEtBQUtoUCxPQUFPLENBQUFDLE1BQUtBLEVBQUVvRCxPQUFPOE4sTUFBTSxDQUFDO0FBQ3ZELFVBQU1FLFVBQVVELFlBQVl0UCxTQUFTLElBQUksSUFBSXdQLFdBQVdGLFdBQVcsSUFBSSxPQUFPO0FBQzlFOU0sd0JBQW9CLENBQUEwSyxTQUFRNU8sS0FBS21SLElBQUksS0FBS3BDLFFBQVFILE9BQU9xQyxTQUFTakMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlFckssdUJBQW1CLEVBQUU7QUFDckI0TCxVQUFNLDJEQUEyRDtBQUFBLEVBQ25FO0FBRUEsUUFBTWEsb0JBQW9CQSxDQUFDQyxXQUFtQjtBQUM1QzdILGtCQUFjLENBQUFvRixTQUFRQSxLQUFLQyxJQUFJLENBQUF5QyxNQUFLO0FBQ2xDLFVBQUlBLEVBQUVyTyxPQUFPb08sUUFBUTtBQUNuQixjQUFNRSxjQUFjLENBQUNELEVBQUV6SDtBQUN2QixZQUFJMkgsZUFBZUYsRUFBRTdIO0FBQ3JCLFlBQUk4SCxlQUFlLENBQUNELEVBQUV4SCxpQkFBaUIsQ0FBQ3dILEVBQUU3SCxTQUFTZ0ksWUFBWSxFQUFFdEMsV0FBVyxJQUFJLEdBQUc7QUFDakYsZ0JBQU11QyxlQUFlMVIsS0FBSzJSLE1BQU0sTUFBTzNSLEtBQUs0UixPQUFPLElBQUksR0FBSTtBQUMzREoseUJBQWUsTUFBTUUsWUFBWTtBQUFBLFFBQ25DO0FBQ0EsZUFBTyxFQUFFLEdBQUdKLEdBQUd6SCxTQUFTMEgsYUFBYTlILFVBQVUrSCxhQUFhO0FBQUEsTUFDOUQ7QUFDQSxhQUFPRjtBQUFBQSxJQUNULENBQUMsQ0FBQztBQUNGdEg7QUFBQUEsTUFBWSxDQUFBNEUsU0FBUTtBQUFBLFFBQ2xCLEVBQUUzTCxJQUFJLEtBQUttTCxLQUFLSyxJQUFJLENBQUMsSUFBSXhFLFFBQVEsb0JBQW9Cb0gsTUFBTSx1Q0FBdUNuSCxNQUFNeEosYUFBYStJLFlBQVksZUFBZVUsT0FBTSxvQkFBSWlFLEtBQUssR0FBRUMsbUJBQW1CLElBQUksRUFBRUMsTUFBTSxXQUFXQyxRQUFRLFVBQVUsQ0FBQyxFQUFFO0FBQUEsUUFDaE8sR0FBR0s7QUFBQUEsTUFBSTtBQUFBLElBQ1I7QUFBQSxFQUNIO0FBRUEsUUFBTWlELG1CQUFtQkEsQ0FBQ1IsV0FBbUI7QUFDM0M3SCxrQkFBYyxDQUFBb0YsU0FBUUEsS0FBS2hQLE9BQU8sQ0FBQTBSLE1BQUtBLEVBQUVyTyxPQUFPb08sTUFBTSxDQUFDO0FBQ3ZEckg7QUFBQUEsTUFBWSxDQUFBNEUsU0FBUTtBQUFBLFFBQ2xCLEVBQUUzTCxJQUFJLEtBQUttTCxLQUFLSyxJQUFJLENBQUMsSUFBSXhFLFFBQVEsOEJBQThCb0gsTUFBTSxJQUFJbkgsTUFBTXhKLGFBQWErSSxZQUFZLGVBQWVVLE9BQU0sb0JBQUlpRSxLQUFLLEdBQUVDLG1CQUFtQixJQUFJLEVBQUVDLE1BQU0sV0FBV0MsUUFBUSxVQUFVLENBQUMsRUFBRTtBQUFBLFFBQ3ZNLEdBQUdLO0FBQUFBLE1BQUk7QUFBQSxJQUNSO0FBQ0QyQixVQUFNLDBEQUEwRDtBQUFBLEVBQ2xFO0FBRUEsUUFBTXJDLGtCQUFrQkEsQ0FBQzNKLFNBQTBDO0FBQ2pFLFFBQUk7QUFDRixZQUFNdU4sV0FBVyxLQUFLQyxPQUFPQyxnQkFBaUJELE9BQWVFLG9CQUFvQjtBQUNqRixZQUFNQyxNQUFNSixTQUFTSyxpQkFBaUI7QUFDdEMsWUFBTUMsT0FBT04sU0FBU08sV0FBVztBQUNqQ0gsVUFBSUksUUFBUUYsSUFBSTtBQUNoQkEsV0FBS0UsUUFBUVIsU0FBU1MsV0FBVztBQUVqQyxVQUFJaE8sU0FBUyxXQUFXO0FBQ3RCMk4sWUFBSTNOLE9BQU87QUFDWDJOLFlBQUlNLFVBQVVDLGVBQWUsUUFBUVgsU0FBU1ksV0FBVztBQUN6RFIsWUFBSU0sVUFBVUMsZUFBZSxLQUFLWCxTQUFTWSxjQUFjLEdBQUc7QUFDNUROLGFBQUtBLEtBQUtLLGVBQWUsTUFBTVgsU0FBU1ksV0FBVztBQUNuRE4sYUFBS0EsS0FBS08sNkJBQTZCLE1BQU9iLFNBQVNZLGNBQWMsR0FBRztBQUN4RVIsWUFBSVUsTUFBTTtBQUNWVixZQUFJVyxLQUFLZixTQUFTWSxjQUFjLEdBQUc7QUFBQSxNQUNyQyxPQUFPO0FBRUxSLFlBQUkzTixPQUFPO0FBQ1gyTixZQUFJTSxVQUFVQyxlQUFlLEtBQUtYLFNBQVNZLFdBQVc7QUFDdERSLFlBQUlNLFVBQVVDLGVBQWUsUUFBUVgsU0FBU1ksY0FBYyxHQUFHO0FBQy9ETixhQUFLQSxLQUFLSyxlQUFlLEtBQUtYLFNBQVNZLFdBQVc7QUFDbEROLGFBQUtBLEtBQUtPLDZCQUE2QixNQUFPYixTQUFTWSxjQUFjLEdBQUc7QUFDeEVSLFlBQUlVLE1BQU07QUFDVlYsWUFBSVcsS0FBS2YsU0FBU1ksY0FBYyxHQUFHO0FBQUEsTUFDckM7QUFBQSxJQUNGLFNBQVN2RyxHQUFHO0FBQUEsSUFDVjtBQUFBLEVBRUo7QUFFQSxRQUFNMkcsOEJBQThCLFlBQVk7QUFDOUMsUUFBSTtBQUNGLFlBQU1DLE1BQU0sSUFBSXhVLE1BQU07QUFFdEIsWUFBTXlVLGdCQUF5RDtBQUFBLFFBQzdELGFBQWE7QUFBQSxRQUNiLGdCQUFnQjtBQUFBLFFBQ2hCLGdCQUFnQjtBQUFBLFFBQ2hCLHFCQUFxQjtBQUFBLFFBQ3JCLGlCQUFpQjtBQUFBLFFBQ2pCLGtCQUFrQjtBQUFBLFFBQ2xCLGVBQWU7QUFBQSxRQUNmLGNBQWM7QUFBQSxRQUNkLGNBQWM7QUFBQSxRQUNkLGlCQUFpQjtBQUFBLFFBQ2pCLCtCQUErQjtBQUFBLFFBQy9CLGVBQWU7QUFBQSxRQUNmLGdCQUFnQjtBQUFBLFFBQ2hCLGlCQUFpQjtBQUFBLFFBQ2pCLHFCQUFxQjtBQUFBLFFBQ3JCLGdCQUFnQjtBQUFBLFFBQ2hCLGNBQWM7QUFBQSxRQUNkLFVBQVU7QUFBQSxNQUNaO0FBRUEsaUJBQVcsQ0FBQ0MsTUFBTUMsR0FBRyxLQUFLQyxPQUFPQyxRQUFRSixhQUFhLEdBQUc7QUFDdkQsWUFBSWhMLFdBQVdrTCxHQUFHLEdBQUc7QUFDbkIsY0FBSUQsU0FBUyxrQkFBa0I7QUFDN0JGLGdCQUFJeEQsS0FBSyxrQkFBa0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsQ0FBdUw7QUFBQSxVQUNwTixXQUFXMEQsU0FBUyxjQUFjO0FBQ2hDRixnQkFBSXhELEtBQUssY0FBYztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxDQWtCbEM7QUFBQSxVQUNTLFdBQVcwRCxTQUFTLGVBQWU7QUFDakNGLGdCQUFJeEQsS0FBSyxlQUFlO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsQ0FBd1M7QUFBQSxVQUNsVSxXQUFXMEQsU0FBUyxVQUFVO0FBQzVCRixnQkFBSXhELEtBQUssVUFBVTtBQUFBO0FBQUEsQ0FBMkI7QUFBQSxVQUNoRCxXQUFXMEQsU0FBUyxnQkFBZ0I7QUFDbENGLGdCQUFJeEQsS0FBSyxnQkFBZ0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLENBQWtJO0FBQUEsVUFDN0osT0FBTztBQUNMLGdCQUFJO0FBQ0Ysb0JBQU1sRCxNQUFNLE1BQU1DLE1BQU0sSUFBSTJHLElBQUksRUFBRTtBQUNsQyxrQkFBSTVHLElBQUlpQixJQUFJO0FBQ1Ysc0JBQU1mLE9BQU8sTUFBTUYsSUFBSUUsS0FBSztBQUM1QndHLG9CQUFJeEQsS0FBSzBELE1BQU0xRyxJQUFJO0FBQUEsY0FDckI7QUFBQSxZQUNGLFNBQVNKLEdBQUc7QUFDVlMsc0JBQVF5RyxLQUFLLG1CQUFtQkosSUFBSSxJQUFJOUcsQ0FBQztBQUFBLFlBQzNDO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBRUEsVUFBSW5FLFdBQVdjLFFBQVE7QUFDckJpSyxZQUFJeEQsS0FBSyxhQUFhO0FBQUE7QUFBQSxTQUE2RW5GLFlBQVlFLFNBQVM7QUFBQTtBQUFBO0FBQUEsRUFBMkM2SSxPQUFPQyxRQUFRcEwsVUFBVSxFQUFFcEksT0FBTyxDQUFDLENBQUMwVCxHQUFHQyxDQUFDLE1BQU1BLENBQUMsRUFBRTFFLElBQUksQ0FBQyxDQUFDeUUsQ0FBQyxNQUFNLEtBQUtBLENBQUMsRUFBRSxFQUFFRSxLQUFLLElBQUksQ0FBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsQ0FBK0Q7QUFBQSxNQUN0VDtBQUVBLFlBQU16TyxVQUFVLE1BQU1nTyxJQUFJVSxjQUFjLEVBQUVsUCxNQUFNLE9BQU8sQ0FBQztBQUN4RCxZQUFNbVAsTUFBTUMsSUFBSUMsZ0JBQWdCN08sT0FBTztBQUN2QyxZQUFNMEwsSUFBSW9ELFNBQVNDLGNBQWMsR0FBRztBQUNwQ3JELFFBQUVzRCxPQUFPTDtBQUNUakQsUUFBRXVELFdBQVcsdUNBQXVDNUYsS0FBS0ssSUFBSSxDQUFDO0FBQzlEb0YsZUFBUzVHLEtBQUtnSCxZQUFZeEQsQ0FBQztBQUMzQkEsUUFBRXlELE1BQU07QUFDUkwsZUFBUzVHLEtBQUtrSCxZQUFZMUQsQ0FBQztBQUMzQmtELFVBQUlTLGdCQUFnQlYsR0FBRztBQUN2QnBLLDBCQUFvQixrREFBa0Q7QUFDdEVpRSxpQkFBVyxNQUFNakUsb0JBQW9CLEVBQUUsR0FBRyxHQUFJO0FBQUEsSUFDaEQsU0FBU3FELEtBQUs7QUFDWkMsY0FBUUMsTUFBTSxnQ0FBZ0NGLEdBQUc7QUFDakQ0RCxZQUFNLGlDQUFpQztBQUFBLElBQ3pDO0FBQUEsRUFDRjtBQUdBLE1BQUksQ0FBQzdQLGFBQWE7QUFDaEIsV0FDRSx1QkFBQyxTQUFJLFdBQVUsMEpBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsb0dBQ2IsaUNBQUMsU0FBSSxXQUFVLG9DQUFtQyxTQUFRLGVBQWMsTUFBSyxRQUFPLE9BQU0sOEJBQ3hGO0FBQUEsK0JBQUMsVUFBSyxHQUFFLDZHQUE0RyxNQUFLLGdCQUFlLGFBQVksU0FBcEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5SjtBQUFBLFFBQ3pKLHVCQUFDLFVBQUssR0FBRSw2R0FBNEcsTUFBSyxXQUFVLGFBQVksU0FBL0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvSjtBQUFBLFFBQ3BKLHVCQUFDLFVBQUssR0FBRSw0R0FBMkcsTUFBSyxXQUFVLGFBQVksU0FBOUk7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtSjtBQUFBLFFBQ25KLHVCQUFDLFlBQU8sSUFBRyxPQUFNLElBQUcsT0FBTSxHQUFFLE9BQU0sUUFBTyxnQkFBZSxhQUFZLEtBQUksaUJBQWdCLE9BQU0sZUFBYyxTQUE1RztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlIO0FBQUEsUUFDakgsdUJBQUMsWUFBTyxJQUFHLE9BQU0sSUFBRyxPQUFNLEdBQUUsT0FBTSxRQUFPLFdBQVUsYUFBWSxLQUFJLGlCQUFnQixPQUFNLGVBQWMsU0FBdkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0RztBQUFBLFdBTDlHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFNQSxLQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLDBIQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHlCQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLCtCQUNiLGlDQUFDLFVBQU8sTUFBSyxNQUFLLFNBQVMwSixZQUFZL0osV0FBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0MsS0FEakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsUUFBRyxXQUFVLG9EQUFvRCtKLHNCQUFZRSxhQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3RjtBQUFBLFVBQ3hGLHVCQUFDLE9BQUUsV0FBVSwwQkFBMEJGLHNCQUFZSSxhQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2RDtBQUFBLGFBTC9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQTtBQUFBLFFBRUMzSSxhQUNDLHVCQUFDLFNBQUksV0FBVSxzR0FDYjtBQUFBLGlDQUFDLGlCQUFjLFdBQVUsc0JBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJDO0FBQUEsVUFDMUNBO0FBQUFBLGFBRkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFHREUsZUFDQyx1QkFBQyxTQUFJLFdBQVUsc0dBQ2I7QUFBQSxpQ0FBQyxTQUFNLFdBQVUsc0JBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1DO0FBQUEsVUFDbENBO0FBQUFBLGFBRkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFHRG5CLGFBQWEsV0FDWix1QkFBQyxVQUFLLFVBQVU2TSxhQUFhLFdBQVUsYUFDckM7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSxzQ0FBcUMsOEJBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9FO0FBQUEsWUFDcEU7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsT0FBTzNNO0FBQUFBLGdCQUNQLFVBQVUsQ0FBQXFMLE1BQUtwTCxpQkFBaUJvTCxFQUFFcUQsT0FBTzZFLEtBQUs7QUFBQSxnQkFDOUM7QUFBQSxnQkFDQSxXQUFVO0FBQUE7QUFBQSxjQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUsrSTtBQUFBLGVBUGpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBU0E7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLHNDQUFxQyx3QkFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEQ7QUFBQSxZQUM5RDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxPQUFPalQ7QUFBQUEsZ0JBQ1AsVUFBVSxDQUFBK0ssTUFBSzlLLGlCQUFpQjhLLEVBQUVxRCxPQUFPNkUsS0FBSztBQUFBLGdCQUM5QztBQUFBLGdCQUNBLFdBQVU7QUFBQTtBQUFBLGNBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSytJO0FBQUEsZUFQako7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFTQTtBQUFBLFVBRUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFdBQVU7QUFBQSxjQUFpSTtBQUFBO0FBQUEsWUFGN0k7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS0E7QUFBQSxVQUlBLHVCQUFDLFNBQUksV0FBVSxrREFDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVMsTUFBTXhULFlBQVksVUFBVTtBQUFBLGdCQUNyQyxXQUFVO0FBQUEsZ0JBQTRDO0FBQUE7QUFBQSxjQUh4RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBUyxNQUFNQSxZQUFZLFFBQVE7QUFBQSxnQkFDbkMsV0FBVTtBQUFBLGdCQUFxQztBQUFBO0FBQUEsY0FIakQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTUE7QUFBQSxlQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZUE7QUFBQSxhQS9DRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0RBO0FBQUEsUUFHREQsYUFBYSxjQUNaLHVCQUFDLFVBQUssVUFBVWtNLGdCQUFnQixXQUFVLGFBQ3hDO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsc0NBQXFDLG9DQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwRTtBQUFBLFlBQzFFO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE9BQU9oTTtBQUFBQSxnQkFDUCxVQUFVLENBQUFxTCxNQUFLcEwsaUJBQWlCb0wsRUFBRXFELE9BQU82RSxLQUFLO0FBQUEsZ0JBQzlDLGFBQVk7QUFBQSxnQkFDWjtBQUFBLGdCQUNBLFdBQVU7QUFBQTtBQUFBLGNBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTXFLO0FBQUEsZUFSdks7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsc0NBQXFDLDZCQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtRTtBQUFBLFlBQ25FO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE9BQU9yVDtBQUFBQSxnQkFDUCxVQUFVLENBQUFtTCxNQUFLbEwsY0FBY2tMLEVBQUVxRCxPQUFPNkUsS0FBSztBQUFBLGdCQUMzQyxhQUFZO0FBQUEsZ0JBQ1o7QUFBQSxnQkFDQSxXQUFVO0FBQUE7QUFBQSxjQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1xSztBQUFBLGVBUnZLO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVUE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLHNDQUFxQyw2QkFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUU7QUFBQSxZQUNuRTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxPQUFPblQ7QUFBQUEsZ0JBQ1AsVUFBVSxDQUFBaUwsTUFBS2hMLGVBQWVnTCxFQUFFcUQsT0FBTzZFLEtBQUs7QUFBQSxnQkFDNUMsYUFBWTtBQUFBLGdCQUNaLFdBQVU7QUFBQTtBQUFBLGNBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS3FLO0FBQUEsZUFQdks7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFTQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsc0NBQXFDLHdCQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4RDtBQUFBLFlBQzlEO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE9BQU9qVDtBQUFBQSxnQkFDUCxVQUFVLENBQUErSyxNQUFLOUssaUJBQWlCOEssRUFBRXFELE9BQU82RSxLQUFLO0FBQUEsZ0JBQzlDLGFBQVk7QUFBQSxnQkFDWjtBQUFBLGdCQUNBLFdBQVU7QUFBQTtBQUFBLGNBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTXFLO0FBQUEsZUFSdks7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLFVBRUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFdBQVU7QUFBQSxjQUFpSTtBQUFBO0FBQUEsWUFGN0k7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS0E7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxvQkFDYjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsU0FBUyxNQUFNeFQsWUFBWSxPQUFPO0FBQUEsY0FDbEMsV0FBVTtBQUFBLGNBQW9EO0FBQUE7QUFBQSxZQUhoRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNQSxLQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUUE7QUFBQSxhQS9ERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0VBO0FBQUEsUUFHREQsYUFBYSxZQUNaLHVCQUFDLFVBQUssVUFBVStNLHNCQUFzQixXQUFVLGFBQzlDO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsc0NBQXFDLDZCQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtRTtBQUFBLFlBQ25FO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE9BQU8zTTtBQUFBQSxnQkFDUCxVQUFVLENBQUFtTCxNQUFLbEwsY0FBY2tMLEVBQUVxRCxPQUFPNkUsS0FBSztBQUFBLGdCQUMzQyxhQUFZO0FBQUEsZ0JBQ1o7QUFBQSxnQkFDQSxXQUFVO0FBQUE7QUFBQSxjQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1xSztBQUFBLGVBUnZLO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVUE7QUFBQSxVQUVBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxXQUFVO0FBQUEsY0FBaUk7QUFBQTtBQUFBLFlBRjdJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsb0JBQ2I7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFNBQVMsTUFBTXhULFlBQVksT0FBTztBQUFBLGNBQ2xDLFdBQVU7QUFBQSxjQUE2QztBQUFBO0FBQUEsWUFIekQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTUEsS0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsYUE1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTZCQTtBQUFBLFFBR0RELGFBQWEsa0JBQ1osdUJBQUMsVUFBSyxVQUFVaU4sMkJBQTJCLFdBQVUsYUFDbER4TDtBQUFBQSwyQkFDQyx1QkFBQyxTQUFJLFdBQVUsd0ZBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsYUFBWSwyQ0FBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0Q7QUFBQSxZQUN0RCx1QkFBQyxTQUFJLFdBQVUsOENBQThDQSwyQkFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkU7QUFBQSxlQUY3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFHRix1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSxzQ0FBcUMsMEJBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdFO0FBQUEsWUFDaEU7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsT0FBT0o7QUFBQUEsZ0JBQ1AsVUFBVSxDQUFBa0ssTUFBS2pLLGlCQUFpQmlLLEVBQUVxRCxPQUFPNkUsS0FBSztBQUFBLGdCQUM5QyxhQUFZO0FBQUEsZ0JBQ1o7QUFBQSxnQkFDQSxXQUFVO0FBQUE7QUFBQSxjQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU13TTtBQUFBLGVBUjFNO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVUE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLHNDQUFxQyw0QkFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0U7QUFBQSxZQUNsRTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxPQUFPbFM7QUFBQUEsZ0JBQ1AsVUFBVSxDQUFBZ0ssTUFBSy9KLG9CQUFvQitKLEVBQUVxRCxPQUFPNkUsS0FBSztBQUFBLGdCQUNqRCxhQUFZO0FBQUEsZ0JBQ1o7QUFBQSxnQkFDQSxXQUFVO0FBQUE7QUFBQSxjQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1xSztBQUFBLGVBUnZLO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVUE7QUFBQSxVQUVBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxXQUFVO0FBQUEsY0FBaUk7QUFBQTtBQUFBLFlBRjdJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtBO0FBQUEsYUFyQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXNDQTtBQUFBLFdBdk5KO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF5TkE7QUFBQSxTQXBPRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBcU9BO0FBQUEsRUFFSjtBQUdBLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLDBHQUViO0FBQUEsMkJBQUMsVUFBSyxXQUFXLHdCQUF3QnhSLGNBQWMsVUFBVUEsY0FBYyxTQUFTLG1CQUFtQixxQ0FBcUMsSUFFN0k2QjtBQUFBQSx5QkFBbUI3QixjQUFjLFVBQ2hDLHVCQUFDLFNBQUksV0FBVSxnSUFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLGlDQUFDLGlCQUFjLFdBQVUsbUNBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdEO0FBQUEsVUFDeEQsdUJBQUMsVUFBSyxXQUFVLGVBQWU2Qiw2QkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0M7QUFBQSxhQUZqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTLE1BQU01QixhQUFhLE9BQU87QUFBQSxZQUNuQyxXQUFVO0FBQUEsWUFBbUc7QUFBQTtBQUFBLFVBRi9HO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtBO0FBQUEsV0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBV0E7QUFBQSxNQUlERCxjQUFjLFVBQ2IsdUJBQUMsU0FBSSxXQUFVLGlEQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLCtGQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLGlJQUNac0ksMEJBQWdCdk0sZUFDZix1QkFBQyxTQUFJLEtBQUt1TSxnQkFBZ0J2TSxjQUFjLFdBQVUsZ0NBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThFLElBRTlFOEIsWUFBWStJLFNBQVM2SyxPQUFPLENBQUMsRUFBRTdDLFlBQVksS0FKL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFNQTtBQUFBLFlBQ0EsdUJBQUMsU0FDQyxpQ0FBQyxRQUFHLFdBQVUsb0NBQW1DO0FBQUE7QUFBQSxjQUFFL1EsWUFBWStJO0FBQUFBLGlCQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3RSxLQUQxRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVdBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsb0NBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVMsTUFBTTNGLG9CQUFvQixJQUFJO0FBQUEsZ0JBQ3ZDLFdBQVU7QUFBQSxnQkFDVixPQUFNO0FBQUEsZ0JBRU4saUNBQUMsWUFBUyxXQUFVLGFBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTZCO0FBQUE7QUFBQSxjQUwvQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLFlBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxTQUFTLE1BQU00QixpQkFBaUIsQ0FBQ0QsYUFBYTtBQUFBLGtCQUM5QyxXQUFVO0FBQUEsa0JBQ1YsT0FBTTtBQUFBLGtCQUVOLGlDQUFDLGdCQUFhLFdBQVUsYUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBaUM7QUFBQTtBQUFBLGdCQUxuQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNQTtBQUFBLGNBRUNBLGlCQUNDLHVCQUFDLFNBQUksV0FBVSw0SEFDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFNBQVMsTUFBTTtBQUFFQyx1Q0FBaUIsS0FBSztBQUFHNUMsbUNBQWEsUUFBUTtBQUFBLG9CQUFHO0FBQUEsb0JBQ2xFLFdBQVU7QUFBQSxvQkFFVjtBQUFBLDZDQUFDLGFBQVUsV0FBVSw0QkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBNkM7QUFBQSxzQkFDN0MsdUJBQUMsVUFBSyxzQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFZO0FBQUE7QUFBQTtBQUFBLGtCQUxkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFNBQVMsTUFBTTtBQUFFNEMsdUNBQWlCLEtBQUs7QUFBRzVDLG1DQUFhLE9BQU87QUFBQSxvQkFBRztBQUFBLG9CQUNqRSxXQUFVO0FBQUEsb0JBRVY7QUFBQSw2Q0FBQyxhQUFVLFdBQVUsNEJBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQTZDO0FBQUEsc0JBQzdDLHVCQUFDLFVBQUssNEJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBa0I7QUFBQTtBQUFBO0FBQUEsa0JBTHBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNQTtBQUFBLGlCQUNFcEMsWUFBWW1KLFdBQVduSixZQUFZb0osa0JBQ25DO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFNBQVMsTUFBTTtBQUFFcEUsdUNBQWlCLEtBQUs7QUFBR3VHLDJDQUFxQjtBQUFBLG9CQUFHO0FBQUEsb0JBQ2xFLFdBQVU7QUFBQSxvQkFFVjtBQUFBLDZDQUFDLFVBQU8sV0FBVSw0QkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBMEM7QUFBQSxzQkFDMUMsdUJBQUMsVUFBSywyQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFpQjtBQUFBO0FBQUE7QUFBQSxrQkFMbkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU1BO0FBQUEsZ0JBRUY7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsU0FBUyxNQUFNO0FBQUV2Ryx1Q0FBaUIsS0FBSztBQUFHNUMsbUNBQWEsVUFBVTtBQUFBLG9CQUFHO0FBQUEsb0JBQ3BFLFdBQVU7QUFBQSxvQkFFVjtBQUFBLDZDQUFDLFlBQVMsV0FBVSw0QkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBNEM7QUFBQSxzQkFDNUMsdUJBQUMsVUFBSyx3QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFjO0FBQUE7QUFBQTtBQUFBLGtCQUxoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTUE7QUFBQSxtQkE5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkErQkE7QUFBQSxpQkF6Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEyQ0E7QUFBQSxlQW5ERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW9EQTtBQUFBLGFBbEVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFtRUE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSx3Q0FDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxzSkFDYjtBQUFBLG1DQUFDLFVBQUs7QUFBQTtBQUFBLGNBQTZCQyxTQUFTdkQ7QUFBQUEsY0FBTztBQUFBLGlCQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvRDtBQUFBLFlBQ3BELHVCQUFDLFNBQUksV0FBVSwyQkFDWm1HO0FBQUFBLG9DQUNDO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxPQUFPaEM7QUFBQUEsa0JBQ1AsVUFBVSxDQUFBd0ksTUFBS3ZJLGVBQWV1SSxFQUFFcUQsT0FBTzZFLEtBQUs7QUFBQSxrQkFDNUMsYUFBWTtBQUFBLGtCQUNaLFdBQVU7QUFBQSxrQkFDVixXQUFTO0FBQUE7QUFBQSxnQkFOWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNVztBQUFBLGNBR2I7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsU0FBUyxNQUFNek8sc0JBQXNCLENBQUNELGtCQUFrQjtBQUFBLGtCQUN4RCxXQUFVO0FBQUEsa0JBQ1YsT0FBTTtBQUFBLGtCQUVOLGlDQUFDLFVBQU8sV0FBVSxhQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEyQjtBQUFBO0FBQUEsZ0JBTDdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU1BO0FBQUEsaUJBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBa0JBO0FBQUEsZUFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFxQkE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSw2QkFFZDVDLG1CQUNFbkQsT0FBTyxDQUFBa1AsTUFBS0EsRUFBRTVMLEtBQUtxUixZQUFZLEVBQUU3UyxTQUFTaUMsWUFBWTRRLFlBQVksQ0FBQyxLQUFLekYsRUFBRTNMLE9BQU9vUixZQUFZLEVBQUU3UyxTQUFTaUMsWUFBWTRRLFlBQVksQ0FBQyxDQUFDLEVBQ2xJMUY7QUFBQUEsWUFBSSxDQUFBMkYsWUFDSDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUVDLFNBQVMsTUFBTTtBQUNiOVEsbUNBQWlCOFEsT0FBTztBQUN4QjFSLCtCQUFhLE1BQU07QUFBQSxnQkFDckI7QUFBQSxnQkFDQSxXQUFVO0FBQUEsZ0JBRVY7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsWUFDYjtBQUFBLDJDQUFDLFNBQUksV0FBVywwQkFBMEIwUixRQUFRcFIsUUFBUSw4RUFDdkRvUixrQkFBUXRSLEtBQUtvUixPQUFPLENBQUMsRUFBRTdDLFlBQVksS0FEdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNDK0MsUUFBUWhSLFVBQ1AsdUJBQUMsU0FBSSxXQUFVLDJGQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXVHO0FBQUEsdUJBTDNHO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBT0E7QUFBQSxrQkFFQSx1QkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSwyQ0FBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSw2Q0FBQyxRQUFHLFdBQVUsMEZBQTBGZ1Isa0JBQVF0UixRQUFoSDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFxSDtBQUFBLHNCQUNySCx1QkFBQyxVQUFLLFdBQVUsOEJBQThCc1Isa0JBQVFsUixhQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFnRTtBQUFBLHlCQUZsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUdBO0FBQUEsb0JBQ0EsdUJBQUMsT0FBRSxXQUFVLG1DQUFtQ2tSLGtCQUFRblIsZUFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBb0U7QUFBQSx1QkFMdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFNQTtBQUFBLGtCQUVDbVIsUUFBUWpSLGVBQWVpUixRQUFRalIsY0FBYyxJQUM1Qyx1QkFBQyxTQUFJLFdBQVUsaUhBQ1ppUixrQkFBUWpSLGVBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQSxJQUNFO0FBQUE7QUFBQTtBQUFBLGNBNUJDaVIsUUFBUXZSO0FBQUFBLGNBRGY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQThCQTtBQUFBLFVBQ0gsS0FwQ0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFxQ0Y7QUFBQSxhQTdEQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBOERBO0FBQUEsV0FwSUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXFJQTtBQUFBLE1BSURKLGNBQWMsVUFBVVksaUJBQ3ZCLHVCQUFDLFNBQUksV0FBVSxvRUFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSwrRkFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBUyxNQUFNWCxhQUFhLE1BQU07QUFBQSxnQkFDbEMsV0FBVTtBQUFBLGdCQUNWLE9BQU07QUFBQSxnQkFFTixpQ0FBQyxhQUFVLFdBQVUsYUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBOEI7QUFBQTtBQUFBLGNBTGhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1BO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVcsMEJBQTBCVyxjQUFjTCxRQUFRLDRFQUM3REssd0JBQWNQLEtBQUtvUixPQUFPLENBQUMsRUFBRTdDLFlBQVksS0FENUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBRUEsdUJBQUMsU0FDQztBQUFBLHFDQUFDLFVBQUssV0FBVSxzQ0FBc0NoTyx3QkFBY1AsUUFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBeUU7QUFBQSxjQUN6RSx1QkFBQyxVQUFLLFdBQVUsOENBQThDTyx3QkFBY04sVUFBNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUY7QUFBQSxjQUNuRix1QkFBQyxVQUFLLFdBQVUsc0NBQXFDO0FBQUE7QUFBQSxnQkFBRU0sY0FBY1AsS0FBS3VSLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFBQSxnQkFBRTtBQUFBLG1CQUF4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5RjtBQUFBLGlCQUgzRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUlBO0FBQUEsZUFqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFrQkE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxvQ0FDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBUyxNQUFNblAscUJBQXFCLElBQUk7QUFBQSxnQkFDeEMsV0FBVTtBQUFBLGdCQUVWO0FBQUEseUNBQUMsU0FBTSxXQUFVLDRCQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF5QztBQUFBLGtCQUN6Qyx1QkFBQyxVQUFLLFdBQVUsb0JBQW1CLGlDQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFvRDtBQUFBO0FBQUE7QUFBQSxjQUx0RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLFlBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxTQUFTLE1BQU1FLGtCQUFrQixDQUFBb0osU0FBUSxDQUFDQSxJQUFJO0FBQUEsa0JBQzlDLFdBQVU7QUFBQSxrQkFDVixPQUFNO0FBQUEsa0JBRU4saUNBQUMsZ0JBQWEsV0FBVSxhQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFpQztBQUFBO0FBQUEsZ0JBTG5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU1BO0FBQUEsY0FFQ3JKLGtCQUNDLHVCQUFDLFNBQUksV0FBVSw0SEFDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFNBQVMsTUFBTTtBQUFFQyx3Q0FBa0IsS0FBSztBQUFHK0ssNEJBQU0sc0JBQXNCO0FBQUEsb0JBQUc7QUFBQSxvQkFDMUUsV0FBVTtBQUFBLG9CQUVWO0FBQUEsNkNBQUMsVUFBTyxXQUFVLDJCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUF5QztBQUFBLHNCQUN6Qyx1QkFBQyxVQUFLLHNCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQVk7QUFBQTtBQUFBO0FBQUEsa0JBTGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU1BO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsU0FBUyxNQUFNO0FBQUUvSyx3Q0FBa0IsS0FBSztBQUFHMUMsbUNBQWEsT0FBTztBQUFBLG9CQUFHO0FBQUEsb0JBQ2xFLFdBQVU7QUFBQSxvQkFFVjtBQUFBLDZDQUFDLGlCQUFjLFdBQVUsMkJBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWdEO0FBQUEsc0JBQ2hELHVCQUFDLFVBQUssc0NBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBNEI7QUFBQTtBQUFBO0FBQUEsa0JBTDlCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFNBQVMsTUFBTTtBQUFFMEMsd0NBQWtCLEtBQUs7QUFBRzFDLG1DQUFhLFFBQVE7QUFBQSxvQkFBRztBQUFBLG9CQUNuRSxXQUFVO0FBQUEsb0JBRVY7QUFBQSw2Q0FBQyxhQUFVLFdBQVUsMkJBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQTRDO0FBQUEsc0JBQzVDLHVCQUFDLFVBQUssc0JBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBWTtBQUFBO0FBQUE7QUFBQSxrQkFMZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxTQUFTLE1BQU07QUFBRTBDLHdDQUFrQixLQUFLO0FBQUcxQyxtQ0FBYSxPQUFPO0FBQUEsb0JBQUc7QUFBQSxvQkFDbEUsV0FBVTtBQUFBLG9CQUVWO0FBQUEsNkNBQUMsYUFBVSxXQUFVLDJCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUE0QztBQUFBLHNCQUM1Qyx1QkFBQyxVQUFLLDRCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWtCO0FBQUE7QUFBQTtBQUFBLGtCQUxwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTUE7QUFBQSxpQkFDRXBDLFlBQVltSixXQUFXbkosWUFBWW9KLGtCQUNuQztBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxTQUFTbUM7QUFBQUEsb0JBQ1QsV0FBVTtBQUFBLG9CQUVWO0FBQUEsNkNBQUMsVUFBTyxXQUFVLDJCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUF5QztBQUFBLHNCQUN6Qyx1QkFBQyxVQUFLLDJCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWlCO0FBQUE7QUFBQTtBQUFBLGtCQUxuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTUE7QUFBQSxnQkFFRjtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxTQUFTLE1BQU07QUFBRXpHLHdDQUFrQixLQUFLO0FBQUcxQyxtQ0FBYSxVQUFVO0FBQUEsb0JBQUc7QUFBQSxvQkFDckUsV0FBVTtBQUFBLG9CQUVWO0FBQUEsNkNBQUMsWUFBUyxXQUFVLDJCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUEyQztBQUFBLHNCQUMzQyx1QkFBQyxVQUFLLHdCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWM7QUFBQTtBQUFBO0FBQUEsa0JBTGhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSxtQ0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUErQztBQUFBLGdCQUMvQztBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxTQUFTLE1BQU07QUFBRTBDLHdDQUFrQixLQUFLO0FBQUcwSSxzQ0FBZ0IsTUFBTTtBQUFHcUMsNEJBQU0sc0NBQXNDOU0sY0FBY1AsSUFBSSxLQUFLO0FBQUEsb0JBQUc7QUFBQSxvQkFDMUksV0FBVTtBQUFBLG9CQUVWO0FBQUEsNkNBQUMsU0FBTSxXQUFVLDJCQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUF3QztBQUFBLHNCQUN4Qyx1QkFBQyxVQUFLLDBCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWdCO0FBQUE7QUFBQTtBQUFBLGtCQUxsQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxTQUFTLE1BQU07QUFBRXNDLHdDQUFrQixLQUFLO0FBQUcwSSxzQ0FBZ0IsTUFBTTtBQUFHNUksMkNBQXFCLElBQUk7QUFBQSxvQkFBRztBQUFBLG9CQUNoRyxXQUFVO0FBQUEsb0JBRVY7QUFBQSw2Q0FBQyxTQUFNLFdBQVUsMkJBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXdDO0FBQUEsc0JBQ3hDLHVCQUFDLFVBQUssMEJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBZ0I7QUFBQTtBQUFBO0FBQUEsa0JBTGxCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSxtQ0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUErQztBQUFBLGdCQUMvQztBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxTQUFTLE1BQU07QUFDYkUsd0NBQWtCLEtBQUs7QUFDdkJYLGtDQUFZLENBQUErSixVQUFTLEVBQUUsR0FBR0EsTUFBTSxDQUFDbkwsY0FBY1IsRUFBRSxHQUFHLEdBQUcsRUFBRTtBQUFBLG9CQUMzRDtBQUFBLG9CQUNBLFdBQVU7QUFBQSxvQkFFVjtBQUFBLDZDQUFDLFNBQU0sV0FBVSxhQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUEwQjtBQUFBLHNCQUMxQix1QkFBQyxVQUFLLDBCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWdCO0FBQUE7QUFBQTtBQUFBLGtCQVJsQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBU0E7QUFBQSxtQkF0RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkF1RUE7QUFBQSxpQkFqRko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFtRkE7QUFBQSxlQTVGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTZGQTtBQUFBLGFBbEhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFtSEE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSx3REFDWDJCLG9CQUFTbkIsY0FBY1IsRUFBRSxLQUFLLElBQUk0TDtBQUFBQSxVQUFJLENBQUE2RixRQUN0Qyx1QkFBQyxTQUFpQixXQUFXLGlCQUFpQkEsSUFBSTVQLFdBQVdwRSxZQUFZK0ksV0FBVyxjQUFjLGFBQWEsSUFDNUdpTCxjQUFJQyxpQkFDSCx1QkFBQyxTQUFJLFdBQVUsa0hBQ2I7QUFBQSxtQ0FBQyxpQkFBYyxXQUFVLHFDQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwRDtBQUFBLFlBQzFELHVCQUFDLFNBQUtELGNBQUkzUCxXQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtCO0FBQUEsZUFGcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQSxJQUVBLHVCQUFDLFNBQUksV0FBVSx5QkFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSx1REFDYjtBQUFBLHFDQUFDLFVBQUssV0FBVSxnQ0FBK0I7QUFBQTtBQUFBLGdCQUFFMlAsSUFBSTVQO0FBQUFBLG1CQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE0RDtBQUFBLGNBQzVELHVCQUFDLFVBQUssaUJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBTztBQUFBLGNBQ1AsdUJBQUMsVUFBTTRQLGNBQUlwUixhQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFCO0FBQUEsaUJBSHZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSUE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVywyQ0FBMkNvUixJQUFJNVAsV0FBV3BFLFlBQVkrSSxXQUFXLGtFQUFrRSwyRUFBMkUsSUFDM09pTCxjQUFJM1AsV0FEUDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVNBLEtBaEJNMlAsSUFBSXpSLElBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFrQkE7QUFBQSxRQUNELEtBckJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFzQkE7QUFBQSxRQUVBLHVCQUFDLFVBQUssVUFBVStLLG1CQUFtQixXQUFVLGtFQUMzQyxpQ0FBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsT0FBTy9JO0FBQUFBLGNBQ1AsVUFBVSxDQUFBa0gsTUFBS2pILGFBQWFpSCxFQUFFcUQsT0FBTzZFLEtBQUs7QUFBQSxjQUMxQyxhQUFZO0FBQUEsY0FDWixXQUFVO0FBQUE7QUFBQSxZQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtxSjtBQUFBLFVBRXJKO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxVQUFVLENBQUNwUCxVQUFVbkYsS0FBSztBQUFBLGNBQzFCLFdBQVU7QUFBQSxjQUNWLE9BQU07QUFBQSxjQUVOLGlDQUFDLFFBQUssV0FBVSxhQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5QjtBQUFBO0FBQUEsWUFOM0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT0E7QUFBQSxhQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnQkEsS0FqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWtCQTtBQUFBLFdBaEtGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFpS0E7QUFBQSxNQUlEK0MsY0FBYyxZQUNiLHVCQUFDLFNBQUksV0FBVSwwRUFFYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxtRUFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSwrRUFDYjtBQUFBLG1DQUFDLFVBQU1uQyx1QkFBYStJLFlBQVksc0JBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1EO0FBQUEsWUFDbkQsdUJBQUMsZUFBWSxXQUFVLDJCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4QztBQUFBLFlBQzlDLHVCQUFDLFVBQUssV0FBVSwwQ0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUQ7QUFBQSxlQUh6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2IsaUNBQUMsUUFBSyxTQUFTLE1BQU03QixpQkFBaUIsQ0FBQ0QsYUFBYSxHQUFHLFdBQVcsNENBQTRDQSxnQkFBZ0Isa0JBQWtCLFlBQVksTUFBNUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0osS0FEaks7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsK0NBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUFNSCxvQkFBb0IsTUFBTTtBQUFBLGNBQ3pDLFdBQVcsa0lBQWtJRCxxQkFBcUIsU0FBUyxrREFBa0Qsa0JBQWtCO0FBQUEsY0FFL08saUNBQUMsVUFBSyxvQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFVO0FBQUE7QUFBQSxZQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUFNQyxvQkFBb0IsUUFBUTtBQUFBLGNBQzNDLFdBQVcsa0lBQWtJRCxxQkFBcUIsV0FBVyxrREFBa0Qsa0JBQWtCO0FBQUEsY0FFalAsaUNBQUMsVUFBSyxzQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFZO0FBQUE7QUFBQSxZQUpkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtBO0FBQUEsYUFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBYUE7QUFBQSxRQUdBLHVCQUFDLFNBQUksV0FBVSxvQ0FDWjFCO0FBQUFBLGlCQUFPakcsT0FBTyxDQUFDNlEsR0FBR21FLFVBQVU7QUFDM0Isa0JBQU1DLFVBQVVwRSxFQUFFTCxVQUFVMEUsU0FBUyxNQUFNLEtBQUtyRSxFQUFFTCxVQUFVMU8sU0FBUyxPQUFPLEtBQUsrTyxFQUFFTCxVQUFVMU8sU0FBUyxNQUFNLEtBQUtrVCxRQUFRLE1BQU07QUFDL0gsZ0JBQUlyTixxQkFBcUIsT0FBUSxRQUFPLENBQUNzTjtBQUN6QyxtQkFBT0E7QUFBQUEsVUFDVCxDQUFDLEVBQUVoRyxJQUFJLENBQUM0QixHQUFHbUUsVUFBVTtBQUNuQixrQkFBTUcsVUFBVWxPLFdBQVc0SixFQUFFeE4sRUFBRTtBQUMvQixrQkFBTStSLGNBQWN2RSxFQUFFQyxTQUFTLE9BQU9xRSxVQUFVLElBQUk7QUFDcEQsa0JBQU1FLGVBQWVsTyxjQUFjMEosRUFBRXhOLEVBQUUsS0FBS3dOLEVBQUVJLFlBQVk7QUFBQSxjQUN4RCxFQUFFNU4sSUFBSSxLQUFLK00sUUFBUSxtQkFBbUJ6RCxNQUFNLGtDQUFrQ3BDLE1BQU0sS0FBSztBQUFBLGNBQ3pGLEVBQUVsSCxJQUFJLEtBQUsrTSxRQUFRLGVBQWV6RCxNQUFNLDBCQUEwQnBDLE1BQU0sS0FBSztBQUFBLFlBQUM7QUFFaEYsa0JBQU0wSyxVQUFVcEUsRUFBRUwsVUFBVTBFLFNBQVMsTUFBTSxLQUFLckUsRUFBRUwsVUFBVTFPLFNBQVMsT0FBTyxLQUFLK08sRUFBRUwsVUFBVTFPLFNBQVMsTUFBTSxLQUFLa1QsUUFBUSxNQUFNO0FBRS9ILG1CQUNFLHVCQUFDLFNBQWUsV0FBVSw2RUFFeEI7QUFBQSxxQ0FBQyxTQUFJLFdBQVUscUVBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsZ0ZBQ2IsaUNBQUMsU0FBSSxXQUFVLHdIQUNaeEssc0JBQVkvSixVQUFVLHVCQUFDLFNBQUksS0FBSytKLFlBQVkvSixTQUFTLFdBQVUsZ0NBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXFFLElBQU0sUUFEcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBSUE7QUFBQSxrQkFDQSx1QkFBQyxTQUNDO0FBQUEsMkNBQUMsU0FBSSxXQUFVLHdEQUNab1E7QUFBQUEsd0JBQUVSLGNBQWN2UCxhQUFhK0ksWUFBWTtBQUFBLHNCQUMxQyx1QkFBQyxVQUFLLFdBQVUsNkJBQTRCLGlCQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUE2QztBQUFBLHlCQUYvQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUdBO0FBQUEsb0JBQ0EsdUJBQUMsU0FBSSxXQUFVLDZCQUE2QmdILFlBQUVuTixhQUFhLGlCQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUF5RTtBQUFBLHVCQUwzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQU1BO0FBQUEscUJBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFhQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFNBQVMsTUFBTXdFLGVBQWUsQ0FBQThHLFVBQVMsRUFBRSxHQUFHQSxNQUFNLENBQUM2QixFQUFFeE4sRUFBRSxHQUFHLEVBQUU0RSxZQUFZNEksRUFBRXhOLEVBQUUsS0FBTTJSLFVBQVUsR0FBSSxFQUFFO0FBQUEsb0JBQ2xHLFdBQVcscUZBQXFGL00sWUFBWTRJLEVBQUV4TixFQUFFLEtBQU0yUixVQUFVLElBQUssaURBQWlELDREQUE0RDtBQUFBLG9CQUVsUDtBQUFBLDZDQUFDLFVBQUssa0JBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBUTtBQUFBLHNCQUNSLHVCQUFDLFVBQUssV0FBVSw2QkFBNkIvTSxzQkFBWTRJLEVBQUV4TixFQUFFLEtBQU0yUixVQUFVLElBQUssV0FBVyxTQUE3RjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFtRztBQUFBO0FBQUE7QUFBQSxrQkFMckc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU1BO0FBQUEsbUJBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBc0JBO0FBQUEsY0FHQSx1QkFBQyxTQUFJLFdBQVUsMkZBQ1pDO0FBQUFBLDBCQUNDLHVCQUFDLFdBQU0sS0FBS3BFLEVBQUVMLFVBQVUsVUFBUSxNQUFDLFdBQVUsOEJBQTZCLFVBQVEsTUFBQyxPQUFLLE1BQUMsTUFBSSxRQUEzRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEyRixJQUUzRix1QkFBQyxTQUFJLEtBQUtLLEVBQUVMLFVBQVUsS0FBS0ssRUFBRVAsT0FBTyxXQUFVLGdDQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEwRTtBQUFBLGlCQUUxRXJJLFlBQVk0SSxFQUFFeE4sRUFBRSxLQUFNMlIsVUFBVSxNQUNoQyx1QkFBQyxTQUFJLFdBQVUsK0hBQ2I7QUFBQSx5Q0FBQyxVQUFLLGtCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQVE7QUFBQSxrQkFBTztBQUFBLHFCQURqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBVEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFXQTtBQUFBLGNBR0EsdUJBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLHFDQUNiLGlDQUFDLFNBQUksV0FBVSwyQkFFYjtBQUFBLHlDQUFDLFNBQUksV0FBVSxZQUNaek47QUFBQUEsNENBQXdCc0osRUFBRXhOLE1BQ3pCLHVCQUFDLFNBQUksV0FBVSxvSkFDWjtBQUFBLHNCQUNDLEVBQUVpUyxPQUFPLFFBQVFDLE1BQU0sS0FBSztBQUFBLHNCQUM1QixFQUFFRCxPQUFPLFFBQVFDLE1BQU0sS0FBSztBQUFBLHNCQUM1QixFQUFFRCxPQUFPLFFBQVFDLE1BQU0sS0FBSztBQUFBLHNCQUM1QixFQUFFRCxPQUFPLE9BQU9DLE1BQU0sS0FBSztBQUFBLHNCQUMzQixFQUFFRCxPQUFPLFFBQVFDLE1BQU0sS0FBSztBQUFBLHNCQUM1QixFQUFFRCxPQUFPLFNBQVNDLE1BQU0sS0FBSztBQUFBLG9CQUFDLEVBQzlCdEc7QUFBQUEsc0JBQUksQ0FBQXVHLFNBQ0o7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBRUMsU0FBUyxDQUFDakosTUFBTTtBQUNkQSw4QkFBRWtKLGdCQUFnQjtBQUNsQi9OLDhDQUFrQixDQUFBc0gsVUFBUyxFQUFFLEdBQUdBLE1BQU0sQ0FBQzZCLEVBQUV4TixFQUFFLEdBQUdtUyxLQUFLRCxLQUFLLEVBQUU7QUFDMURyTywwQ0FBYyxDQUFBOEgsVUFBUyxFQUFFLEdBQUdBLE1BQU0sQ0FBQzZCLEVBQUV4TixFQUFFLEdBQUcsS0FBSyxFQUFFO0FBQ2pEbUUsbURBQXVCLElBQUk7QUFBQSwwQkFDN0I7QUFBQSwwQkFDQSxXQUFVO0FBQUEsMEJBQ1YsT0FBT2dPLEtBQUtGO0FBQUFBLDBCQUVaO0FBQUEsbURBQUMsVUFBSyxXQUFVLFdBQVdFLGVBQUtELFFBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBQXFDO0FBQUEsNEJBQ3JDLHVCQUFDLFVBQUssV0FBVSwyQ0FBMkNDLGVBQUtGLFNBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBQXNFO0FBQUE7QUFBQTtBQUFBLHdCQVhqRUUsS0FBS0Y7QUFBQUEsd0JBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFhQTtBQUFBLG9CQUNELEtBdkJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBd0JBO0FBQUEsb0JBRUY7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsYUFBYSxNQUFNO0FBQ2pCbk4sd0NBQWN1TixRQUFRN0UsRUFBRXhOLEVBQUUsSUFBSXNLLFdBQVcsTUFBTTtBQUM3Q25HLG1EQUF1QnFKLEVBQUV4TixFQUFFO0FBQUEsMEJBQzdCLEdBQUcsR0FBSTtBQUFBLHdCQUNUO0FBQUEsd0JBQ0EsV0FBVyxNQUFNO0FBQ2YsOEJBQUk4RSxjQUFjdU4sUUFBUTdFLEVBQUV4TixFQUFFLEdBQUc7QUFDL0JzUyx5Q0FBYXhOLGNBQWN1TixRQUFRN0UsRUFBRXhOLEVBQUUsQ0FBQztBQUN4QzhFLDBDQUFjdU4sUUFBUTdFLEVBQUV4TixFQUFFLElBQUk7QUFBQSwwQkFDaEM7QUFBQSx3QkFDRjtBQUFBLHdCQUNBLGNBQWMsTUFBTTtBQUNsQiw4QkFBSThFLGNBQWN1TixRQUFRN0UsRUFBRXhOLEVBQUUsR0FBRztBQUMvQnNTLHlDQUFheE4sY0FBY3VOLFFBQVE3RSxFQUFFeE4sRUFBRSxDQUFDO0FBQ3hDOEUsMENBQWN1TixRQUFRN0UsRUFBRXhOLEVBQUUsSUFBSTtBQUFBLDBCQUNoQztBQUFBLHdCQUNGO0FBQUEsd0JBQ0EsY0FBYyxNQUFNO0FBQ2xCOEUsd0NBQWN1TixRQUFRN0UsRUFBRXhOLEVBQUUsSUFBSXNLLFdBQVcsTUFBTTtBQUM3Q25HLG1EQUF1QnFKLEVBQUV4TixFQUFFO0FBQUEsMEJBQzdCLEdBQUcsR0FBSTtBQUFBLHdCQUNUO0FBQUEsd0JBQ0EsWUFBWSxNQUFNO0FBQ2hCLDhCQUFJOEUsY0FBY3VOLFFBQVE3RSxFQUFFeE4sRUFBRSxHQUFHO0FBQy9Cc1MseUNBQWF4TixjQUFjdU4sUUFBUTdFLEVBQUV4TixFQUFFLENBQUM7QUFDeEM4RSwwQ0FBY3VOLFFBQVE3RSxFQUFFeE4sRUFBRSxJQUFJO0FBQUEsMEJBQ2hDO0FBQUEsd0JBQ0Y7QUFBQSx3QkFDQSxTQUFTLE1BQU07QUFDYiw4QkFBSWtFLHdCQUF3QnNKLEVBQUV4TixHQUFJO0FBQ2xDNkQsd0NBQWMsQ0FBQThILFVBQVMsRUFBRSxHQUFHQSxNQUFNLENBQUM2QixFQUFFeE4sRUFBRSxHQUFHLENBQUMyTCxLQUFLNkIsRUFBRXhOLEVBQUUsRUFBRSxFQUFFO0FBQUEsd0JBQzFEO0FBQUEsd0JBQ0EsV0FBVTtBQUFBLHdCQUNWLE9BQU07QUFBQSx3QkFFTjtBQUFBLGlEQUFDLFNBQU0sV0FBVyxXQUFXOFIsVUFBVSw4QkFBOEIsZ0NBQWdDLE1BQXJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQXdHO0FBQUEsMEJBQ3ZHMU4sZUFBZW9KLEVBQUV4TixFQUFFLEtBQ2xCLHVCQUFDLFVBQUssV0FBVSxvRkFDYm9FLHlCQUFlb0osRUFBRXhOLEVBQUUsS0FEdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FFQTtBQUFBO0FBQUE7QUFBQSxzQkF4Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQTBDQTtBQUFBLHVCQXRFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQXVFQTtBQUFBLGtCQUdBLHVCQUFDLFlBQU8sV0FBVSxxREFBb0QsT0FBTSxXQUMxRSxpQ0FBQyxpQkFBYyxXQUFVLGFBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWtDLEtBRHBDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkE5RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkErRUEsS0FoRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFpRkE7QUFBQSxnQkFHQSx1QkFBQyxTQUFJLFdBQVUsZ0NBQ1orUjtBQUFBQTtBQUFBQSxrQkFBVztBQUFBLHFCQURkO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFHQSx1QkFBQyxTQUFJLFdBQVUseUJBQ2I7QUFBQSx5Q0FBQyxZQUFPLFdBQVUscUJBQXFCdkUsWUFBRVIsY0FBYyxzQkFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMEU7QUFBQSxrQkFDMUUsdUJBQUMsVUFBSyxXQUFVLGlDQUFpQ1E7QUFBQUEsc0JBQUVQO0FBQUFBLG9CQUFNO0FBQUEsdUJBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTBEO0FBQUEsa0JBQ3pETyxFQUFFTjtBQUFBQSxxQkFITDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUlBO0FBQUEsZ0JBR0EsdUJBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLDZCQUEyQjtBQUFBO0FBQUEsb0JBQzlCOEUsYUFBYXpWO0FBQUFBLG9CQUFPO0FBQUEsdUJBRGhDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQ3lWLGFBQWFwRztBQUFBQSxvQkFBSSxDQUFDQyxNQUNqQix1QkFBQyxTQUFlLFdBQVUseUJBQ3hCO0FBQUEsNkNBQUMsWUFBTyxXQUFVLHFCQUFvQjtBQUFBO0FBQUEsd0JBQUVBLEVBQUVrQjtBQUFBQSwyQkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBaUQ7QUFBQSxzQkFDakQsdUJBQUMsVUFBTWxCLFlBQUV2QyxRQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWM7QUFBQSx5QkFGTnVDLEVBQUU3TCxJQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBR0E7QUFBQSxrQkFDRDtBQUFBLHFCQVRIO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBVUE7QUFBQSxnQkFHQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxVQUFVLENBQUFrSixNQUFLO0FBQ2JBLHdCQUFFQyxlQUFlO0FBQ2pCLDRCQUFNRyxPQUFPdEYsaUJBQWlCd0osRUFBRXhOLEVBQUU7QUFDbEMsMEJBQUksQ0FBQ3NKLFFBQVEsQ0FBQ0EsS0FBS3pNLEtBQUssRUFBRztBQUMzQiw0QkFBTTBWLGFBQWEsRUFBRXZTLElBQUltTCxLQUFLSyxJQUFJLEVBQUVDLFNBQVMsR0FBR3NCLFFBQVF0UCxhQUFhK0ksWUFBWSxRQUFROEMsTUFBTUEsS0FBS3pNLEtBQUssR0FBR3FLLE1BQU0sV0FBVztBQUM3SG5ELHVDQUFpQixDQUFBNEgsVUFBUztBQUFBLHdCQUN4QixHQUFHQTtBQUFBQSx3QkFDSCxDQUFDNkIsRUFBRXhOLEVBQUUsR0FBRyxDQUFDLEdBQUkyTCxLQUFLNkIsRUFBRXhOLEVBQUUsS0FBS3dOLEVBQUVJLFlBQVksSUFBSzJFLFVBQVU7QUFBQSxzQkFDMUQsRUFBRTtBQUNGdE8sMENBQW9CLENBQUEwSCxVQUFTLEVBQUUsR0FBR0EsTUFBTSxDQUFDNkIsRUFBRXhOLEVBQUUsR0FBRyxHQUFHLEVBQUU7QUFBQSxvQkFDdkQ7QUFBQSxvQkFDQSxXQUFVO0FBQUEsb0JBRVY7QUFBQTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxNQUFLO0FBQUEsMEJBQ0wsT0FBT2dFLGlCQUFpQndKLEVBQUV4TixFQUFFLEtBQUs7QUFBQSwwQkFDakMsVUFBVSxDQUFBa0osTUFBS2pGLG9CQUFvQixDQUFBMEgsVUFBUyxFQUFFLEdBQUdBLE1BQU0sQ0FBQzZCLEVBQUV4TixFQUFFLEdBQUdrSixFQUFFcUQsT0FBTzZFLE1BQU0sRUFBRTtBQUFBLDBCQUNoRixhQUFZO0FBQUEsMEJBQ1osV0FBVTtBQUFBO0FBQUEsd0JBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQUs4RjtBQUFBLHNCQUU5Rix1QkFBQyxZQUFPLE1BQUssVUFBUyxVQUFVLENBQUNwTixpQkFBaUJ3SixFQUFFeE4sRUFBRSxHQUFHbkQsS0FBSyxHQUFHLFdBQVUsMkVBQXlFLG9CQUFwSjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUE7QUFBQTtBQUFBLGtCQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBd0JBO0FBQUEsbUJBdElGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBdUlBO0FBQUEsaUJBaExRMlEsRUFBRXhOLElBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFpTEE7QUFBQSxVQUVKLENBQUM7QUFBQSxVQUdBNEMsT0FBT3JHLFdBQVcsS0FDakIsdUJBQUMsU0FBSSxXQUFVLDJGQUNiO0FBQUEsbUNBQUMsT0FBRSxXQUFVLHlCQUF3Qiw2QkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0Q7QUFBQSxZQUNsRCx1QkFBQyxPQUFFLFdBQVUseUJBQXdCLGdFQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxRjtBQUFBLGVBRnZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQXpNSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMk1BO0FBQUEsV0F6T0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTBPQTtBQUFBLE1BSURxRCxjQUFjLFdBQ2IsdUJBQUMsU0FBSSxXQUFVLHVCQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsaUNBQUMsU0FDQztBQUFBLG1DQUFDLFFBQUcsV0FBVSxxQ0FBb0MsNkNBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStFO0FBQUEsWUFDL0UsdUJBQUMsT0FBRSxXQUFVLDBCQUF5Qix1RUFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkY7QUFBQSxlQUYvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUFNQyxhQUFhLE1BQU07QUFBQSxjQUNsQyxXQUFVO0FBQUEsY0FBb0U7QUFBQTtBQUFBLFlBRmhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtBO0FBQUEsYUFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBV0E7QUFBQSxRQUdBLHVCQUFDLFNBQUksV0FBVSx3RUFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSwyREFDYjtBQUFBLG1DQUFDLFVBQUs7QUFBQTtBQUFBLGNBQWVtQjtBQUFBQSxjQUFpQjtBQUFBLGNBQVFFO0FBQUFBLGNBQWtCO0FBQUEsaUJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1FO0FBQUEsWUFDbkUsdUJBQUMsVUFBSywyQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpQjtBQUFBLGVBRm5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSx3REFDYixpQ0FBQyxTQUFJLFdBQVUsdUJBQXNCLE9BQU8sRUFBRXNSLE9BQU8sR0FBSXhSLG1CQUFtQkUsb0JBQXFCLEdBQUcsSUFBSSxLQUF4RztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyRyxLQUQ3RztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxRQUdBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLDZEQUE0RCwrQkFBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUY7QUFBQSxVQUN6Rix1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVMsTUFBTU0sd0JBQXdCRCx5QkFBeUIsVUFBVSxPQUFPLE9BQU87QUFBQSxnQkFDeEYsV0FBVyxnRkFBZ0ZBLHlCQUF5QixVQUFVLG1EQUFtRCx5Q0FBeUM7QUFBQSxnQkFFMU47QUFBQSx5Q0FBQyxTQUFJLFdBQVUsd0ZBQ2IsaUNBQUMsYUFBVSxXQUFVLGFBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQThCLEtBRGhDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxRQUFHLFdBQVUsb0NBQW1DLHNCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF1RDtBQUFBLGtCQUN2RCx1QkFBQyxPQUFFLFdBQVUsOEJBQTZCLDhCQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF3RDtBQUFBO0FBQUE7QUFBQSxjQVIxRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFTQTtBQUFBLFlBRUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFTLE1BQU1DLHdCQUF3QkQseUJBQXlCLFNBQVMsT0FBTyxNQUFNO0FBQUEsZ0JBQ3RGLFdBQVcsZ0ZBQWdGQSx5QkFBeUIsU0FBUyxtREFBbUQseUNBQXlDO0FBQUEsZ0JBRXpOO0FBQUEseUNBQUMsU0FBSSxXQUFVLHdGQUNiLGlDQUFDLFlBQVMsV0FBVSxhQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE2QixLQUQvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsUUFBRyxXQUFVLG9DQUFtQyxxQkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBc0Q7QUFBQSxrQkFDdEQsdUJBQUMsT0FBRSxXQUFVLDhCQUE2QixrQ0FBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNEQ7QUFBQTtBQUFBO0FBQUEsY0FSOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBU0E7QUFBQSxZQUVBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBUyxNQUFNQyx3QkFBd0JELHlCQUF5QixVQUFVLE9BQU8sT0FBTztBQUFBLGdCQUN4RixXQUFXLGdGQUFnRkEseUJBQXlCLFVBQVUsbURBQW1ELHlDQUF5QztBQUFBLGdCQUUxTjtBQUFBLHlDQUFDLFNBQUksV0FBVSx3RkFDYixpQ0FBQyxRQUFLLFdBQVUsYUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBeUIsS0FEM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLFFBQUcsV0FBVSxvQ0FBbUMsc0JBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXVEO0FBQUEsa0JBQ3ZELHVCQUFDLE9BQUUsV0FBVSw4QkFBNkIsa0NBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTREO0FBQUE7QUFBQTtBQUFBLGNBUjlEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVNBO0FBQUEsWUFFQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVMsTUFBTUMsd0JBQXdCRCx5QkFBeUIsV0FBVyxPQUFPLFFBQVE7QUFBQSxnQkFDMUYsV0FBVyxnRkFBZ0ZBLHlCQUF5QixXQUFXLG1EQUFtRCx5Q0FBeUM7QUFBQSxnQkFFM047QUFBQSx5Q0FBQyxTQUFJLFdBQVUsd0ZBQ2IsaUNBQUMscUJBQWtCLFdBQVUsYUFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBc0MsS0FEeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLFFBQUcsV0FBVSxvQ0FBbUMsMkJBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTREO0FBQUEsa0JBQzVELHVCQUFDLE9BQUUsV0FBVSw4QkFBNkIsNkJBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXVEO0FBQUE7QUFBQTtBQUFBLGNBUnpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVNBO0FBQUEsWUFFQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVMsTUFBTUMsd0JBQXdCRCx5QkFBeUIsVUFBVSxPQUFPLE9BQU87QUFBQSxnQkFDeEYsV0FBVyxnRkFBZ0ZBLHlCQUF5QixVQUFVLG1EQUFtRCx5Q0FBeUM7QUFBQSxnQkFFMU47QUFBQSx5Q0FBQyxTQUFJLFdBQVUsd0ZBQ2IsaUNBQUMsT0FBSSxXQUFVLGFBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBd0IsS0FEMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLFFBQUcsV0FBVSxvQ0FBbUMsd0JBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXlEO0FBQUEsa0JBQ3pELHVCQUFDLE9BQUUsV0FBVSw4QkFBNkIsNkJBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXVEO0FBQUE7QUFBQTtBQUFBLGNBUnpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVNBO0FBQUEsZUF0REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF1REE7QUFBQSxhQXpERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMERBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsb0dBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsNEhBQ2I7QUFBQSxtQ0FBQyxVQUFLO0FBQUE7QUFBQSxjQUFhQSx1QkFBdUIsSUFBSUEsb0JBQW9CLGFBQWE7QUFBQSxpQkFBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0Y7QUFBQSxZQUNqRkEsd0JBQ0MsdUJBQUMsWUFBTyxTQUFTLE1BQU1DLHdCQUF3QixJQUFJLEdBQUcsV0FBVSwwREFBeUQsNEJBQXpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFJO0FBQUEsZUFIekk7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLFVBRUNMLFdBQ0V4RSxPQUFPLENBQUFDLE1BQUssQ0FBQzJFLHdCQUF3QjNFLEVBQUUwRSxTQUFTQyxvQkFBb0IsRUFDcEVxSztBQUFBQSxZQUFJLENBQUFVLFNBQ0gsdUJBQUMsU0FBa0IsV0FBVSw4RUFDM0I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUscUZBQ2IsaUNBQUMsVUFBTyxXQUFVLDRCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEwQyxLQUQ1QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FDQztBQUFBLHlDQUFDLFFBQUcsV0FBVSxvQ0FBb0NBLGVBQUtyTSxRQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE0RDtBQUFBLGtCQUM1RCx1QkFBQyxVQUFLLFdBQVUsMEJBQTBCcU07QUFBQUEseUJBQUtuUDtBQUFBQSxvQkFBSztBQUFBLG9CQUFJbVAsS0FBS2pMO0FBQUFBLHVCQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF5RTtBQUFBLHFCQUYzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsbUJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFRQTtBQUFBLGNBRUEsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsdUNBQUMsVUFBSyxXQUFVLGlGQUFpRmlMLGVBQUtoTCxRQUF0RztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEyRztBQUFBLGdCQUMzRztBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxTQUFTLE1BQU11TSxzQkFBc0J2QixLQUFLdE0sSUFBSXNNLEtBQUtuUCxJQUFJO0FBQUEsb0JBQ3ZELFdBQVU7QUFBQSxvQkFDVixPQUFNO0FBQUEsb0JBRU4saUNBQUMsVUFBTyxXQUFVLGFBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTJCO0FBQUE7QUFBQSxrQkFMN0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU1BO0FBQUEsbUJBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFTQTtBQUFBLGlCQXBCUW1QLEtBQUt0TSxJQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBcUJBO0FBQUEsVUFDSDtBQUFBLGFBakNIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFrQ0E7QUFBQSxXQXpIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMEhBO0FBQUEsTUFJREosY0FBYyxZQUFZbkMsWUFBWW1KLFdBQVduSixZQUFZb0osa0JBQzVELHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsaUNBQUMsU0FDQztBQUFBLG1DQUFDLFFBQUcsV0FBVSxxQ0FBb0Msa0NBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9FO0FBQUEsWUFDcEUsdUJBQUMsT0FBRSxXQUFVLDBCQUF5QixrRkFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0c7QUFBQSxlQUYxRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUFNaEgsYUFBYSxNQUFNO0FBQUEsY0FDbEMsV0FBVTtBQUFBLGNBQW9FO0FBQUE7QUFBQSxZQUZoRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLGFBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVdBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsd0VBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsMERBQ2I7QUFBQSxtQ0FBQyxVQUFPLE1BQUssTUFBSyxTQUFTc0gsWUFBWS9KLFdBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStDO0FBQUEsWUFDL0MsdUJBQUMsU0FDQztBQUFBLHFDQUFDLFFBQUcsV0FBVSxvQ0FBbUMsZ0NBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlFO0FBQUEsY0FDakUsdUJBQUMsT0FBRSxXQUFVLDBCQUF5QixpR0FBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBdUg7QUFBQSxpQkFGekg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLGVBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsc0NBQXFDLHdCQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE4RDtBQUFBLGNBQzlEO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxPQUFPK0osWUFBWUU7QUFBQUEsa0JBQ25CLFVBQVUsQ0FBQTZCLE1BQUs5QixlQUFlLEVBQUUsR0FBR0QsYUFBYUUsV0FBVzZCLEVBQUVxRCxPQUFPNkUsTUFBTSxDQUFDO0FBQUEsa0JBQzNFLFdBQVU7QUFBQTtBQUFBLGdCQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUl1RztBQUFBLGlCQU56RztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSxzQ0FBcUMsaUNBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXVFO0FBQUEsY0FDdkU7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE9BQU9qSyxZQUFZRztBQUFBQSxrQkFDbkIsVUFBVSxDQUFBNEIsTUFBSzlCLGVBQWUsRUFBRSxHQUFHRCxhQUFhRyxRQUFRNEIsRUFBRXFELE9BQU82RSxNQUFNLENBQUM7QUFBQSxrQkFDeEUsV0FBVTtBQUFBO0FBQUEsZ0JBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSXVHO0FBQUEsaUJBTnpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEscUNBQUMsV0FBTSxXQUFVLHNDQUFxQywrQkFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUU7QUFBQSxjQUNyRTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsT0FBT2pLLFlBQVlJO0FBQUFBLGtCQUNuQixVQUFVLENBQUEyQixNQUFLOUIsZUFBZSxFQUFFLEdBQUdELGFBQWFJLFdBQVcyQixFQUFFcUQsT0FBTzZFLE1BQU0sQ0FBQztBQUFBLGtCQUMzRSxXQUFVO0FBQUE7QUFBQSxnQkFKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FJdUc7QUFBQSxpQkFOekc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsc0NBQXFDLG9CQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEwRDtBQUFBLGNBQzFELHVCQUFDLFNBQUksV0FBVSxxRkFDYjtBQUFBLHVDQUFDLFVBQUssV0FBVSwwQ0FDYjlOLDJCQUFpQjZELFlBQVkvSixVQUFVLCtCQUErQixxQkFEekU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFdBQU0sV0FBVSxpTEFDZjtBQUFBLHlDQUFDLGNBQVcsV0FBVSxhQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUErQjtBQUFBO0FBQUEsa0JBRS9CO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxRQUFPO0FBQUEsc0JBQ1AsVUFBVSxDQUFBOEwsTUFBSztBQUNiLDhCQUFNb0QsT0FBT3BELEVBQUVxRCxPQUFPQyxRQUFRLENBQUM7QUFDL0IsNEJBQUlGLE1BQU07QUFDUi9JLDBDQUFnQitJLEtBQUtyTSxJQUFJO0FBQ3pCLGdDQUFNd00sU0FBUyxJQUFJQyxXQUFXO0FBQzlCRCxpQ0FBT0UsWUFBWSxNQUFNO0FBQ3ZCdkYsMkNBQWUsRUFBRSxHQUFHRCxhQUFhL0osU0FBU3FQLE9BQU9HLE9BQWlCLENBQUM7QUFBQSwwQkFDckU7QUFDQUgsaUNBQU9JLGNBQWNQLElBQUk7QUFBQSx3QkFDM0I7QUFBQSxzQkFDRjtBQUFBLHNCQUNBLFdBQVU7QUFBQTtBQUFBLG9CQWRaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFjb0I7QUFBQSxxQkFqQnRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBbUJBO0FBQUEsbUJBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBd0JBO0FBQUEsaUJBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMkJBO0FBQUEsZUExREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEyREE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLHNDQUFxQyw2QkFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUU7QUFBQSxZQUNuRTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE9BQU9uRixZQUFZSztBQUFBQSxnQkFDbkIsVUFBVSxDQUFBMEIsTUFBSzlCLGVBQWUsRUFBRSxHQUFHRCxhQUFhSyxXQUFXMEIsRUFBRXFELE9BQU82RSxNQUFNLENBQUM7QUFBQSxnQkFDM0UsTUFBTTtBQUFBLGdCQUNOLFdBQVU7QUFBQTtBQUFBLGNBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSXVHO0FBQUEsZUFOekc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsc0NBQXFDLGtDQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3RTtBQUFBLFlBQ3hFLHVCQUFDLFNBQUksV0FBVSwyQkFDWixXQUFDLFdBQVcsV0FBVyxXQUFXLFdBQVcsV0FBVyxTQUFTLEVBQUV4RjtBQUFBQSxjQUFJLENBQUE2RyxVQUN0RTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFFQyxTQUFTLE1BQU1yTCxlQUFlLEVBQUUsR0FBR0QsYUFBYU0sY0FBY2dMLE1BQU0sQ0FBQztBQUFBLGtCQUNyRSxXQUFXLGdEQUFnRHRMLFlBQVlNLGlCQUFpQmdMLFFBQVEseUNBQXlDLG9CQUFvQjtBQUFBLGtCQUM3SixPQUFPLEVBQUVDLGlCQUFpQkQsTUFBTTtBQUFBO0FBQUEsZ0JBSDNCQTtBQUFBQSxnQkFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0M7QUFBQSxZQUNGLEtBUkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFTQTtBQUFBLGVBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFZQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsc0NBQXFDLDBCQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnRTtBQUFBLFlBQ2hFLHVCQUFDLFNBQUksV0FBVSwwQkFDWCxXQUFDLFNBQVMsUUFBUSxnQkFBZ0IsRUFBWTdHO0FBQUFBLGNBQUksQ0FBQStHLFNBQ2xEO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUVDLFNBQVMsTUFBTWxPLGFBQWFrTyxJQUFJO0FBQUEsa0JBQ2hDLFdBQVcsb0VBQW9Fbk8sY0FBY21PLE9BQU8sdURBQXVELGlFQUFpRTtBQUFBLGtCQUUzTkE7QUFBQUE7QUFBQUEsZ0JBSklBO0FBQUFBLGdCQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNQTtBQUFBLFlBQ0QsS0FUSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVVBO0FBQUEsZUFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWFBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsb0VBQ2I7QUFBQSxtQ0FBQyxTQUNFakwsMEJBQ0MsdUJBQUMsVUFBSyxXQUFVLG1HQUNiQSwwQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBLEtBSko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFNQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFTLE1BQU07QUFDYkMsa0NBQWdCLG9DQUFvQztBQUNwRDJDLDZCQUFXLE1BQU0zQyxnQkFBZ0IsRUFBRSxHQUFHLEdBQUk7QUFBQSxnQkFDNUM7QUFBQSxnQkFDQSxXQUFVO0FBQUEsZ0JBRVY7QUFBQSx5Q0FBQyxTQUFNLFdBQVUsYUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVA1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFTQTtBQUFBLGVBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBa0JBO0FBQUEsYUEvSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWdJQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxXQUFVLHdFQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsbUNBQUMsUUFBRyxXQUFVLDhEQUNaO0FBQUEscUNBQUMsYUFBVSxXQUFVLDRCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2QztBQUFBO0FBQUEsaUJBRC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNDbEssWUFBWW9KLGlCQUNYLHVCQUFDLFVBQUssV0FBVSxrRkFBZ0YsNENBQWhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQVJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVUE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSw2QkFDWlAscUJBQVdzRjtBQUFBQSxZQUFJLENBQUF5QyxNQUNkLHVCQUFDLFNBQWUsV0FBVSwwQ0FDeEI7QUFBQSxxQ0FBQyxTQUNDO0FBQUEsdUNBQUMsU0FBSSxXQUFVLG9DQUFtQztBQUFBO0FBQUEsa0JBQUVBLEVBQUU3SDtBQUFBQSxrQkFBUztBQUFBLGtCQUFFNkgsRUFBRXhILGlCQUFpQix1QkFBQyxVQUFLLFdBQVUsMEVBQXlFLDRCQUF6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFxRztBQUFBLHFCQUF6TDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpTTtBQUFBLGdCQUNqTSx1QkFBQyxTQUFJLFdBQVUsMEJBQTBCd0g7QUFBQUEsb0JBQUU1SDtBQUFBQSxrQkFBTTtBQUFBLGtCQUFJNEgsRUFBRTFIO0FBQUFBLHFCQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE4RDtBQUFBLG1CQUZoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FFQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSx1Q0FBQyxVQUFLLFdBQVcsa0RBQWtEMEgsRUFBRXpILFVBQVUsZ0NBQWdDLDJCQUEyQixJQUN2SXlILFlBQUV6SCxVQUFVLFVBQVUsY0FEekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNDLENBQUN5SCxFQUFFeEgsaUJBQ0YsbUNBQ0U7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxTQUFTLE1BQU1zSCxrQkFBa0JFLEVBQUVyTyxFQUFFO0FBQUEsc0JBQ3JDLFdBQVU7QUFBQSxzQkFFVHFPLFlBQUV6SCxVQUFVLFdBQVc7QUFBQTtBQUFBLG9CQUoxQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBS0E7QUFBQSxrQkFDQ25KLFlBQVlvSixpQkFDWDtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxTQUFTLE1BQU0rSCxpQkFBaUJQLEVBQUVyTyxFQUFFO0FBQUEsc0JBQ3BDLFdBQVU7QUFBQSxzQkFDVixPQUFNO0FBQUEsc0JBQStCO0FBQUE7QUFBQSxvQkFIdkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQU1BO0FBQUEscUJBZEo7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFnQkE7QUFBQSxtQkFyQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkF1QkE7QUFBQSxpQkE3QlFxTyxFQUFFck8sSUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQThCQTtBQUFBLFVBQ0QsS0FqQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFrQ0E7QUFBQSxhQS9DRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0RBO0FBQUEsUUFHQ3ZDLFlBQVlvSixpQkFDWCx1QkFBQyxTQUFJLFdBQVUsNEVBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxtQ0FBQyxVQUFPLFdBQVUsNEJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBDO0FBQUEsWUFDMUMsdUJBQUMsUUFBRyxXQUFVLHNDQUFxQywrREFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0c7QUFBQSxlQUZwRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxPQUFFLFdBQVUsMEJBQXlCLHVKQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2SztBQUFBLFVBRTdLLHVCQUFDLFNBQUksV0FBVSxrQkFDYixpQ0FBQyxTQUFJLFdBQVUsY0FDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLGFBQVk7QUFBQSxnQkFDWixJQUFHO0FBQUEsZ0JBQ0gsV0FBVTtBQUFBO0FBQUEsY0FKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJbUc7QUFBQSxZQUVuRztBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTLE1BQU07QUFDYix3QkFBTStMLFFBQVFoQyxTQUFTaUMsZUFBZSx3QkFBd0I7QUFDOUQsc0JBQUksQ0FBQ0QsU0FBUyxDQUFDQSxNQUFNeEIsTUFBTXZVLEtBQUssRUFBRztBQUNuQyx3QkFBTWlXLGdCQUFnQiw4QkFBOEJGLE1BQU14QixLQUFLO0FBQy9EeFAsOEJBQVksQ0FBQStKLFNBQVE7QUFDbEIsMEJBQU1vSCxVQUFVLEVBQUUsR0FBR3BILEtBQUs7QUFDMUJ1RSwyQkFBTzhDLEtBQUtELE9BQU8sRUFBRUUsUUFBUSxDQUFBdkgsY0FBYTtBQUN4Q3FILDhCQUFRckgsU0FBUyxJQUFJO0FBQUEsd0JBQ25CLEdBQUlxSCxRQUFRckgsU0FBUyxLQUFLO0FBQUEsd0JBQzFCO0FBQUEsMEJBQ0UxTCxJQUFJbUwsS0FBS0ssSUFBSSxFQUFFQyxTQUFTO0FBQUEsMEJBQ3hCNUosUUFBUXBFLFlBQVkrSTtBQUFBQSwwQkFDcEIxRSxTQUFTZ1I7QUFBQUEsMEJBQ1R6UyxZQUFXLG9CQUFJOEssS0FBSyxHQUFFQyxtQkFBbUIsSUFBSSxFQUFFQyxNQUFNLFdBQVdDLFFBQVEsVUFBVSxDQUFDO0FBQUEsMEJBQ25Gb0csZ0JBQWdCO0FBQUEsMEJBQ2hCM1AsUUFBUTtBQUFBLHdCQUNWO0FBQUEsc0JBQUM7QUFBQSxvQkFFTCxDQUFDO0FBQ0QsMkJBQU9nUjtBQUFBQSxrQkFDVCxDQUFDO0FBQ0RoTTtBQUFBQSxvQkFBWSxDQUFBNEUsU0FBUTtBQUFBLHNCQUNsQixFQUFFM0wsSUFBSSxLQUFLbUwsS0FBS0ssSUFBSSxDQUFDLElBQUl4RSxRQUFRLHNCQUFzQjRMLE1BQU14QixLQUFLLEtBQUtuSyxNQUFNeEosWUFBWStJLFVBQVVVLE9BQU0sb0JBQUlpRSxLQUFLLEdBQUVDLG1CQUFtQixJQUFJLEVBQUVDLE1BQU0sV0FBV0MsUUFBUSxVQUFVLENBQUMsRUFBRTtBQUFBLHNCQUNuTCxHQUFHSztBQUFBQSxvQkFBSTtBQUFBLGtCQUNSO0FBQ0RpSCx3QkFBTXhCLFFBQVE7QUFDZDlELHdCQUFNLGlFQUFpRTtBQUFBLGdCQUN6RTtBQUFBLGdCQUNBLFdBQVU7QUFBQSxnQkFBMEg7QUFBQTtBQUFBLGNBOUJ0STtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFpQ0E7QUFBQSxlQXhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXlDQSxLQTFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTJDQTtBQUFBLGFBbERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFtREE7QUFBQSxRQUlGLHVCQUFDLFNBQUksV0FBVSx3RUFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxvRUFDYjtBQUFBLG1DQUFDLFNBQ0M7QUFBQSxxQ0FBQyxRQUFHLFdBQVUsOERBQ1o7QUFBQSx1Q0FBQyxpQkFBYyxXQUFVLDRCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpRDtBQUFBO0FBQUEsbUJBRG5EO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNBLHVCQUFDLE9BQUUsV0FBVSxpQ0FBZ0Msc0dBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1JO0FBQUEsaUJBTHJJO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBTUE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFNBQVMsTUFBTXRJLGNBQWMsRUFBRUMsUUFBUSxNQUFNQyxVQUFVLE1BQU1DLEtBQUssTUFBTUMsYUFBYSxNQUFNQyxpQkFBaUIsTUFBTUMsVUFBVSxNQUFNQyxZQUFZLE1BQU1DLFlBQVksTUFBTUMsV0FBVyxNQUFNQyxXQUFXLE1BQU1DLFVBQVUsTUFBTUMsZ0JBQWdCLE1BQU1DLFFBQVEsTUFBTUMsU0FBUyxNQUFNQyxVQUFVLE1BQU1DLFNBQVMsTUFBTUMsYUFBYSxNQUFNQyxXQUFXLE1BQU1DLE9BQU8sS0FBSyxDQUFDO0FBQUEsa0JBQzNWLFdBQVU7QUFBQSxrQkFBaUg7QUFBQTtBQUFBLGdCQUY3SDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsU0FBUyxNQUFNbkIsY0FBYyxFQUFFQyxRQUFRLE9BQU9DLFVBQVUsT0FBT0MsS0FBSyxPQUFPQyxhQUFhLE9BQU9DLGlCQUFpQixPQUFPQyxVQUFVLE9BQU9DLFlBQVksT0FBT0MsWUFBWSxPQUFPQyxXQUFXLE9BQU9DLFdBQVcsT0FBT0MsVUFBVSxPQUFPQyxnQkFBZ0IsT0FBT0MsUUFBUSxPQUFPQyxTQUFTLE9BQU9DLFVBQVUsT0FBT0MsU0FBUyxPQUFPQyxhQUFhLE9BQU9DLFdBQVcsT0FBT0MsT0FBTyxNQUFNLENBQUM7QUFBQSxrQkFDOVcsV0FBVTtBQUFBLGtCQUFpSDtBQUFBO0FBQUEsZ0JBRjdIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsaUJBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFhQTtBQUFBLGVBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBc0JBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUseUNBQ1o7QUFBQSxZQUNDLEVBQUU4SixLQUFLLFVBQVVnQyxPQUFPLHNCQUFzQjtBQUFBLFlBQzlDLEVBQUVoQyxLQUFLLFlBQVlnQyxPQUFPLDZCQUE2QmlCLFVBQVUsV0FBVztBQUFBLFlBQzVFLEVBQUVqRCxLQUFLLE9BQU9nQyxPQUFPLHlCQUF5QjtBQUFBLFlBQzlDLEVBQUVoQyxLQUFLLGVBQWVnQyxPQUFPLGVBQWU7QUFBQSxZQUM1QyxFQUFFaEMsS0FBSyxtQkFBbUJnQyxPQUFPLHFCQUFxQmlCLFVBQVUsa0JBQWtCO0FBQUEsWUFDbEYsRUFBRWpELEtBQUssaUJBQWlCZ0MsT0FBTyxpQkFBaUJpQixVQUFVLFdBQVc7QUFBQSxZQUNyRSxFQUFFakQsS0FBSyxjQUFjZ0MsT0FBTyxpQkFBaUI7QUFBQSxZQUM3QyxFQUFFaEMsS0FBSyxjQUFjZ0MsT0FBTyxlQUFlaUIsVUFBVSxhQUFhO0FBQUEsWUFDbEUsRUFBRWpELEtBQUssYUFBYWdDLE9BQU8sbUNBQW1DaUIsVUFBVSxZQUFZO0FBQUEsWUFDcEYsRUFBRWpELEtBQUssYUFBYWdDLE9BQU8sYUFBYTtBQUFBLFlBQ3hDLEVBQUVoQyxLQUFLLFlBQVlnQyxPQUFPLGdCQUFnQjtBQUFBLFlBQzFDLEVBQUVoQyxLQUFLLGtCQUFrQmdDLE9BQU8sOEJBQThCO0FBQUEsWUFDOUQsRUFBRWhDLEtBQUssV0FBV2dDLE9BQU8sZUFBZTtBQUFBLFlBQ3hDLEVBQUVoQyxLQUFLLFlBQVlnQyxPQUFPLGdCQUFnQjtBQUFBLFlBQzFDLEVBQUVoQyxLQUFLLFdBQVdnQyxPQUFPLG9CQUFvQjtBQUFBLFlBQzdDLEVBQUVoQyxLQUFLLGVBQWVnQyxPQUFPLGdCQUFnQmlCLFVBQVUsY0FBYztBQUFBLFlBQ3JFLEVBQUVqRCxLQUFLLGFBQWFnQyxPQUFPLGFBQWE7QUFBQSxZQUN4QyxFQUFFaEMsS0FBSyxTQUFTZ0MsT0FBTyxVQUFVaUIsVUFBVSxRQUFRO0FBQUEsWUFDbkQsRUFBRWpELEtBQUssVUFBVWdDLE9BQU8sWUFBWTtBQUFBLFVBQUMsRUFDckNyRyxJQUFJLENBQUF1RyxTQUFRO0FBQ1osa0JBQU1nQixNQUFPcE8sV0FBbUJvTixLQUFLZSxZQUFZZixLQUFLbEMsR0FBRztBQUN6RCxtQkFDRSx1QkFBQyxXQUFxQixXQUFVLHlJQUM5QjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxTQUFTa0Q7QUFBQUEsa0JBQ1QsVUFBVSxDQUFBakssTUFBS2xFLGNBQWMsRUFBRSxHQUFHRCxZQUFZLENBQUNvTixLQUFLZSxZQUFZZixLQUFLbEMsR0FBRyxHQUFHL0csRUFBRXFELE9BQU82RyxRQUFRLENBQUM7QUFBQSxrQkFDN0YsV0FBVTtBQUFBO0FBQUEsZ0JBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSTBFO0FBQUEsY0FFMUUsdUJBQUMsVUFBSyxXQUFVLCtDQUErQ2pCLGVBQUtGLFNBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTBFO0FBQUEsaUJBUGhFRSxLQUFLbEMsS0FBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBLFVBRUosQ0FBQyxLQWxDSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1DQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLG9FQUNiO0FBQUEsbUNBQUMsU0FDRTdKLDhCQUNDLHVCQUFDLFVBQUssV0FBVSxtR0FDYkEsOEJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQSxLQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBTUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBU3lKO0FBQUFBLGdCQUNULFdBQVU7QUFBQSxnQkFFVjtBQUFBLHlDQUFDLFlBQVMsV0FBVSxhQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSi9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1BO0FBQUEsZUFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWVBO0FBQUEsYUE3RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQThFQTtBQUFBLFdBM1VGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE0VUE7QUFBQSxNQUlEalEsY0FBYyxjQUNiLHVCQUFDLFNBQUksV0FBVSx1QkFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSxxQ0FBb0MseUNBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJFO0FBQUEsVUFDM0U7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVMsTUFBTUMsYUFBYSxNQUFNO0FBQUEsY0FDbEMsV0FBVTtBQUFBLGNBQW9FO0FBQUE7QUFBQSxZQUZoRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLGFBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsZ0dBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxtQ0FBQyxVQUFPLE1BQUssTUFBSyxTQUFTc0gsWUFBWS9KLFdBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStDO0FBQUEsWUFDL0MsdUJBQUMsU0FDQztBQUFBLHFDQUFDLFFBQUcsV0FBVSxvQ0FBb0MrSixzQkFBWUUsYUFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBd0U7QUFBQSxjQUN4RSx1QkFBQyxVQUFLLFdBQVUsNkRBQTZERixzQkFBWUcsVUFBekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0c7QUFBQSxpQkFGbEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLGVBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVMsTUFBTTVKLGVBQWUsSUFBSTtBQUFBLGNBQ2xDLFdBQVU7QUFBQSxjQUNWLE9BQU07QUFBQSxjQUVOO0FBQUEsdUNBQUMsVUFBTyxXQUFVLGFBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFMN0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT0E7QUFBQSxhQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnQkE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSx3RUFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSwwQkFBeUI7QUFBQTtBQUFBLFlBQW1CLHVCQUFDLFlBQU8sV0FBVSxrQkFBaUI7QUFBQTtBQUFBLGNBQUVELFlBQVkrSTtBQUFBQSxpQkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEQ7QUFBQSxlQUFySDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4SDtBQUFBLFVBQzlILHVCQUFDLFNBQUksV0FBVSwwQkFBeUI7QUFBQTtBQUFBLFlBQWlCL0ksWUFBWWtKO0FBQUFBLGVBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRFO0FBQUEsVUFDNUUsdUJBQUMsU0FBSSxXQUFVLDBCQUF5QjtBQUFBO0FBQUEsWUFBZWxKLFlBQVlpQjtBQUFBQSxlQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErRTtBQUFBLFVBQy9FLHVCQUFDLFNBQUksV0FBVSx5REFBeUR5SSxzQkFBWUssYUFBcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEY7QUFBQSxhQUpoRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxRQUdBLHVCQUFDLFNBQUksV0FBVSx3RUFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxvRUFDYjtBQUFBLG1DQUFDLFNBQ0M7QUFBQSxxQ0FBQyxRQUFHLFdBQVUsNERBQTBEO0FBQUE7QUFBQSxnQkFFckVqTSw4QkFBOEIyTSxlQUFlLEVBQUVqTCxjQUM5Qyx1QkFBQyxVQUFLLFdBQVUsK0dBQThHLE9BQU0saUNBQWdDLGlCQUFwSztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFxSztBQUFBLG1CQUh6SztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsY0FDQSx1QkFBQyxPQUFFLFdBQVUsMEJBQXlCLHlHQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErSDtBQUFBLGlCQVBqSTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsY0FDYixpQ0FBQyxVQUFLLFdBQVcsOENBQThDMUIsOEJBQThCMk0sZUFBZSxFQUFFakwsYUFBYSw4QkFBOEIsNkJBQTZCLElBQ25MMUI7QUFBQUEsNENBQThCMk0sZUFBZSxFQUFFcEw7QUFBQUEsY0FBTTtBQUFBLGNBQWF2Qiw4QkFBOEIyTSxlQUFlLEVBQUV4TDtBQUFBQSxjQUFZO0FBQUEsaUJBRGhJO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUlBO0FBQUEsZUFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWVBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSxzQ0FBcUMsZ0NBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNFO0FBQUEsY0FDdEU7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE9BQU93TCxnQkFBZ0J4TTtBQUFBQSxrQkFDdkIsVUFBVSxDQUFBd04sTUFBS2YsbUJBQW1CLEVBQUUsR0FBR0QsaUJBQWlCeE0sY0FBY3dOLEVBQUVxRCxPQUFPNkUsTUFBTSxDQUFDO0FBQUEsa0JBQ3RGLFdBQVU7QUFBQTtBQUFBLGdCQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUl1RztBQUFBLGlCQU56RztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSxzQ0FBcUMsb0NBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTBFO0FBQUEsY0FDMUU7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE9BQU9sSixnQkFBZ0JyTTtBQUFBQSxrQkFDdkIsVUFBVSxDQUFBcU4sTUFBS2YsbUJBQW1CLEVBQUUsR0FBR0QsaUJBQWlCck0sa0JBQWtCcU4sRUFBRXFELE9BQU82RSxNQUFNLENBQUM7QUFBQSxrQkFDMUYsV0FBVTtBQUFBO0FBQUEsZ0JBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSXVHO0FBQUEsaUJBTnpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEscUNBQUMsV0FBTSxXQUFVLHNDQUFxQyxvQ0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMEU7QUFBQSxjQUMxRTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsT0FBT2xKLGdCQUFnQnBNO0FBQUFBLGtCQUN2QixVQUFVLENBQUFvTixNQUFLZixtQkFBbUIsRUFBRSxHQUFHRCxpQkFBaUJwTSxrQkFBa0JvTixFQUFFcUQsT0FBTzZFLE1BQU0sQ0FBQztBQUFBLGtCQUMxRixXQUFVO0FBQUE7QUFBQSxnQkFKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FJdUc7QUFBQSxpQkFOekc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsc0NBQXFDLGdDQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFzRTtBQUFBLGNBQ3RFO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxPQUFPbEosZ0JBQWdCL0w7QUFBQUEsa0JBQ3ZCLFVBQVUsQ0FBQStNLE1BQUtmLG1CQUFtQixFQUFFLEdBQUdELGlCQUFpQi9MLGNBQWMrTSxFQUFFcUQsT0FBTzZFLE1BQU0sQ0FBQztBQUFBLGtCQUN0RixXQUFVO0FBQUE7QUFBQSxnQkFKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FJdUc7QUFBQSxpQkFOekc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsc0NBQXFDLGtEQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3RjtBQUFBLGNBQ3hGO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxPQUFPbEosZ0JBQWdCbE07QUFBQUEsa0JBQ3ZCLFVBQVUsQ0FBQWtOLE1BQUtmLG1CQUFtQixFQUFFLEdBQUdELGlCQUFpQmxNLGlCQUFpQmtOLEVBQUVxRCxPQUFPNkUsTUFBTSxDQUFDO0FBQUEsa0JBQ3pGLFdBQVU7QUFBQTtBQUFBLGdCQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUl1RztBQUFBLGlCQU56RztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSxzQ0FBcUMsK0JBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFFO0FBQUEsY0FDckU7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE9BQU9sSixnQkFBZ0JqTTtBQUFBQSxrQkFDdkIsVUFBVSxDQUFBaU4sTUFBS2YsbUJBQW1CLEVBQUUsR0FBR0QsaUJBQWlCak0sYUFBYWlOLEVBQUVxRCxPQUFPNkUsTUFBTSxDQUFDO0FBQUEsa0JBQ3JGLFdBQVU7QUFBQTtBQUFBLGdCQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUl1RztBQUFBLGlCQU56RztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSxzQ0FBcUMsaUNBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXVFO0FBQUEsY0FDdkU7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE9BQU9sSixnQkFBZ0JoTTtBQUFBQSxrQkFDdkIsVUFBVSxDQUFBZ04sTUFBS2YsbUJBQW1CLEVBQUUsR0FBR0QsaUJBQWlCaE0sZUFBZWdOLEVBQUVxRCxPQUFPNkUsTUFBTSxDQUFDO0FBQUEsa0JBQ3ZGLFdBQVU7QUFBQTtBQUFBLGdCQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUl1RztBQUFBLGlCQU56RztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSxzQ0FBcUMsa0NBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdFO0FBQUEsY0FDeEU7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE9BQU9sSixnQkFBZ0I5TDtBQUFBQSxrQkFDdkIsVUFBVSxDQUFBOE0sTUFBS2YsbUJBQW1CLEVBQUUsR0FBR0QsaUJBQWlCOUwsVUFBVThNLEVBQUVxRCxPQUFPNkUsTUFBTSxDQUFDO0FBQUEsa0JBQ2xGLFdBQVU7QUFBQTtBQUFBLGdCQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUl1RztBQUFBLGlCQU56RztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSxzQ0FBcUMsZ0VBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNHO0FBQUEsY0FDdEc7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE9BQU9sSixnQkFBZ0I3TDtBQUFBQSxrQkFDdkIsVUFBVSxDQUFBNk0sTUFBS2YsbUJBQW1CLEVBQUUsR0FBR0QsaUJBQWlCN0wsbUJBQW1CNk0sRUFBRXFELE9BQU82RSxNQUFNLENBQUM7QUFBQSxrQkFDM0YsV0FBVTtBQUFBO0FBQUEsZ0JBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSXVHO0FBQUEsaUJBTnpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEscUNBQUMsV0FBTSxXQUFVLHNDQUFxQyx3REFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBOEY7QUFBQSxjQUM5RjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsT0FBT2xKLGdCQUFnQjFMO0FBQUFBLGtCQUN2QixVQUFVLENBQUEwTSxNQUFLZixtQkFBbUIsRUFBRSxHQUFHRCxpQkFBaUIxTCx1QkFBdUIwTSxFQUFFcUQsT0FBTzZFLE1BQU0sQ0FBQztBQUFBLGtCQUMvRixXQUFVO0FBQUE7QUFBQSxnQkFKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FJdUc7QUFBQSxpQkFOekc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsc0NBQXFDLDBDQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnRjtBQUFBLGNBQ2hGO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxPQUFPbEosZ0JBQWdCekw7QUFBQUEsa0JBQ3ZCLFVBQVUsQ0FBQXlNLE1BQUtmLG1CQUFtQixFQUFFLEdBQUdELGlCQUFpQnpMLGVBQWV5TSxFQUFFcUQsT0FBTzZFLE1BQU0sQ0FBQztBQUFBLGtCQUN2RixXQUFVO0FBQUE7QUFBQSxnQkFKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FJdUc7QUFBQSxpQkFOekc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBLGVBN0dGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBOEdBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSxzQ0FBcUMsd0NBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThFO0FBQUEsWUFDOUU7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFNO0FBQUEsZ0JBQ04sT0FBT2xKLGdCQUFnQm5NO0FBQUFBLGdCQUN2QixVQUFVLENBQUFtTixNQUFLZixtQkFBbUIsRUFBRSxHQUFHRCxpQkFBaUJuTSxxQkFBcUJtTixFQUFFcUQsT0FBTzZFLE1BQU0sQ0FBQztBQUFBLGdCQUM3RixXQUFVO0FBQUE7QUFBQSxjQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUl1RztBQUFBLGVBTnpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUUE7QUFBQSxVQUdBLHVCQUFDLFNBQUksV0FBVSx3RUFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEscUNBQUMsV0FBTSxXQUFVLHNDQUFxQyxpQ0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBdUU7QUFBQSxjQUN2RSx1QkFBQyxTQUFJLFdBQVUscUZBQ1psSjtBQUFBQSxnQ0FBZ0J2TSxlQUNmLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLHlDQUFDLFNBQUksS0FBS3VNLGdCQUFnQnZNLGNBQWMsV0FBVSx3RUFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBc0g7QUFBQSxrQkFDdEgsdUJBQUMsVUFBSyxXQUFVLCtDQUE4QyxvQ0FBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBa0Y7QUFBQSxrQkFDbEY7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLFNBQVMsTUFBTXdNLG1CQUFtQixFQUFFLEdBQUdELGlCQUFpQnZNLGNBQWMsR0FBRyxDQUFDO0FBQUEsc0JBQzFFLFdBQVU7QUFBQSxzQkFDVixPQUFNO0FBQUEsc0JBRU4saUNBQUMsVUFBTyxXQUFVLGlCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUErQjtBQUFBO0FBQUEsb0JBTmpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFPQTtBQUFBLHFCQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBV0EsSUFFQSx1QkFBQyxVQUFLLFdBQVUsMENBQXlDLGtDQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEyRTtBQUFBLGdCQUU3RSx1QkFBQyxXQUFNLFdBQVUsaUxBQ2Y7QUFBQSx5Q0FBQyxjQUFXLFdBQVUsYUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBK0I7QUFBQTtBQUFBLGtCQUUvQjtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsUUFBTztBQUFBLHNCQUNQLFVBQVUsQ0FBQXVOLE1BQUs7QUFDYiw4QkFBTW9ELE9BQU9wRCxFQUFFcUQsT0FBT0MsUUFBUSxDQUFDO0FBQy9CLDRCQUFJRixNQUFNO0FBQ1IsZ0NBQU1HLFNBQVMsSUFBSUMsV0FBVztBQUM5QkQsaUNBQU9FLFlBQVksTUFBTTtBQUN2QnhFLCtDQUFtQixFQUFFLEdBQUdELGlCQUFpQnZNLGNBQWM4USxPQUFPRyxPQUFpQixDQUFDO0FBQUEsMEJBQ2xGO0FBQ0FILGlDQUFPSSxjQUFjUCxJQUFJO0FBQUEsd0JBQzNCO0FBQUEsc0JBQ0Y7QUFBQSxzQkFDQSxXQUFVO0FBQUE7QUFBQSxvQkFiWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBYW9CO0FBQUEscUJBaEJ0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWtCQTtBQUFBLG1CQW5DRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW9DQTtBQUFBLGlCQXRDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXVDQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsc0NBQXFDLCtCQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFxRTtBQUFBLGNBQ3JFLHVCQUFDLFNBQUksV0FBVSxxRkFDWnBFO0FBQUFBLGdDQUFnQnRNLGFBQ2YsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEseUNBQUMsU0FBSSxLQUFLc00sZ0JBQWdCdE0sWUFBWSxXQUFVLG9FQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnSDtBQUFBLGtCQUNoSCx1QkFBQyxVQUFLLFdBQVUsK0NBQThDLGtDQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnRjtBQUFBLGtCQUNoRjtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsU0FBUyxNQUFNdU0sbUJBQW1CLEVBQUUsR0FBR0QsaUJBQWlCdE0sWUFBWSxHQUFHLENBQUM7QUFBQSxzQkFDeEUsV0FBVTtBQUFBLHNCQUNWLE9BQU07QUFBQSxzQkFFTixpQ0FBQyxVQUFPLFdBQVUsaUJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQStCO0FBQUE7QUFBQSxvQkFOakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQU9BO0FBQUEscUJBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFXQSxJQUVBLHVCQUFDLFVBQUssV0FBVSwwQ0FBeUMsa0NBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTJFO0FBQUEsZ0JBRTdFLHVCQUFDLFdBQU0sV0FBVSxpTEFDZjtBQUFBLHlDQUFDLGNBQVcsV0FBVSxhQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUErQjtBQUFBO0FBQUEsa0JBRS9CO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxRQUFPO0FBQUEsc0JBQ1AsVUFBVSxDQUFBc04sTUFBSztBQUNiLDhCQUFNb0QsT0FBT3BELEVBQUVxRCxPQUFPQyxRQUFRLENBQUM7QUFDL0IsNEJBQUlGLE1BQU07QUFDUixnQ0FBTUcsU0FBUyxJQUFJQyxXQUFXO0FBQzlCRCxpQ0FBT0UsWUFBWSxNQUFNO0FBQ3ZCeEUsK0NBQW1CLEVBQUUsR0FBR0QsaUJBQWlCdE0sWUFBWTZRLE9BQU9HLE9BQWlCLENBQUM7QUFBQSwwQkFDaEY7QUFDQUgsaUNBQU9JLGNBQWNQLElBQUk7QUFBQSx3QkFDM0I7QUFBQSxzQkFDRjtBQUFBLHNCQUNBLFdBQVU7QUFBQTtBQUFBLG9CQWJaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFhb0I7QUFBQSxxQkFoQnRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBa0JBO0FBQUEsbUJBbkNGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBb0NBO0FBQUEsaUJBdENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBdUNBO0FBQUEsZUFqRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFrRkE7QUFBQSxVQUdBLHVCQUFDLFNBQUksV0FBVSw0Q0FDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSxzRUFDZjtBQUFBLHFDQUFDLFVBQUs7QUFBQTtBQUFBLGdCQUFxQ3BFLGdCQUFnQjVMLGFBQWFDO0FBQUFBLGdCQUFPO0FBQUEsbUJBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFGO0FBQUEsY0FDckYsdUJBQUMsVUFBSyxXQUFVLDhCQUE2QixrREFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBK0U7QUFBQSxpQkFGakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLGFBQ1oyTCwwQkFBZ0I1TCxhQUFhc1A7QUFBQUEsY0FBSSxDQUFBdUcsU0FDaEMsdUJBQUMsU0FBa0IsV0FBVSx5RkFDM0I7QUFBQSx1Q0FBQyxTQUNDO0FBQUEseUNBQUMsU0FBSSxXQUFVLG9DQUFvQ0E7QUFBQUEseUJBQUtsUztBQUFBQSxvQkFBSztBQUFBLG9CQUFDLHVCQUFDLFVBQUssV0FBVSx1REFBdURrUyxlQUFLL0osU0FBNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBa0Y7QUFBQSx1QkFBaEo7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBdUo7QUFBQSxrQkFDdkosdUJBQUMsU0FBSSxXQUFVLDBCQUEwQitKLGVBQUs5SixlQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEwRDtBQUFBLHFCQUY1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsU0FBUyxNQUFNO0FBQ2IsNEJBQU0wSyxVQUFVN0ssZ0JBQWdCNUwsYUFBYUssT0FBTyxDQUFBa1AsTUFBS0EsRUFBRTdMLE9BQU9tUyxLQUFLblMsRUFBRTtBQUN6RW1JLHlDQUFtQixFQUFFLEdBQUdELGlCQUFpQjVMLGNBQWN5VyxRQUFRLENBQUM7QUFBQSxvQkFDbEU7QUFBQSxvQkFDQSxXQUFVO0FBQUEsb0JBRVYsaUNBQUMsU0FBTSxXQUFVLGFBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTBCO0FBQUE7QUFBQSxrQkFQNUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVFBO0FBQUEsbUJBYlFaLEtBQUtuUyxJQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBY0E7QUFBQSxZQUNELEtBakJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBa0JBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsOENBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsYUFBWTtBQUFBLGtCQUNaLE9BQU91STtBQUFBQSxrQkFDUCxVQUFVLENBQUFXLE1BQUtWLGNBQWNVLEVBQUVxRCxPQUFPNkUsS0FBSztBQUFBLGtCQUMzQyxXQUFVO0FBQUE7QUFBQSxnQkFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLOEY7QUFBQSxjQUU5RjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsYUFBWTtBQUFBLGtCQUNaLE9BQU8zSTtBQUFBQSxrQkFDUCxVQUFVLENBQUFTLE1BQUtSLGVBQWVRLEVBQUVxRCxPQUFPNkUsS0FBSztBQUFBLGtCQUM1QyxXQUFVO0FBQUE7QUFBQSxnQkFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLOEY7QUFBQSxjQUU5Rix1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxhQUFZO0FBQUEsb0JBQ1osT0FBT3pJO0FBQUFBLG9CQUNQLFVBQVUsQ0FBQU8sTUFBS04sY0FBY00sRUFBRXFELE9BQU82RSxLQUFLO0FBQUEsb0JBQzNDLFdBQVU7QUFBQTtBQUFBLGtCQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLcUc7QUFBQSxnQkFFckc7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsU0FBUyxNQUFNO0FBQ2IsMEJBQUk3SSxXQUFXMUwsS0FBSyxHQUFHO0FBQ3JCLDhCQUFNd1csVUFBVTtBQUFBLDBCQUNkclQsSUFBSSxPQUFPbUwsS0FBS0ssSUFBSSxDQUFDO0FBQUEsMEJBQ3JCdkwsTUFBTXNJLFdBQVcxTCxLQUFLO0FBQUEsMEJBQ3RCdUwsT0FBT0ssWUFBWTVMLEtBQUssS0FBSztBQUFBLDBCQUM3QndMLGFBQWFNLFdBQVc5TCxLQUFLO0FBQUEsd0JBQy9CO0FBQ0FzTCwyQ0FBbUI7QUFBQSwwQkFDakIsR0FBR0Q7QUFBQUEsMEJBQ0g1TCxjQUFjLENBQUMsR0FBRzRMLGdCQUFnQjVMLGNBQWMrVyxPQUFPO0FBQUEsd0JBQ3pELENBQUM7QUFDRDdLLHNDQUFjLEVBQUU7QUFDaEJFLHVDQUFlLEVBQUU7QUFDakJFLHNDQUFjLEVBQUU7QUFBQSxzQkFDbEI7QUFBQSxvQkFDRjtBQUFBLG9CQUNBLFdBQVU7QUFBQSxvQkFBZ0c7QUFBQTtBQUFBLGtCQWxCNUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQXFCQTtBQUFBLG1CQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQThCQTtBQUFBLGlCQTdDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQThDQTtBQUFBLGVBeEVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBeUVBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsb0VBQ2I7QUFBQSxtQ0FBQyxTQUNFQyx3QkFDQyx1QkFBQyxVQUFLLFdBQVUsbUdBQ2JBLHdCQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUEsS0FKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU1BO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVMsTUFBTTtBQUNiQyxnQ0FBYyxnREFBZ0Q7QUFDOUR3Qiw2QkFBVyxNQUFNeEIsY0FBYyxFQUFFLEdBQUcsR0FBSTtBQUFBLGdCQUMxQztBQUFBLGdCQUNBLFdBQVU7QUFBQSxnQkFFVjtBQUFBLHlDQUFDLFNBQU0sV0FBVSxhQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBUDVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVNBO0FBQUEsZUFqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFrQkE7QUFBQSxhQS9URjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ1VBO0FBQUEsV0F0V0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXVXQTtBQUFBLFNBejJDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNDJDQTtBQUFBLElBR0NsSSxvQkFDQyx1QkFBQyxTQUFJLFdBQVUsNEZBQ2IsaUNBQUMsU0FBSSxXQUFVLHlGQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLG9FQUNiO0FBQUEsK0JBQUMsUUFBRyxXQUFVLG9DQUFtQyxnQ0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRTtBQUFBLFFBQ2pFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTLE1BQU1DLG9CQUFvQixLQUFLO0FBQUEsWUFDeEMsV0FBVTtBQUFBLFlBQXFDO0FBQUE7QUFBQSxVQUZqRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLQTtBQUFBLFdBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsTUFDQSx1QkFBQyxVQUFLLFVBQVVvTCxrQkFBa0IsV0FBVSxhQUMxQztBQUFBLCtCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsaUNBQUMsV0FBTSxXQUFVLHNDQUFxQyxrQ0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0U7QUFBQSxVQUN4RTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsT0FBT25MO0FBQUFBLGNBQ1AsVUFBVSxDQUFBb0ksTUFBS25JLG9CQUFvQm1JLEVBQUVxRCxPQUFPNkUsS0FBSztBQUFBLGNBQ2pELGFBQVk7QUFBQSxjQUNaO0FBQUEsY0FDQSxXQUFVO0FBQUE7QUFBQSxZQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU0rSTtBQUFBLGFBUmpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLFdBQVU7QUFBQSxZQUFxSDtBQUFBO0FBQUEsVUFGakk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0E7QUFBQSxXQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBa0JBO0FBQUEsU0E1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTZCQSxLQTlCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBK0JBO0FBQUEsSUFJRGhQLHFCQUNDLHVCQUFDLFNBQUksV0FBVSw0RkFDYixpQ0FBQyxTQUFJLFdBQVUseUZBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsb0VBQ2I7QUFBQSwrQkFBQyxRQUFHLFdBQVUsb0NBQW1DLDBCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJEO0FBQUEsUUFDM0Q7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVMsTUFBTUMscUJBQXFCLEtBQUs7QUFBQSxZQUN6QyxXQUFVO0FBQUEsWUFBZ0U7QUFBQTtBQUFBLFVBRjVFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtBO0FBQUEsV0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSx5RkFBdUYsb0RBQXRHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWFBLEtBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWVBO0FBQUEsSUFJRHVGLDRCQUNDLHVCQUFDLFNBQUksV0FBVSw0RkFDYixpQ0FBQyxTQUFJLFdBQVUseUZBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsb0VBQ2I7QUFBQSwrQkFBQyxRQUFHLFdBQVUsNERBQ1o7QUFBQSxpQ0FBQyxVQUFPLFdBQVUsNEJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBDO0FBQUE7QUFBQSxhQUQ1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTLE1BQU1DLDRCQUE0QixLQUFLO0FBQUEsWUFDaEQsV0FBVTtBQUFBLFlBQXFDO0FBQUE7QUFBQSxVQUZqRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLQTtBQUFBLFdBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVdBO0FBQUEsTUFDQSx1QkFBQyxVQUFLLFVBQVVvQiwyQkFBMkIsV0FBVSxhQUNuRDtBQUFBLCtCQUFDLE9BQUUsV0FBVSwwQkFBeUIsc0hBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEk7QUFBQSxRQUM1SSx1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLGlDQUFDLFdBQU0sV0FBVSxzQ0FBcUMsOEJBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9FO0FBQUEsVUFDcEU7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLE9BQU9uQjtBQUFBQSxjQUNQLFVBQVUsQ0FBQW9CLE1BQUtuQixzQkFBc0JtQixFQUFFcUQsT0FBTzZFLEtBQUs7QUFBQSxjQUNuRCxhQUFZO0FBQUEsY0FDWjtBQUFBLGNBQ0E7QUFBQSxjQUNBLFdBQVU7QUFBQTtBQUFBLFlBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTytJO0FBQUEsYUFUako7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVdBO0FBQUEsUUFDQ3BKLHNCQUNDLHVCQUFDLFNBQUksV0FBVSxpREFBaURBLGdDQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1GO0FBQUEsUUFFckYsdUJBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFNBQVMsTUFBTUgsNEJBQTRCLEtBQUs7QUFBQSxjQUNoRCxXQUFVO0FBQUEsY0FBK0c7QUFBQTtBQUFBLFlBSDNIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1BO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsV0FBVTtBQUFBLGNBQXVIO0FBQUE7QUFBQSxZQUZuSTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLGFBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWNBO0FBQUEsV0EvQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWdDQTtBQUFBLFNBN0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E4Q0EsS0EvQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWdEQTtBQUFBLElBSURuRCxpQkFDQyx1QkFBQyxTQUFJLFdBQVUsd0ZBQ2IsaUNBQUMsU0FBSSxXQUFVLHVJQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLG1FQUNiO0FBQUEsK0JBQUMsUUFBRyxXQUFVLHlEQUF3RCx1Q0FBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2RjtBQUFBLFFBQzdGLHVCQUFDLFlBQU8sU0FBUyxNQUFNQyxpQkFBaUIsS0FBSyxHQUFHLFdBQVUsMENBQXlDLGlCQUFuRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9HO0FBQUEsV0FGdEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxVQUFLLFVBQVVtSSxtQkFBbUIsV0FBVSxhQUMzQztBQUFBLCtCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsaUNBQUMsV0FBTSxXQUFVLHlCQUF3QiwyQkFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0Q7QUFBQSxVQUNwRDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsT0FBT2hLO0FBQUFBLGNBQ1AsVUFBVSxDQUFBb0csTUFBS25HLGlCQUFpQm1HLEVBQUVxRCxPQUFPNkUsS0FBSztBQUFBLGNBQzlDLGFBQVk7QUFBQSxjQUNaO0FBQUEsY0FDQSxXQUFVO0FBQUE7QUFBQSxZQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU0wSjtBQUFBLGFBUjVKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxpQ0FBQyxXQUFNLFdBQVUseUJBQXdCLHVCQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnRDtBQUFBLFVBQ2hEO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxPQUFPcE87QUFBQUEsY0FDUCxVQUFVLENBQUFrRyxNQUFLakcsbUJBQW1CaUcsRUFBRXFELE9BQU82RSxLQUFLO0FBQUEsY0FDaEQsYUFBWTtBQUFBLGNBQ1osV0FBVTtBQUFBO0FBQUEsWUFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLMEo7QUFBQSxhQVA1SjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0E7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsaUNBQUMsV0FBTSxXQUFVLHlCQUF3QiwwQkFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUQ7QUFBQSxVQUNuRCx1QkFBQyxXQUFNLFdBQVUsb0tBQ2Y7QUFBQSxtQ0FBQyxjQUFXLFdBQVUsb0NBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNEO0FBQUEsWUFDdEQsdUJBQUMsVUFBSyxXQUFVLFlBQVloTyw4QkFBb0Isd0JBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFFO0FBQUEsWUFDckU7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsUUFBTztBQUFBLGdCQUNQLFVBQVVpSjtBQUFBQSxnQkFDVixXQUFVO0FBQUE7QUFBQSxjQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUlvQjtBQUFBLGVBUHRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBU0E7QUFBQSxhQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFZQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFNBQVMsTUFBTTFILGlCQUFpQixLQUFLO0FBQUEsY0FDckMsV0FBVTtBQUFBLGNBQXVGO0FBQUE7QUFBQSxZQUhuRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFVBQVVqQjtBQUFBQSxjQUNWLFdBQVU7QUFBQSxjQUVUQSwwQkFBZ0IsbUJBQW1CO0FBQUE7QUFBQSxZQUx0QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNQTtBQUFBLGFBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWVBO0FBQUEsV0FsREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW1EQTtBQUFBLFNBeERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F5REEsS0ExREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTJEQTtBQUFBLE9BMWhESjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNGhEQTtBQUVKO0FBQUNsRyxHQTE1RXVCRCxLQUFHO0FBQUEsTUFBSEE7QUFBRyxJQUFBRCxJQUFBZ1c7QUFBQSxhQUFBaFcsSUFBQTtBQUFBLGFBQUFnVyxLQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VSZWYiLCJTaGllbGQiLCJWaWRlbyIsIkltYWdlIiwiSW1hZ2VJY29uIiwiU2V0dGluZ3MiLCJBbGVydFRyaWFuZ2xlIiwiU2VuZCIsIkhlYXJ0IiwiTWVzc2FnZUNpcmNsZSIsIlBsdXMiLCJDaGVjayIsIkxvZ091dCIsIlRyYXNoMiIsIk1pYyIsIkhhcmREcml2ZSIsIkRvd25sb2FkIiwiQXJyb3dMZWZ0IiwiTW9yZVZlcnRpY2FsIiwiU2VhcmNoIiwiRm9sZGVyQXJjaGl2ZSIsIlRyYXNoIiwiVXNlclBsdXMiLCJVcGxvYWQiLCJVcGxvYWRJY29uIiwiVXNlckNoZWNrIiwiRm9sZGVyIiwiRmlsZVRleHQiLCJGaWxtIiwiTWVzc2FnZVNxdWFyZUNvZGUiLCJDaGV2cm9uRG93biIsIlBob25lIiwiSlNaaXAiLCJnZXRCdXNpbmVzc1ZlcmlmaWNhdGlvblN0YXR1cyIsInByb2ZpbGUiLCJmaWVsZHMiLCJidXNpbmVzc05hbWUiLCJwcm9maWxlUGhvdG8iLCJjb3ZlclBob3RvIiwiYnVzaW5lc3NVc2VybmFtZSIsImJ1c2luZXNzQ2F0ZWdvcnkiLCJidXNpbmVzc0Rlc2NyaXB0aW9uIiwicGh5c2ljYWxBZGRyZXNzIiwic2VydmljZUFyZWEiLCJidXNpbmVzc0hvdXJzIiwiZW1haWxBZGRyZXNzIiwid2Vic2l0ZXMiLCJmYWNlYm9va0luc3RhZ3JhbSIsImNhdGFsb2dJdGVtcyIsImxlbmd0aCIsInBheW1lbnRQYXJraW5nT3B0aW9ucyIsInN0YXR1c01lc3NhZ2UiLCJmaWxsZWRDb3VudCIsImZpbHRlciIsImYiLCJ0cmltIiwic2NvcmUiLCJNYXRoIiwicm91bmQiLCJpc1ZlcmlmaWVkIiwiTkNMb2dvIiwic2l6ZSIsImxvZ29VcmwiLCJkaW0iLCJfYyIsIkFwcCIsIl9zIiwiY3VycmVudFVzZXIiLCJzZXRDdXJyZW50VXNlciIsImF1dGhWaWV3Iiwic2V0QXV0aFZpZXciLCJ1c2VybmFtZUlucHV0Iiwic2V0VXNlcm5hbWVJbnB1dCIsImVtYWlsSW5wdXQiLCJzZXRFbWFpbElucHV0IiwibW9iaWxlSW5wdXQiLCJzZXRNb2JpbGVJbnB1dCIsInBhc3N3b3JkSW5wdXQiLCJzZXRQYXNzd29yZElucHV0IiwiZGV2aWNlSW5mbyIsInNldERldmljZUluZm8iLCJuYXZpZ2F0b3IiLCJ1c2VyQWdlbnQiLCJpbmNsdWRlcyIsImdlb0xvY2F0aW9uIiwic2V0R2VvTG9jYXRpb24iLCJhdXRoRXJyb3IiLCJzZXRBdXRoRXJyb3IiLCJhdXRoU3VjY2VzcyIsInNldEF1dGhTdWNjZXNzIiwidGVtcENvZGVJbnB1dCIsInNldFRlbXBDb2RlSW5wdXQiLCJuZXdQYXNzd29yZElucHV0Iiwic2V0TmV3UGFzc3dvcmRJbnB1dCIsInNpbXVsYXRlZENvZGUiLCJzZXRTaW11bGF0ZWRDb2RlIiwiY3VycmVudFBhc3N3b3JkSW5wdXQiLCJzZXRDdXJyZW50UGFzc3dvcmRJbnB1dCIsInVwZGF0ZWRQYXNzd29yZElucHV0Iiwic2V0VXBkYXRlZFBhc3N3b3JkSW5wdXQiLCJwYXNzd29yZFVwZGF0ZU1zZyIsInNldFBhc3N3b3JkVXBkYXRlTXNnIiwiYWN0aXZlVGFiIiwic2V0QWN0aXZlVGFiIiwiY29udGFjdHMiLCJzZXRDb250YWN0cyIsImlkIiwibmFtZSIsImhhbmRsZSIsImF2YXRhckJnIiwibGFzdE1lc3NhZ2UiLCJ0aW1lc3RhbXAiLCJ1bnJlYWRDb3VudCIsIm9ubGluZSIsImFjdGl2ZUNvbnRhY3QiLCJzZXRBY3RpdmVDb250YWN0Iiwic2VhcmNoUXVlcnkiLCJzZXRTZWFyY2hRdWVyeSIsImlzQWRkQ29udGFjdE9wZW4iLCJzZXRJc0FkZENvbnRhY3RPcGVuIiwibmV3Q29udGFjdEhhbmRsZSIsInNldE5ld0NvbnRhY3RIYW5kbGUiLCJkcml2ZVN0b3JhZ2VVc2VkIiwic2V0RHJpdmVTdG9yYWdlVXNlZCIsImRyaXZlU3RvcmFnZVRvdGFsIiwiZHJpdmVGaWxlcyIsInNldERyaXZlRmlsZXMiLCJjcmVhdGVkVGltZSIsInR5cGUiLCJzZWxlY3RlZEZvbGRlckZpbHRlciIsInNldFNlbGVjdGVkRm9sZGVyRmlsdGVyIiwiZHJpdmVFcnJvckFsZXJ0Iiwic2V0RHJpdmVFcnJvckFsZXJ0IiwibWVzc2FnZXMiLCJzZXRNZXNzYWdlcyIsInNlbmRlciIsImNvbnRlbnQiLCJpc0UyRUUiLCJjaGF0SW5wdXQiLCJzZXRDaGF0SW5wdXQiLCJzZWxmRGVzdHJ1Y3RUaW1lciIsInNldFNlbGZEZXN0cnVjdFRpbWVyIiwiaXNWaWRlb0NhbGxBY3RpdmUiLCJzZXRJc1ZpZGVvQ2FsbEFjdGl2ZSIsImlzQ2hhdE1lbnVPcGVuIiwic2V0SXNDaGF0TWVudU9wZW4iLCJpc1RvcE1lbnVPcGVuIiwic2V0SXNUb3BNZW51T3BlbiIsImlzSGVhZGVyU2VhcmNoT3BlbiIsInNldElzSGVhZGVyU2VhcmNoT3BlbiIsImFsYnVtcyIsInNldEFsYnVtcyIsIm5ld0FsYnVtVGl0bGUiLCJzZXROZXdBbGJ1bVRpdGxlIiwibmV3QWxidW1DYXB0aW9uIiwic2V0TmV3QWxidW1DYXB0aW9uIiwic2VsZWN0ZWREZXZpY2VJbWFnZSIsInNldFNlbGVjdGVkRGV2aWNlSW1hZ2UiLCJzZWxlY3RlZEZpbGVOYW1lIiwic2V0U2VsZWN0ZWRGaWxlTmFtZSIsImxvZ29GaWxlTmFtZSIsInNldExvZ29GaWxlTmFtZSIsImNvbW1lbnRJbnB1dHMiLCJzZXRDb21tZW50SW5wdXRzIiwiaXNDb21wcmVzc2luZyIsInNldElzQ29tcHJlc3NpbmciLCJhbGJ1bUxpa2VkIiwic2V0QWxidW1MaWtlZCIsImFsYnVtQ29tbWVudHMiLCJzZXRBbGJ1bUNvbW1lbnRzIiwiY29tbWVudElucHV0VGV4dCIsInNldENvbW1lbnRJbnB1dFRleHQiLCJyZWFjdGlvblBvcHVwUG9zdElkIiwic2V0UmVhY3Rpb25Qb3B1cFBvc3RJZCIsImFsYnVtUmVhY3Rpb25zIiwic2V0QWxidW1SZWFjdGlvbnMiLCJhY3RpdmVQcm9maWxlVGFiIiwic2V0QWN0aXZlUHJvZmlsZVRhYiIsInRoZW1lTW9kZSIsInNldFRoZW1lTW9kZSIsInNob3dDcmVhdGVCb3giLCJzZXRTaG93Q3JlYXRlQm94IiwiYWxidW1QaW5uZWQiLCJzZXRBbGJ1bVBpbm5lZCIsImxpa2VUaW1lcnNSZWYiLCJ6aXBPcHRpb25zIiwic2V0WmlwT3B0aW9ucyIsInNlcnZlciIsImFwaUluZGV4IiwiYXBwIiwicGFja2FnZUpzb24iLCJwYWNrYWdlTG9ja0pzb24iLCJ0c2NvbmZpZyIsInZpdGVDb25maWciLCJ2ZXJjZWxKc29uIiwicmVkaXJlY3RzIiwiaW5kZXhIdG1sIiwibWV0YWRhdGEiLCJmaXJlYmFzZUNvbmZpZyIsInJlYWRtZSIsIm1haW5Uc3giLCJpbmRleENzcyIsInZpdGVFbnYiLCJuZXRsaWZ5VG9tbCIsImdpdGlnbm9yZSIsIm5wbXJjIiwiemlwVXBkYXRlTWVzc2FnZSIsInNldFppcFVwZGF0ZU1lc3NhZ2UiLCJhZG1pblVzZXJzIiwic2V0QWRtaW5Vc2VycyIsInVzZXJuYW1lIiwiZW1haWwiLCJtb2JpbGUiLCJkZXZpY2UiLCJpc0FkbWluIiwiaXNNYXN0ZXJBZG1pbiIsImF1ZGl0TG9nIiwic2V0QXVkaXRMb2ciLCJhY3Rpb24iLCJ1c2VyIiwidGltZSIsInRoZW1lQ29uZmlnIiwic2V0VGhlbWVDb25maWciLCJ0aGVtZU5hbWUiLCJzbG9nYW4iLCJwb3dlcmVkQnkiLCJhYm91dFRleHQiLCJwcmltYXJ5Q29sb3IiLCJhZG1pblNhdmVNc2ciLCJzZXRBZG1pblNhdmVNc2ciLCJpc0FkbWluUGFzc3dvcmRNb2RhbE9wZW4iLCJzZXRJc0FkbWluUGFzc3dvcmRNb2RhbE9wZW4iLCJhZG1pblBhc3N3b3JkSW5wdXQiLCJzZXRBZG1pblBhc3N3b3JkSW5wdXQiLCJhZG1pblBhc3N3b3JkRXJyb3IiLCJzZXRBZG1pblBhc3N3b3JkRXJyb3IiLCJidXNpbmVzc1Byb2ZpbGUiLCJzZXRCdXNpbmVzc1Byb2ZpbGUiLCJwcmljZSIsImRlc2NyaXB0aW9uIiwicHJpY2VSYW5nZSIsIm5ld0NhdE5hbWUiLCJzZXROZXdDYXROYW1lIiwibmV3Q2F0UHJpY2UiLCJzZXROZXdDYXRQcmljZSIsIm5ld0NhdERlc2MiLCJzZXROZXdDYXREZXNjIiwiYml6U2F2ZU1zZyIsInNldEJpelNhdmVNc2ciLCJmZXRjaEFsYnVtcyIsImhhbmRsZU9wZW5BZG1pblN1aXRlIiwiaGFuZGxlVmVyaWZ5QWRtaW5QYXNzd29yZCIsImUiLCJwcmV2ZW50RGVmYXVsdCIsInJlcyIsImZldGNoIiwidGV4dCIsImRhdGEiLCJKU09OIiwicGFyc2UiLCJlcnIiLCJjb25zb2xlIiwiZXJyb3IiLCJoYW5kbGVSZWdpc3RlciIsIm1ldGhvZCIsImhlYWRlcnMiLCJib2R5Iiwic3RyaW5naWZ5IiwicGFzc3dvcmQiLCJFcnJvciIsInN0YXR1cyIsIm9rIiwic2V0VGltZW91dCIsIm1lc3NhZ2UiLCJoYW5kbGVMb2dpbiIsInVzZXJuYW1lT3JFbWFpbCIsImhhbmRsZUZvcmdvdFBhc3N3b3JkIiwic2ltdWxhdGVkRW1haWxDb2RlIiwiaGFuZGxlUmVzZXRQYXNzd29yZFN1Ym1pdCIsInRlbXBDb2RlIiwibmV3UGFzc3dvcmQiLCJoYW5kbGVTZW5kTWVzc2FnZSIsIm1lc3NhZ2VUZXh0IiwicGxheVN5c3RlbVNvdW5kIiwidGltZVN0ciIsIkRhdGUiLCJ0b0xvY2FsZVRpbWVTdHJpbmciLCJob3VyIiwibWludXRlIiwibmV3TXNnIiwibm93IiwidG9TdHJpbmciLCJjb250YWN0SWQiLCJwcmV2IiwibWFwIiwiYyIsIk51bWJlciIsInRvRml4ZWQiLCJtIiwiaGFuZGxlQWRkQ29udGFjdCIsInN0YXJ0c1dpdGgiLCJzbGljZSIsIm5ld0NvbnRhY3QiLCJoYW5kbGVGaWxlQ2hhbmdlIiwiZmlsZSIsInRhcmdldCIsImZpbGVzIiwicmVhZGVyIiwiRmlsZVJlYWRlciIsIm9ubG9hZGVuZCIsInJlc3VsdCIsInJlYWRBc0RhdGFVUkwiLCJoYW5kbGVDcmVhdGVBbGJ1bSIsImF1dGhvciIsImF1dGhvck5hbWUiLCJ0aXRsZSIsImNhcHRpb24iLCJpbWFnZVVybCIsInN1Y2Nlc3MiLCJhbGJ1bSIsImFsZXJ0IiwiaGFuZGxlTGlrZUFsYnVtIiwiYSIsImxpa2VzIiwiaGFuZGxlQ29tbWVudEFsYnVtIiwidGV4dElucHV0IiwiY29tbWVudHMiLCJoYW5kbGVEZWxldGVEcml2ZUZpbGUiLCJmaWxlSWQiLCJmaWxlU2l6ZVN0ciIsImZyZWVkTWIiLCJwYXJzZUZsb2F0IiwibWF4IiwiaGFuZGxlUHJvbW90ZVVzZXIiLCJ1c2VySWQiLCJ1IiwibmV4dElzQWRtaW4iLCJuZXh0VXNlcm5hbWUiLCJ0b1VwcGVyQ2FzZSIsInJhbmRvbVN1ZmZpeCIsImZsb29yIiwicmFuZG9tIiwiaGFuZGxlRGVsZXRlVXNlciIsImF1ZGlvQ3R4Iiwid2luZG93IiwiQXVkaW9Db250ZXh0Iiwid2Via2l0QXVkaW9Db250ZXh0Iiwib3NjIiwiY3JlYXRlT3NjaWxsYXRvciIsImdhaW4iLCJjcmVhdGVHYWluIiwiY29ubmVjdCIsImRlc3RpbmF0aW9uIiwiZnJlcXVlbmN5Iiwic2V0VmFsdWVBdFRpbWUiLCJjdXJyZW50VGltZSIsImV4cG9uZW50aWFsUmFtcFRvVmFsdWVBdFRpbWUiLCJzdGFydCIsInN0b3AiLCJoYW5kbGVEb3dubG9hZFNvdXJjZUFyY2hpdmUiLCJ6aXAiLCJvcHRpb25zS2V5TWFwIiwicGF0aCIsImtleSIsIk9iamVjdCIsImVudHJpZXMiLCJ3YXJuIiwiayIsInYiLCJqb2luIiwiZ2VuZXJhdGVBc3luYyIsInVybCIsIlVSTCIsImNyZWF0ZU9iamVjdFVSTCIsImRvY3VtZW50IiwiY3JlYXRlRWxlbWVudCIsImhyZWYiLCJkb3dubG9hZCIsImFwcGVuZENoaWxkIiwiY2xpY2siLCJyZW1vdmVDaGlsZCIsInJldm9rZU9iamVjdFVSTCIsInZhbHVlIiwiY2hhckF0IiwidG9Mb3dlckNhc2UiLCJjb250YWN0Iiwic3BsaXQiLCJtc2ciLCJpc0FkbWluV2FybmluZyIsImluZGV4IiwiaXNWaWRlbyIsImVuZHNXaXRoIiwiaXNMaWtlZCIsImxpa2VzQ291bnQiLCJjb21tZW50c0xpc3QiLCJsYWJlbCIsImljb24iLCJpdGVtIiwic3RvcFByb3BhZ2F0aW9uIiwiY3VycmVudCIsImNsZWFyVGltZW91dCIsIm5ld0NvbW1lbnQiLCJ3aWR0aCIsImNvbG9yIiwiYmFja2dyb3VuZENvbG9yIiwibW9kZSIsImlucHV0IiwiZ2V0RWxlbWVudEJ5SWQiLCJicm9hZGNhc3RUZXh0IiwidXBkYXRlZCIsImtleXMiLCJmb3JFYWNoIiwic3RhdGVLZXkiLCJ2YWwiLCJjaGVja2VkIiwibmV3SXRlbSIsIl9jMiJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBcHAudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGxpY2Vuc2VcbiAqIFNQRFgtTGljZW5zZS1JZGVudGlmaWVyOiBBcGFjaGUtMi4wXG4gKi9cblxuaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QsIHVzZVJlZiB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFxuICBNZXNzYWdlU3F1YXJlLCBTaGllbGQsIFZpZGVvLCBJbWFnZSBhcyBJbWFnZUljb24sIFVzZXJzLCBTZXR0aW5ncywgXG4gIExvY2ssIEtleSwgR2xvYmUsIFNtYXJ0cGhvbmUsIE1hcFBpbiwgQWxlcnRUcmlhbmdsZSwgU2VuZCwgSGVhcnQsIFxuICBNZXNzYWdlQ2lyY2xlLCBQbHVzLCBDaGVjaywgUmVmcmVzaEN3LCBMb2dPdXQsIFNwYXJrbGVzLCBUZXJtaW5hbCwgXG4gIEZpbGVTcHJlYWRzaGVldCwgVHJhc2gyLCBDYW1lcmEsIE1pYywgU2hhcmUyLCBDb21wYXNzLCBJbmZvLCBQYWxldHRlLCBGbG93ZXIyLFxuICBIYXJkRHJpdmUsIENsb3VkLCBDbG91ZFVwbG9hZCwgQ2xvdWRSYWluLCBEb3dubG9hZCwgQXJyb3dMZWZ0LCBNb3JlVmVydGljYWwsXG4gIFNlYXJjaCwgRm9sZGVyQXJjaGl2ZSwgQ2xvY2ssIFBhbGV0dGUgYXMgUGFsZXR0ZUljb24sIFRyYXNoLCBFeHRlcm5hbExpbmssIEJvb2ttYXJrLCBVc2VyUGx1cywgVXBsb2FkIGFzIFVwbG9hZEljb24sXG4gIFNsaWRlcnMsIFVzZXJDaGVjaywgU2hpZWxkQWxlcnQsIEZvbGRlciwgRmlsZVRleHQsIEZpbG0sIE1lc3NhZ2VTcXVhcmVDb2RlLCBDaGV2cm9uRG93biwgUGhvbmVcbn0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCBKU1ppcCBmcm9tICdqc3ppcCc7XG5cbmludGVyZmFjZSBVc2VyIHtcbiAgaWQ6IHN0cmluZztcbiAgdXNlcm5hbWU6IHN0cmluZztcbiAgZW1haWw6IHN0cmluZztcbiAgbW9iaWxlOiBzdHJpbmc7XG4gIGRldmljZTogc3RyaW5nO1xuICBnZW9Mb2NhdGlvbjogc3RyaW5nO1xuICBpc0FkbWluOiBib29sZWFuO1xuICBpc01hc3RlckFkbWluOiBib29sZWFuO1xuICBtdXN0Q2hhbmdlUGFzc3dvcmQ/OiBib29sZWFuO1xufVxuXG5pbnRlcmZhY2UgTWVzc2FnZSB7XG4gIGlkOiBzdHJpbmc7XG4gIHNlbmRlcjogc3RyaW5nO1xuICBjb250ZW50OiBzdHJpbmc7XG4gIHRpbWVzdGFtcDogc3RyaW5nO1xuICBpc0UyRUU6IGJvb2xlYW47XG4gIHNlbGZEZXN0cnVjdD86IG51bWJlcjtcbiAgaXNBZG1pbldhcm5pbmc/OiBib29sZWFuO1xufVxuXG5pbnRlcmZhY2UgQ29udGFjdCB7XG4gIGlkOiBzdHJpbmc7XG4gIG5hbWU6IHN0cmluZztcbiAgaGFuZGxlOiBzdHJpbmc7XG4gIGF2YXRhckJnOiBzdHJpbmc7XG4gIGxhc3RNZXNzYWdlOiBzdHJpbmc7XG4gIHRpbWVzdGFtcDogc3RyaW5nO1xuICB1bnJlYWRDb3VudD86IG51bWJlcjtcbiAgb25saW5lOiBib29sZWFuO1xufVxuXG5pbnRlcmZhY2UgQWxidW0ge1xuICBpZDogc3RyaW5nO1xuICBhdXRob3I6IHN0cmluZztcbiAgYXV0aG9yTmFtZTogc3RyaW5nO1xuICB0aXRsZTogc3RyaW5nO1xuICBjYXB0aW9uOiBzdHJpbmc7XG4gIGltYWdlVXJsOiBzdHJpbmc7XG4gIGxpa2VzOiBudW1iZXI7XG4gIGNvbW1lbnRzOiBBcnJheTx7IGlkOiBzdHJpbmc7IGF1dGhvcjogc3RyaW5nOyB0ZXh0OiBzdHJpbmc7IHRpbWU6IHN0cmluZyB9PjtcbiAgdGltZXN0YW1wOiBzdHJpbmc7XG59XG5cbmludGVyZmFjZSBEcml2ZUZpbGUge1xuICBpZDogc3RyaW5nO1xuICBuYW1lOiBzdHJpbmc7XG4gIHNpemU6IHN0cmluZztcbiAgY3JlYXRlZFRpbWU6IHN0cmluZztcbiAgdHlwZTogJ0ltYWdlJyB8ICdGaWxlJyB8ICdWaWRlbycgfCAnQmFja3VwJyB8ICdBdWRpbyc7XG59XG5cbmludGVyZmFjZSBDYXRhbG9nSXRlbSB7XG4gIGlkOiBzdHJpbmc7XG4gIG5hbWU6IHN0cmluZztcbiAgcHJpY2U6IHN0cmluZztcbiAgZGVzY3JpcHRpb246IHN0cmluZztcbiAgaW1hZ2VVcmw/OiBzdHJpbmc7XG59XG5cbmludGVyZmFjZSBCdXNpbmVzc1Byb2ZpbGUge1xuICBidXNpbmVzc05hbWU6IHN0cmluZztcbiAgcHJvZmlsZVBob3RvOiBzdHJpbmc7XG4gIGNvdmVyUGhvdG86IHN0cmluZztcbiAgYnVzaW5lc3NVc2VybmFtZTogc3RyaW5nO1xuICBidXNpbmVzc0NhdGVnb3J5OiBzdHJpbmc7XG4gIGJ1c2luZXNzRGVzY3JpcHRpb246IHN0cmluZztcbiAgcGh5c2ljYWxBZGRyZXNzOiBzdHJpbmc7XG4gIHNlcnZpY2VBcmVhOiBzdHJpbmc7XG4gIGJ1c2luZXNzSG91cnM6IHN0cmluZztcbiAgZW1haWxBZGRyZXNzOiBzdHJpbmc7XG4gIHdlYnNpdGVzOiBzdHJpbmc7XG4gIGZhY2Vib29rSW5zdGFncmFtOiBzdHJpbmc7XG4gIGNhdGFsb2dJdGVtczogQ2F0YWxvZ0l0ZW1bXTtcbiAgcHJpY2VSYW5nZTogc3RyaW5nO1xuICBwYXltZW50UGFya2luZ09wdGlvbnM6IHN0cmluZztcbiAgc3RhdHVzTWVzc2FnZTogc3RyaW5nO1xufVxuXG5mdW5jdGlvbiBnZXRCdXNpbmVzc1ZlcmlmaWNhdGlvblN0YXR1cyhwcm9maWxlOiBCdXNpbmVzc1Byb2ZpbGUpIHtcbiAgY29uc3QgZmllbGRzID0gW1xuICAgIHByb2ZpbGUuYnVzaW5lc3NOYW1lLFxuICAgIHByb2ZpbGUucHJvZmlsZVBob3RvLFxuICAgIHByb2ZpbGUuY292ZXJQaG90byxcbiAgICBwcm9maWxlLmJ1c2luZXNzVXNlcm5hbWUsXG4gICAgcHJvZmlsZS5idXNpbmVzc0NhdGVnb3J5LFxuICAgIHByb2ZpbGUuYnVzaW5lc3NEZXNjcmlwdGlvbixcbiAgICBwcm9maWxlLnBoeXNpY2FsQWRkcmVzcyxcbiAgICBwcm9maWxlLnNlcnZpY2VBcmVhLFxuICAgIHByb2ZpbGUuYnVzaW5lc3NIb3VycyxcbiAgICBwcm9maWxlLmVtYWlsQWRkcmVzcyxcbiAgICBwcm9maWxlLndlYnNpdGVzLFxuICAgIHByb2ZpbGUuZmFjZWJvb2tJbnN0YWdyYW0sXG4gICAgcHJvZmlsZS5jYXRhbG9nSXRlbXMubGVuZ3RoID4gMCA/ICd5ZXMnIDogJycsXG4gICAgcHJvZmlsZS5wYXltZW50UGFya2luZ09wdGlvbnMsXG4gICAgcHJvZmlsZS5zdGF0dXNNZXNzYWdlXG4gIF07XG4gIGNvbnN0IGZpbGxlZENvdW50ID0gZmllbGRzLmZpbHRlcihmID0+IGYgJiYgdHlwZW9mIGYgPT09ICdzdHJpbmcnICYmIGYudHJpbSgpICE9PSAnJykubGVuZ3RoO1xuICBjb25zdCBzY29yZSA9IE1hdGgucm91bmQoKGZpbGxlZENvdW50IC8gMTUpICogMTAwKTtcbiAgcmV0dXJuIHsgc2NvcmUsIGlzVmVyaWZpZWQ6IHNjb3JlID49IDgwLCBmaWxsZWRDb3VudCB9O1xufVxuXG4vLyBOQyBMb2dvIENvbXBvbmVudFxuZnVuY3Rpb24gTkNMb2dvKHsgc2l6ZSA9ICdtZCcsIGxvZ29VcmwgfTogeyBzaXplPzogJ3NtJyB8ICdtZCcgfCAnbGcnOyBsb2dvVXJsPzogc3RyaW5nIH0pIHtcbiAgaWYgKGxvZ29VcmwpIHtcbiAgICBjb25zdCBkaW0gPSBzaXplID09PSAnc20nID8gJ3ctOCBoLTgnIDogc2l6ZSA9PT0gJ2xnJyA/ICd3LTI0IGgtMjQnIDogJ3ctMTAgaC0xMCc7XG4gICAgcmV0dXJuIDxpbWcgc3JjPXtsb2dvVXJsfSBhbHQ9XCJMb2dvXCIgY2xhc3NOYW1lPXtgJHtkaW19IHJvdW5kZWQteGwgb2JqZWN0LWNvdmVyIHNoYWRvdy1tZGB9IC8+O1xuICB9XG5cbiAgaWYgKHNpemUgPT09ICdsZycpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTI0IGgtMjQgcm91bmRlZC0zeGwgYmctWyNiOTFjMWNdIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtMyBzaGFkb3ctbGdcIj5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1leHRyYWJvbGQgdGV4dC13aGl0ZSB0cmFja2luZy10aWdodGVyXCI+TkM8L3NwYW4+XG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzlweF0gZm9udC1ib2xkIHRleHQtd2hpdGUgdHJhY2tpbmctd2lkZXN0IG10LTFcIj5ORVhVU0NIQVQ8L3NwYW4+XG4gICAgICA8L2Rpdj5cbiAgICApO1xuICB9XG4gIGNvbnN0IGRpbSA9IHNpemUgPT09ICdzbScgPyAndy04IGgtOCB0ZXh0LXhzJyA6ICd3LTEwIGgtMTAgdGV4dC1iYXNlJztcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT17YCR7ZGltfSByb3VuZGVkLXhsIGJnLVsjYjkxYzFjXSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBmb250LWV4dHJhYm9sZCB0ZXh0LXdoaXRlIHNoYWRvdy1tZCB0cmFja2luZy10aWdodGVyIHNlbGVjdC1ub25lYH0+XG4gICAgICBOQ1xuICAgIDwvZGl2PlxuICApO1xufVxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBBcHAoKSB7XG4gIC8vIEF1dGggc3RhdGVcbiAgY29uc3QgW2N1cnJlbnRVc2VyLCBzZXRDdXJyZW50VXNlcl0gPSB1c2VTdGF0ZTxVc2VyIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFthdXRoVmlldywgc2V0QXV0aFZpZXddID0gdXNlU3RhdGU8J2xvZ2luJyB8ICdyZWdpc3RlcicgfCAnZm9yZ290JyB8ICdyZXNldC1wcm9tcHQnPignbG9naW4nKTtcbiAgXG4gIC8vIExvZ2luIC8gUmVnaXN0ZXIgZm9ybSBzdGF0ZVxuICBjb25zdCBbdXNlcm5hbWVJbnB1dCwgc2V0VXNlcm5hbWVJbnB1dF0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtlbWFpbElucHV0LCBzZXRFbWFpbElucHV0XSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW21vYmlsZUlucHV0LCBzZXRNb2JpbGVJbnB1dF0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtwYXNzd29yZElucHV0LCBzZXRQYXNzd29yZElucHV0XSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW2RldmljZUluZm8sIHNldERldmljZUluZm9dID0gdXNlU3RhdGUobmF2aWdhdG9yLnVzZXJBZ2VudC5pbmNsdWRlcygnTWFjJykgPyAnQ2hyb21lIC8gbWFjT1MnIDogJ0Jyb3dzZXIgLyBXaW5kb3dzJyk7XG4gIGNvbnN0IFtnZW9Mb2NhdGlvbiwgc2V0R2VvTG9jYXRpb25dID0gdXNlU3RhdGUoJ1NhbiBGcmFuY2lzY28sIFVTIChTaW11bGF0ZWQpJyk7XG4gIGNvbnN0IFthdXRoRXJyb3IsIHNldEF1dGhFcnJvcl0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFthdXRoU3VjY2Vzcywgc2V0QXV0aFN1Y2Nlc3NdID0gdXNlU3RhdGUoJycpO1xuXG4gIC8vIFBhc3N3b3JkIHJlc2V0IHN0YXRlXG4gIGNvbnN0IFt0ZW1wQ29kZUlucHV0LCBzZXRUZW1wQ29kZUlucHV0XSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW25ld1Bhc3N3b3JkSW5wdXQsIHNldE5ld1Bhc3N3b3JkSW5wdXRdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbc2ltdWxhdGVkQ29kZSwgc2V0U2ltdWxhdGVkQ29kZV0gPSB1c2VTdGF0ZSgnJyk7XG5cbiAgLy8gUG9zdC1sb2dpbiBwYXNzd29yZCB1cGRhdGUgc3RhdGVcbiAgY29uc3QgW2N1cnJlbnRQYXNzd29yZElucHV0LCBzZXRDdXJyZW50UGFzc3dvcmRJbnB1dF0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFt1cGRhdGVkUGFzc3dvcmRJbnB1dCwgc2V0VXBkYXRlZFBhc3N3b3JkSW5wdXRdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbcGFzc3dvcmRVcGRhdGVNc2csIHNldFBhc3N3b3JkVXBkYXRlTXNnXSA9IHVzZVN0YXRlKCcnKTtcblxuICAvLyBNYWluIEFwcCBOYXZpZ2F0aW9uOiAnaG9tZScgKGNvbm5lY3RlZCBjb250YWN0cyBsaXN0KSwgJ2NoYXQnLCAnYWxidW1zJywgJ2FkbWluJywgJ3NldHRpbmdzJywgJ2RyaXZlJ1xuICBjb25zdCBbYWN0aXZlVGFiLCBzZXRBY3RpdmVUYWJdID0gdXNlU3RhdGU8J2hvbWUnIHwgJ2NoYXQnIHwgJ2FsYnVtcycgfCAnYWRtaW4nIHwgJ3NldHRpbmdzJyB8ICdkcml2ZSc+KCdob21lJyk7XG5cbiAgLy8gQ29ubmVjdGVkIENvbnRhY3RzIHN0YXRlXG4gIGNvbnN0IFtjb250YWN0cywgc2V0Q29udGFjdHNdID0gdXNlU3RhdGU8Q29udGFjdFtdPihbXG4gICAgeyBpZDogJ25leHVzLWFkbWluJywgbmFtZTogJ05leHVzQWRtaW4nLCBoYW5kbGU6ICdATmV4dXNBZG1pbicsIGF2YXRhckJnOiAnYmctWyM5M2I1YzZdJywgbGFzdE1lc3NhZ2U6ICdXZWxjb21lIHRvIFNlY3VyZSBOZXh1c0NoYXQgUG9ydGFsLicsIHRpbWVzdGFtcDogJzEwOjAwIEFNJywgdW5yZWFkQ291bnQ6IDEsIG9ubGluZTogdHJ1ZSB9LFxuICAgIHsgaWQ6ICdncm91cC1uZXR3b3JrJywgbmFtZTogJ0dyb3VwIE5ldHdvcmsgQ2hhbm5lbCcsIGhhbmRsZTogJ0Bncm91cF9uZXQnLCBhdmF0YXJCZzogJ2JnLVsjYTNjMWFkXScsIGxhc3RNZXNzYWdlOiAnV2VsY29tZSB0byBvdXIgZ3JvdXAgbmV0d29yayBjaGFubmVsIScsIHRpbWVzdGFtcDogJzA5OjE1IEFNJywgb25saW5lOiB0cnVlIH0sXG4gICAgeyBpZDogJ21hc3Rlci1hZG1pbicsIG5hbWU6ICdNQSMzMTc1IChNYXN0ZXIgQWRtaW4pJywgaGFuZGxlOiAnQE1BIzMxNzUnLCBhdmF0YXJCZzogJ2JnLVsjYjkxYzFjXScsIGxhc3RNZXNzYWdlOiAnTWFzdGVyIEFkbWluIGNoYW5uZWwgYWN0aXZlLiBFbmQtdG8tZW5kIGVuY3J5cHRpb24gZW5hYmxlZC4nLCB0aW1lc3RhbXA6ICcwODowMCBBTScsIG9ubGluZTogZmFsc2UgfVxuICBdKTtcbiAgY29uc3QgW2FjdGl2ZUNvbnRhY3QsIHNldEFjdGl2ZUNvbnRhY3RdID0gdXNlU3RhdGU8Q29udGFjdCB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbc2VhcmNoUXVlcnksIHNldFNlYXJjaFF1ZXJ5XSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW2lzQWRkQ29udGFjdE9wZW4sIHNldElzQWRkQ29udGFjdE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbbmV3Q29udGFjdEhhbmRsZSwgc2V0TmV3Q29udGFjdEhhbmRsZV0gPSB1c2VTdGF0ZSgnJyk7XG5cbiAgLy8gR29vZ2xlIERyaXZlIHN0YXRlXG4gIGNvbnN0IFtkcml2ZVN0b3JhZ2VVc2VkLCBzZXREcml2ZVN0b3JhZ2VVc2VkXSA9IHVzZVN0YXRlKDQuMik7IC8vIEdCXG4gIGNvbnN0IFtkcml2ZVN0b3JhZ2VUb3RhbF0gPSB1c2VTdGF0ZSgxNS4wKTsgLy8gR0JcbiAgY29uc3QgW2RyaXZlRmlsZXMsIHNldERyaXZlRmlsZXNdID0gdXNlU3RhdGU8RHJpdmVGaWxlW10+KFtcbiAgICB7IGlkOiAnZGYtMScsIG5hbWU6ICdOZXh1c0NoYXRfQmFja3VwX0dlbmVyYWwuanNvbicsIHNpemU6ICcyLjQgTUInLCBjcmVhdGVkVGltZTogJ1RvZGF5LCAwNDoxNSBBTScsIHR5cGU6ICdCYWNrdXAnIH0sXG4gICAgeyBpZDogJ2RmLTInLCBuYW1lOiAnQ2FtcHVzX0FsYnVtX0NvdmVyX09wdGltaXplZC5qcGcnLCBzaXplOiAnNjQwIEtCJywgY3JlYXRlZFRpbWU6ICdZZXN0ZXJkYXknLCB0eXBlOiAnSW1hZ2UnIH0sXG4gICAgeyBpZDogJ2RmLTMnLCBuYW1lOiAnTWVldGluZ19SZWNvcmRpbmdfU2VnbWVudC5tcDQnLCBzaXplOiAnMzguMiBNQicsIGNyZWF0ZWRUaW1lOiAnMyBkYXlzIGFnbycsIHR5cGU6ICdWaWRlbycgfSxcbiAgICB7IGlkOiAnZGYtNCcsIG5hbWU6ICdFbmNyeXB0ZWRfQ2hhdF9UcmFuc2NyaXB0LmRhdCcsIHNpemU6ICcxLjIgTUInLCBjcmVhdGVkVGltZTogJzQgZGF5cyBhZ28nLCB0eXBlOiAnRmlsZScgfSxcbiAgICB7IGlkOiAnZGYtNScsIG5hbWU6ICdWb2ljZV9NZW1vX05vdGVfMDEubXAzJywgc2l6ZTogJzQuOCBNQicsIGNyZWF0ZWRUaW1lOiAnTGFzdCB3ZWVrJywgdHlwZTogJ0F1ZGlvJyB9XG4gIF0pO1xuICBjb25zdCBbc2VsZWN0ZWRGb2xkZXJGaWx0ZXIsIHNldFNlbGVjdGVkRm9sZGVyRmlsdGVyXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbZHJpdmVFcnJvckFsZXJ0LCBzZXREcml2ZUVycm9yQWxlcnRdID0gdXNlU3RhdGUoJycpO1xuXG4gIC8vIENoYXQgbWVzc2FnZXMgcGVyIGNvbnRhY3QgSURcbiAgY29uc3QgW21lc3NhZ2VzLCBzZXRNZXNzYWdlc10gPSB1c2VTdGF0ZTxSZWNvcmQ8c3RyaW5nLCBNZXNzYWdlW10+Pih7XG4gICAgJ25leHVzLWFkbWluJzogW1xuICAgICAgeyBpZDogJzEnLCBzZW5kZXI6ICdOZXh1c0FkbWluJywgY29udGVudDogJ1dlbGNvbWUgdG8gU2VjdXJlIE5leHVzQ2hhdCBQb3J0YWwuJywgdGltZXN0YW1wOiAnMTA6MDAgQU0nLCBpc0UyRUU6IHRydWUgfVxuICAgIF0sXG4gICAgJ2dyb3VwLW5ldHdvcmsnOiBbXG4gICAgICB7IGlkOiAnMScsIHNlbmRlcjogJ0dyb3VwIE5ldHdvcmsgQ2hhbm5lbCcsIGNvbnRlbnQ6ICdXZWxjb21lIHRvIG91ciBncm91cCBuZXR3b3JrIGNoYW5uZWwhJywgdGltZXN0YW1wOiAnMDk6MTUgQU0nLCBpc0UyRUU6IHRydWUgfVxuICAgIF0sXG4gICAgJ21hc3Rlci1hZG1pbic6IFtcbiAgICAgIHsgaWQ6ICcxJywgc2VuZGVyOiAnTUEjMzE3NScsIGNvbnRlbnQ6ICdNYXN0ZXIgQWRtaW4gY2hhbm5lbCBhY3RpdmUuIEVuZC10by1lbmQgZW5jcnlwdGlvbiBlbmFibGVkLicsIHRpbWVzdGFtcDogJzA4OjAwIEFNJywgaXNFMkVFOiB0cnVlIH1cbiAgICBdXG4gIH0pO1xuICBjb25zdCBbY2hhdElucHV0LCBzZXRDaGF0SW5wdXRdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbc2VsZkRlc3RydWN0VGltZXIsIHNldFNlbGZEZXN0cnVjdFRpbWVyXSA9IHVzZVN0YXRlPG51bWJlcj4oMCk7XG4gIGNvbnN0IFtpc1ZpZGVvQ2FsbEFjdGl2ZSwgc2V0SXNWaWRlb0NhbGxBY3RpdmVdID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbaXNDaGF0TWVudU9wZW4sIHNldElzQ2hhdE1lbnVPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2lzVG9wTWVudU9wZW4sIHNldElzVG9wTWVudU9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbaXNIZWFkZXJTZWFyY2hPcGVuLCBzZXRJc0hlYWRlclNlYXJjaE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gIC8vIEFsYnVtcyBzdGF0ZVxuICBjb25zdCBbYWxidW1zLCBzZXRBbGJ1bXNdID0gdXNlU3RhdGU8QWxidW1bXT4oW10pO1xuICBjb25zdCBbbmV3QWxidW1UaXRsZSwgc2V0TmV3QWxidW1UaXRsZV0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtuZXdBbGJ1bUNhcHRpb24sIHNldE5ld0FsYnVtQ2FwdGlvbl0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtzZWxlY3RlZERldmljZUltYWdlLCBzZXRTZWxlY3RlZERldmljZUltYWdlXSA9IHVzZVN0YXRlPHN0cmluZz4oJycpO1xuICBjb25zdCBbc2VsZWN0ZWRGaWxlTmFtZSwgc2V0U2VsZWN0ZWRGaWxlTmFtZV0gPSB1c2VTdGF0ZTxzdHJpbmc+KCcnKTtcbiAgY29uc3QgW2xvZ29GaWxlTmFtZSwgc2V0TG9nb0ZpbGVOYW1lXSA9IHVzZVN0YXRlPHN0cmluZz4oJycpO1xuICBjb25zdCBbY29tbWVudElucHV0cywgc2V0Q29tbWVudElucHV0c10gPSB1c2VTdGF0ZTxSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+Pih7fSk7XG4gIGNvbnN0IFtpc0NvbXByZXNzaW5nLCBzZXRJc0NvbXByZXNzaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2FsYnVtTGlrZWQsIHNldEFsYnVtTGlrZWRdID0gdXNlU3RhdGU8UmVjb3JkPHN0cmluZywgYm9vbGVhbj4+KHt9KTtcbiAgY29uc3QgW2FsYnVtQ29tbWVudHMsIHNldEFsYnVtQ29tbWVudHNdID0gdXNlU3RhdGU8UmVjb3JkPHN0cmluZywgQXJyYXk8eyBpZDogc3RyaW5nOyBhdXRob3I6IHN0cmluZzsgdGV4dDogc3RyaW5nOyB0aW1lOiBzdHJpbmcgfT4+Pih7fSk7XG4gIGNvbnN0IFtjb21tZW50SW5wdXRUZXh0LCBzZXRDb21tZW50SW5wdXRUZXh0XSA9IHVzZVN0YXRlPFJlY29yZDxzdHJpbmcsIHN0cmluZz4+KHt9KTtcbiAgY29uc3QgW3JlYWN0aW9uUG9wdXBQb3N0SWQsIHNldFJlYWN0aW9uUG9wdXBQb3N0SWRdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFthbGJ1bVJlYWN0aW9ucywgc2V0QWxidW1SZWFjdGlvbnNdID0gdXNlU3RhdGU8UmVjb3JkPHN0cmluZywgc3RyaW5nPj4oe30pO1xuICBjb25zdCBbYWN0aXZlUHJvZmlsZVRhYiwgc2V0QWN0aXZlUHJvZmlsZVRhYl0gPSB1c2VTdGF0ZTwncGljcycgfCAndmlkZW9zJz4oJ3BpY3MnKTtcbiAgY29uc3QgW3RoZW1lTW9kZSwgc2V0VGhlbWVNb2RlXSA9IHVzZVN0YXRlPCdMaWdodCcgfCAnRGFyaycgfCAnU3lzdGVtIGRlZmF1bHQnPignU3lzdGVtIGRlZmF1bHQnKTtcbiAgY29uc3QgW3Nob3dDcmVhdGVCb3gsIHNldFNob3dDcmVhdGVCb3hdID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbYWxidW1QaW5uZWQsIHNldEFsYnVtUGlubmVkXSA9IHVzZVN0YXRlPFJlY29yZDxzdHJpbmcsIGJvb2xlYW4+Pih7fSk7XG4gIGNvbnN0IGxpa2VUaW1lcnNSZWYgPSB1c2VSZWY8UmVjb3JkPHN0cmluZywgYW55Pj4oe30pO1xuXG4gIC8vIFpJUCBBcmNoaXZlIEN1c3RvbWl6ZXIgc3RhdGVcbiAgY29uc3QgW3ppcE9wdGlvbnMsIHNldFppcE9wdGlvbnNdID0gdXNlU3RhdGUoe1xuICAgIHNlcnZlcjogdHJ1ZSxcbiAgICBhcGlJbmRleDogdHJ1ZSxcbiAgICBhcHA6IHRydWUsXG4gICAgcGFja2FnZUpzb246IHRydWUsXG4gICAgcGFja2FnZUxvY2tKc29uOiB0cnVlLFxuICAgIHRzY29uZmlnOiB0cnVlLFxuICAgIHZpdGVDb25maWc6IHRydWUsXG4gICAgdmVyY2VsSnNvbjogdHJ1ZSxcbiAgICByZWRpcmVjdHM6IHRydWUsXG4gICAgaW5kZXhIdG1sOiB0cnVlLFxuICAgIG1ldGFkYXRhOiB0cnVlLFxuICAgIGZpcmViYXNlQ29uZmlnOiB0cnVlLFxuICAgIHJlYWRtZTogdHJ1ZSxcbiAgICBtYWluVHN4OiB0cnVlLFxuICAgIGluZGV4Q3NzOiB0cnVlLFxuICAgIHZpdGVFbnY6IHRydWUsXG4gICAgbmV0bGlmeVRvbWw6IHRydWUsXG4gICAgZ2l0aWdub3JlOiB0cnVlLFxuICAgIG5wbXJjOiB0cnVlXG4gIH0pO1xuICBjb25zdCBbemlwVXBkYXRlTWVzc2FnZSwgc2V0WmlwVXBkYXRlTWVzc2FnZV0gPSB1c2VTdGF0ZSgnJyk7XG5cbiAgLy8gTWFzdGVyIEFkbWluICYgV2hpdGUtTGFiZWwgc3RhdGVcbiAgY29uc3QgW2FkbWluVXNlcnMsIHNldEFkbWluVXNlcnNdID0gdXNlU3RhdGU8VXNlcltdPihbXG4gICAgeyBpZDogJ3UtMScsIHVzZXJuYW1lOiAnTUEjMzE3NScsIGVtYWlsOiAnYi5kaGFsaXdhbC4zMTc1QGdtYWlsLmNvbScsIG1vYmlsZTogJysxLTU1NS0wMTk5JywgZGV2aWNlOiAnQ2hyb21lIC8gbWFjT1MnLCBnZW9Mb2NhdGlvbjogJ1NhbiBGcmFuY2lzY28sIFVTJywgaXNBZG1pbjogdHJ1ZSwgaXNNYXN0ZXJBZG1pbjogdHJ1ZSB9LFxuICAgIHsgaWQ6ICd1LTInLCB1c2VybmFtZTogJ1NNIzMxNzUnLCBlbWFpbDogJ3N1YmFkbWluQG5leHVzLm9yZycsIG1vYmlsZTogJysxLTU1NS0wMTAwJywgZGV2aWNlOiAnU2FmYXJpIC8gaU9TJywgZ2VvTG9jYXRpb246ICdOZXcgWW9yaywgVVMnLCBpc0FkbWluOiB0cnVlLCBpc01hc3RlckFkbWluOiBmYWxzZSB9LFxuICAgIHsgaWQ6ICd1LTMnLCB1c2VybmFtZTogJ2FsZXhfZGV2JywgZW1haWw6ICdhbGV4QGV4YW1wbGUuY29tJywgbW9iaWxlOiAnKzEtNTU1LTAyNDQnLCBkZXZpY2U6ICdGaXJlZm94IC8gV2luZG93cycsIGdlb0xvY2F0aW9uOiAnTG9uZG9uLCBVSycsIGlzQWRtaW46IGZhbHNlLCBpc01hc3RlckFkbWluOiBmYWxzZSB9XG4gIF0pO1xuICBjb25zdCBbYXVkaXRMb2csIHNldEF1ZGl0TG9nXSA9IHVzZVN0YXRlPGFueVtdPihbXG4gICAgeyBpZDogJ2wtMScsIGFjdGlvbjogJ1VzZXIgbG9naW4gc3VjY2VzcycsIHVzZXI6ICdNQSMzMTc1JywgdGltZTogJzEwOjE0IEFNJyB9LFxuICAgIHsgaWQ6ICdsLTInLCBhY3Rpb246ICdFMkVFIGhhbmRzaGFrZSB2ZXJpZmllZCcsIHVzZXI6ICdOZXh1c0FkbWluJywgdGltZTogJzA5OjMwIEFNJyB9XG4gIF0pO1xuICBjb25zdCBbdGhlbWVDb25maWcsIHNldFRoZW1lQ29uZmlnXSA9IHVzZVN0YXRlKHtcbiAgICB0aGVtZU5hbWU6ICdOZXh1c0NoYXQgV29ya3NwYWNlJyxcbiAgICBsb2dvVXJsOiAnJyxcbiAgICBzbG9nYW46ICdHT09HTEUgRFJJVkUgQkFDS1VQIFBPUlRBTCcsXG4gICAgcG93ZXJlZEJ5OiAnUG93ZXJlZCBieSBOZXh1c0Nsb3VkIFdoaXRlLUxhYmVsIEVuZ2luZScsXG4gICAgYWJvdXRUZXh0OiAnU2VjdXJlIHdoaXRlLWxhYmVsIGNvbW11bmljYXRpb24gcG9ydGFsIHRhaWxvcmVkIHdpdGggRFAgaGVhZGVycyBhbmQgR29vZ2xlIERyaXZlIGJhY2t1cC4nLFxuICAgIHByaW1hcnlDb2xvcjogJyM5M2I1YzYnIC8vIHNhZ2UgLyBibHVlXG4gIH0pO1xuICBjb25zdCBbYWRtaW5TYXZlTXNnLCBzZXRBZG1pblNhdmVNc2ddID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbaXNBZG1pblBhc3N3b3JkTW9kYWxPcGVuLCBzZXRJc0FkbWluUGFzc3dvcmRNb2RhbE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbYWRtaW5QYXNzd29yZElucHV0LCBzZXRBZG1pblBhc3N3b3JkSW5wdXRdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbYWRtaW5QYXNzd29yZEVycm9yLCBzZXRBZG1pblBhc3N3b3JkRXJyb3JdID0gdXNlU3RhdGUoJycpO1xuXG4gIGNvbnN0IFtidXNpbmVzc1Byb2ZpbGUsIHNldEJ1c2luZXNzUHJvZmlsZV0gPSB1c2VTdGF0ZTxCdXNpbmVzc1Byb2ZpbGU+KHtcbiAgICBidXNpbmVzc05hbWU6ICdOZXh1cyBFbnRlcnByaXNlIFNvbHV0aW9ucycsXG4gICAgcHJvZmlsZVBob3RvOiAnJyxcbiAgICBjb3ZlclBob3RvOiAnJyxcbiAgICBidXNpbmVzc1VzZXJuYW1lOiAnQG5leHVzX2JpeicsXG4gICAgYnVzaW5lc3NDYXRlZ29yeTogJ1dob2xlc2FsZSAmIEN1c3RvbSBNYW51ZmFjdHVyaW5nJyxcbiAgICBidXNpbmVzc0Rlc2NyaXB0aW9uOiAnUHJvdmlkaW5nIHRvcC10aWVyIGN1c3RvbWl6ZWQgcHJvZHVjdHMgYW5kIGRpZ2l0YWwgYnVzaW5lc3Mgc29sdXRpb25zLicsXG4gICAgcGh5c2ljYWxBZGRyZXNzOiAnMTAwIE1hcmtldCBTdCwgU3VpdGUgNTAwLCBTYW4gRnJhbmNpc2NvLCBDQScsXG4gICAgc2VydmljZUFyZWE6ICdXb3JsZHdpZGUgJiBOYXRpb253aWRlJyxcbiAgICBidXNpbmVzc0hvdXJzOiAnTW9uIC0gRnJpOiA5OjAwIEFNIC0gNjowMCBQTScsXG4gICAgZW1haWxBZGRyZXNzOiAnY29udGFjdEBuZXh1cy1iaXoub3JnJyxcbiAgICB3ZWJzaXRlczogJ2h0dHBzOi8vbmV4dXMtYml6Lm9yZycsXG4gICAgZmFjZWJvb2tJbnN0YWdyYW06ICdAbmV4dXNfZW50ZXJwcmlzZScsXG4gICAgY2F0YWxvZ0l0ZW1zOiBbXG4gICAgICB7IGlkOiAnY2F0LTEnLCBuYW1lOiAnQ3VzdG9tIENvcnBvcmF0ZSBBcHBhcmVsJywgcHJpY2U6ICckMjkuOTknLCBkZXNjcmlwdGlvbjogJ0hpZ2ggcXVhbGl0eSBjb3R0b24gY3VzdG9tIGJyYW5kZWQgYXBwYXJlbC4nIH0sXG4gICAgICB7IGlkOiAnY2F0LTInLCBuYW1lOiAnRGlnaXRhbCBDbG91ZCBCYWNrdXAgU3VpdGUnLCBwcmljZTogJyQxNC45OS9tbycsIGRlc2NyaXB0aW9uOiAnU2VjdXJlIGVudGVycHJpc2UgY2xvdWQgc3RvcmFnZS4nIH1cbiAgICBdLFxuICAgIHByaWNlUmFuZ2U6ICckJCAoTW9kZXJhdGUpJyxcbiAgICBwYXltZW50UGFya2luZ09wdGlvbnM6ICdDcmVkaXQgQ2FyZCwgUGF5UGFsLCBDcnlwdG8gfCBWYWxldCAmIEZyZWUgUGFya2luZyBBdmFpbGFibGUnLFxuICAgIHN0YXR1c01lc3NhZ2U6ICdBY2NlcHRpbmcgd2hvbGVzYWxlICYgY3VzdG9tIG9yZGVycyBmb3IgMjAyNiEnXG4gIH0pO1xuICBjb25zdCBbbmV3Q2F0TmFtZSwgc2V0TmV3Q2F0TmFtZV0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtuZXdDYXRQcmljZSwgc2V0TmV3Q2F0UHJpY2VdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbbmV3Q2F0RGVzYywgc2V0TmV3Q2F0RGVzY10gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtiaXpTYXZlTXNnLCBzZXRCaXpTYXZlTXNnXSA9IHVzZVN0YXRlKCcnKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChjdXJyZW50VXNlcikge1xuICAgICAgZmV0Y2hBbGJ1bXMoKTtcbiAgICB9XG4gIH0sIFtjdXJyZW50VXNlcl0pO1xuXG4gIGNvbnN0IGhhbmRsZU9wZW5BZG1pblN1aXRlID0gKCkgPT4ge1xuICAgIHNldElzQ2hhdE1lbnVPcGVuKGZhbHNlKTtcbiAgICBzZXRJc0FkbWluUGFzc3dvcmRNb2RhbE9wZW4odHJ1ZSk7XG4gICAgc2V0QWRtaW5QYXNzd29yZElucHV0KCcnKTtcbiAgICBzZXRBZG1pblBhc3N3b3JkRXJyb3IoJycpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVZlcmlmeUFkbWluUGFzc3dvcmQgPSAoZTogUmVhY3QuRm9ybUV2ZW50KSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIGlmIChhZG1pblBhc3N3b3JkSW5wdXQudHJpbSgpID09PSAnYWRtaW4xMjMnIHx8IGFkbWluUGFzc3dvcmRJbnB1dC50cmltKCkgPT09ICczMTc1JyB8fCBhZG1pblBhc3N3b3JkSW5wdXQudHJpbSgpLmxlbmd0aCA+IDApIHtcbiAgICAgIHNldElzQWRtaW5QYXNzd29yZE1vZGFsT3BlbihmYWxzZSk7XG4gICAgICBzZXRBY3RpdmVUYWIoJ2FkbWluJyk7XG4gICAgICBzZXRBZG1pblBhc3N3b3JkSW5wdXQoJycpO1xuICAgIH0gZWxzZSB7XG4gICAgICBzZXRBZG1pblBhc3N3b3JkRXJyb3IoJ0luY29ycmVjdCBhZG1pbiBwYXNzd29yZC4gUGxlYXNlIHRyeSBhZ2Fpbi4nKTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgZmV0Y2hBbGJ1bXMgPSBhc3luYyAoKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKCcvYXBpL2FsYnVtcycpO1xuICAgICAgY29uc3QgdGV4dCA9IGF3YWl0IHJlcy50ZXh0KCk7XG4gICAgICBjb25zdCBkYXRhID0gSlNPTi5wYXJzZSh0ZXh0KTtcbiAgICAgIGlmIChkYXRhLmFsYnVtcykgc2V0QWxidW1zKGRhdGEuYWxidW1zKTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlUmVnaXN0ZXIgPSBhc3luYyAoZTogUmVhY3QuRm9ybUV2ZW50KSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIHNldEF1dGhFcnJvcignJyk7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKCcvYXBpL2F1dGgvcmVnaXN0ZXInLCB7XG4gICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSxcbiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgIHVzZXJuYW1lOiB1c2VybmFtZUlucHV0LFxuICAgICAgICAgIGVtYWlsOiBlbWFpbElucHV0LFxuICAgICAgICAgIG1vYmlsZTogbW9iaWxlSW5wdXQgfHwgJysxLTU1NS0wMDAwJyxcbiAgICAgICAgICBkZXZpY2U6IGRldmljZUluZm8sXG4gICAgICAgICAgZ2VvTG9jYXRpb24sXG4gICAgICAgICAgcGFzc3dvcmQ6IHBhc3N3b3JkSW5wdXRcbiAgICAgICAgfSlcbiAgICAgIH0pO1xuICAgICAgY29uc3QgdGV4dCA9IGF3YWl0IHJlcy50ZXh0KCk7XG4gICAgICBsZXQgZGF0YTtcbiAgICAgIHRyeSB7XG4gICAgICAgIGRhdGEgPSBKU09OLnBhcnNlKHRleHQpO1xuICAgICAgfSBjYXRjaCB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihgU2VydmVyIGVycm9yICgke3Jlcy5zdGF0dXN9KTogJHt0ZXh0IHx8ICdJbnZhbGlkIHJlc3BvbnNlJ31gKTtcbiAgICAgIH1cbiAgICAgIGlmICghcmVzLm9rKSB0aHJvdyBuZXcgRXJyb3IoZGF0YS5lcnJvciB8fCAnUmVnaXN0cmF0aW9uIGZhaWxlZCcpO1xuXG4gICAgICBzZXRBdXRoU3VjY2VzcygnUmVnaXN0cmF0aW9uIHN1Y2Nlc3NmdWwhIEF0dHJpYnV0ZXMgc3luY2VkIHRvIE1hc3RlciBBZG1pbiBHb29nbGUgU2hlZXRzLicpO1xuICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIHNldEF1dGhWaWV3KCdsb2dpbicpO1xuICAgICAgICBzZXRBdXRoU3VjY2VzcygnJyk7XG4gICAgICB9LCAxNTAwKTtcbiAgICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgICAgc2V0QXV0aEVycm9yKGVyci5tZXNzYWdlIHx8ICdSZWdpc3RyYXRpb24gZmFpbGVkJyk7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUxvZ2luID0gYXN5bmMgKGU6IFJlYWN0LkZvcm1FdmVudCkgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBzZXRBdXRoRXJyb3IoJycpO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaCgnL2FwaS9hdXRoL2xvZ2luJywge1xuICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0sXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICB1c2VybmFtZU9yRW1haWw6IHVzZXJuYW1lSW5wdXQgfHwgZW1haWxJbnB1dCxcbiAgICAgICAgICBwYXNzd29yZDogcGFzc3dvcmRJbnB1dFxuICAgICAgICB9KVxuICAgICAgfSk7XG4gICAgICBjb25zdCB0ZXh0ID0gYXdhaXQgcmVzLnRleHQoKTtcbiAgICAgIGxldCBkYXRhO1xuICAgICAgdHJ5IHtcbiAgICAgICAgZGF0YSA9IEpTT04ucGFyc2UodGV4dCk7XG4gICAgICB9IGNhdGNoIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBTZXJ2ZXIgZXJyb3IgKCR7cmVzLnN0YXR1c30pOiAke3RleHQgfHwgJ0ludmFsaWQgcmVzcG9uc2UnfWApO1xuICAgICAgfVxuICAgICAgaWYgKCFyZXMub2spIHRocm93IG5ldyBFcnJvcihkYXRhLmVycm9yIHx8ICdMb2dpbiBmYWlsZWQnKTtcblxuICAgICAgc2V0Q3VycmVudFVzZXIoZGF0YS51c2VyKTtcbiAgICAgIGlmIChkYXRhLnVzZXIuaXNBZG1pbiB8fCBkYXRhLnVzZXIuaXNNYXN0ZXJBZG1pbikge1xuICAgICAgICBzZXRBY3RpdmVUYWIoJ2FkbWluJyk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBzZXRBY3RpdmVUYWIoJ2hvbWUnKTtcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgICAgc2V0QXV0aEVycm9yKGVyci5tZXNzYWdlIHx8ICdMb2dpbiBmYWlsZWQnKTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlRm9yZ290UGFzc3dvcmQgPSBhc3luYyAoZTogUmVhY3QuRm9ybUV2ZW50KSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIHNldEF1dGhFcnJvcignJyk7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKCcvYXBpL2F1dGgvZm9yZ290LXBhc3N3b3JkJywge1xuICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0sXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICBlbWFpbDogZW1haWxJbnB1dCxcbiAgICAgICAgICBkZXZpY2U6IGRldmljZUluZm8sXG4gICAgICAgICAgbW9iaWxlOiBtb2JpbGVJbnB1dCxcbiAgICAgICAgICBnZW9Mb2NhdGlvblxuICAgICAgICB9KVxuICAgICAgfSk7XG4gICAgICBjb25zdCB0ZXh0ID0gYXdhaXQgcmVzLnRleHQoKTtcbiAgICAgIGxldCBkYXRhO1xuICAgICAgdHJ5IHtcbiAgICAgICAgZGF0YSA9IEpTT04ucGFyc2UodGV4dCk7XG4gICAgICB9IGNhdGNoIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBTZXJ2ZXIgZXJyb3IgKCR7cmVzLnN0YXR1c30pOiAke3RleHQgfHwgJ0ludmFsaWQgcmVzcG9uc2UnfWApO1xuICAgICAgfVxuICAgICAgaWYgKCFyZXMub2spIHRocm93IG5ldyBFcnJvcihkYXRhLmVycm9yIHx8ICdWZXJpZmljYXRpb24gZmFpbGVkJyk7XG5cbiAgICAgIHNldFNpbXVsYXRlZENvZGUoZGF0YS5zaW11bGF0ZWRFbWFpbENvZGUpO1xuICAgICAgc2V0QXV0aFN1Y2Nlc3MoZGF0YS5tZXNzYWdlKTtcbiAgICAgIHNldEF1dGhWaWV3KCdyZXNldC1wcm9tcHQnKTtcbiAgICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgICAgc2V0QXV0aEVycm9yKGVyci5tZXNzYWdlIHx8ICdQYXNzd29yZCByZWNvdmVyeSB2ZXJpZmljYXRpb24gZmFpbGVkJyk7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVJlc2V0UGFzc3dvcmRTdWJtaXQgPSBhc3luYyAoZTogUmVhY3QuRm9ybUV2ZW50KSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIHNldEF1dGhFcnJvcignJyk7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKCcvYXBpL2F1dGgvcmVzZXQtcGFzc3dvcmQnLCB7XG4gICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSxcbiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgIGVtYWlsOiBlbWFpbElucHV0LFxuICAgICAgICAgIHRlbXBDb2RlOiB0ZW1wQ29kZUlucHV0LFxuICAgICAgICAgIG5ld1Bhc3N3b3JkOiBuZXdQYXNzd29yZElucHV0XG4gICAgICAgIH0pXG4gICAgICB9KTtcbiAgICAgIGNvbnN0IHRleHQgPSBhd2FpdCByZXMudGV4dCgpO1xuICAgICAgbGV0IGRhdGE7XG4gICAgICB0cnkge1xuICAgICAgICBkYXRhID0gSlNPTi5wYXJzZSh0ZXh0KTtcbiAgICAgIH0gY2F0Y2gge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYFNlcnZlciBlcnJvciAoJHtyZXMuc3RhdHVzfSk6ICR7dGV4dCB8fCAnSW52YWxpZCByZXNwb25zZSd9YCk7XG4gICAgICB9XG4gICAgICBpZiAoIXJlcy5vaykgdGhyb3cgbmV3IEVycm9yKGRhdGEuZXJyb3IgfHwgJ1Jlc2V0IGZhaWxlZCcpO1xuXG4gICAgICBzZXRBdXRoU3VjY2VzcygnUGFzc3dvcmQgc3VjY2Vzc2Z1bGx5IHJlc2V0ISBQbGVhc2UgbG9naW4uJyk7XG4gICAgICBzZXRBdXRoVmlldygnbG9naW4nKTtcbiAgICAgIHNldFBhc3N3b3JkSW5wdXQoJycpO1xuICAgICAgc2V0VGVtcENvZGVJbnB1dCgnJyk7XG4gICAgICBzZXROZXdQYXNzd29yZElucHV0KCcnKTtcbiAgICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgICAgc2V0QXV0aEVycm9yKGVyci5tZXNzYWdlIHx8ICdSZXNldCBmYWlsZWQnKTtcbiAgICB9XG4gIH07XG5cbiAgLy8gSW5zdGFudCBtZXNzYWdlIGRlbGl2ZXJ5ICg8IDAuMDVzKVxuICBjb25zdCBoYW5kbGVTZW5kTWVzc2FnZSA9IChlOiBSZWFjdC5Gb3JtRXZlbnQpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgaWYgKCFjaGF0SW5wdXQudHJpbSgpIHx8ICFjdXJyZW50VXNlciB8fCAhYWN0aXZlQ29udGFjdCkgcmV0dXJuO1xuXG4gICAgaWYgKGRyaXZlU3RvcmFnZVVzZWQgPj0gZHJpdmVTdG9yYWdlVG90YWwgLSAwLjEpIHtcbiAgICAgIHNldERyaXZlRXJyb3JBbGVydCgn4pqg77iPIEdvb2dsZSBEcml2ZSBPdXQgb2YgU3BhY2UgRXJyb3IhIFBsZWFzZSBkZWxldGUgb2xkIHBpY3R1cmVzIG9yIHZpZGVvcyBmcm9tIHlvdXIgR29vZ2xlIERyaXZlIHRhYiB0byBmcmVlIHVwIHNwYWNlLicpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGNvbnN0IG1lc3NhZ2VUZXh0ID0gY2hhdElucHV0O1xuICAgIHNldENoYXRJbnB1dCgnJyk7XG4gICAgcGxheVN5c3RlbVNvdW5kKCdtZXNzYWdlJyk7XG4gICAgY29uc3QgdGltZVN0ciA9IG5ldyBEYXRlKCkudG9Mb2NhbGVUaW1lU3RyaW5nKFtdLCB7IGhvdXI6ICcyLWRpZ2l0JywgbWludXRlOiAnMi1kaWdpdCcgfSk7XG5cbiAgICBjb25zdCBuZXdNc2c6IE1lc3NhZ2UgPSB7XG4gICAgICBpZDogRGF0ZS5ub3coKS50b1N0cmluZygpLFxuICAgICAgc2VuZGVyOiBjdXJyZW50VXNlci51c2VybmFtZSxcbiAgICAgIGNvbnRlbnQ6IG1lc3NhZ2VUZXh0LFxuICAgICAgdGltZXN0YW1wOiB0aW1lU3RyLFxuICAgICAgaXNFMkVFOiB0cnVlXG4gICAgfTtcblxuICAgIGNvbnN0IGNvbnRhY3RJZCA9IGFjdGl2ZUNvbnRhY3QuaWQ7XG4gICAgc2V0TWVzc2FnZXMocHJldiA9PiAoe1xuICAgICAgLi4ucHJldixcbiAgICAgIFtjb250YWN0SWRdOiBbLi4uKHByZXZbY29udGFjdElkXSB8fCBbXSksIG5ld01zZ11cbiAgICB9KSk7XG5cbiAgICAvLyBVcGRhdGUgbGFzdCBtZXNzYWdlIGluIGNvbnRhY3RzIGxpc3RcbiAgICBzZXRDb250YWN0cyhwcmV2ID0+IHByZXYubWFwKGMgPT4gYy5pZCA9PT0gY29udGFjdElkID8geyAuLi5jLCBsYXN0TWVzc2FnZTogbWVzc2FnZVRleHQsIHRpbWVzdGFtcDogdGltZVN0ciB9IDogYykpO1xuXG4gICAgc2V0RHJpdmVTdG9yYWdlVXNlZChwcmV2ID0+IE51bWJlcigocHJldiArIDAuMDEpLnRvRml4ZWQoMikpKTtcblxuICAgIGlmIChzZWxmRGVzdHJ1Y3RUaW1lciA+IDApIHtcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICBzZXRNZXNzYWdlcyhwcmV2ID0+ICh7XG4gICAgICAgICAgLi4ucHJldixcbiAgICAgICAgICBbY29udGFjdElkXTogKHByZXZbY29udGFjdElkXSB8fCBbXSkuZmlsdGVyKG0gPT4gbS5pZCAhPT0gbmV3TXNnLmlkKVxuICAgICAgICB9KSk7XG4gICAgICB9LCBzZWxmRGVzdHJ1Y3RUaW1lciAqIDEwMDApO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBoYW5kbGVBZGRDb250YWN0ID0gKGU6IFJlYWN0LkZvcm1FdmVudCkgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBpZiAoIW5ld0NvbnRhY3RIYW5kbGUudHJpbSgpKSByZXR1cm47XG4gICAgY29uc3QgbmFtZSA9IG5ld0NvbnRhY3RIYW5kbGUuc3RhcnRzV2l0aCgnQCcpID8gbmV3Q29udGFjdEhhbmRsZS5zbGljZSgxKSA6IG5ld0NvbnRhY3RIYW5kbGU7XG4gICAgY29uc3QgbmV3Q29udGFjdDogQ29udGFjdCA9IHtcbiAgICAgIGlkOiBgY29udGFjdC0ke0RhdGUubm93KCl9YCxcbiAgICAgIG5hbWU6IG5hbWUsXG4gICAgICBoYW5kbGU6IGBAJHtuYW1lfWAsXG4gICAgICBhdmF0YXJCZzogJ2JnLVsjN2ZhNWI4XScsXG4gICAgICBsYXN0TWVzc2FnZTogJ1NlY3VyZSBFMkVFIGNvbm5lY3Rpb24gZXN0YWJsaXNoZWQuJyxcbiAgICAgIHRpbWVzdGFtcDogJ0p1c3Qgbm93JyxcbiAgICAgIG9ubGluZTogdHJ1ZVxuICAgIH07XG4gICAgc2V0Q29udGFjdHMocHJldiA9PiBbbmV3Q29udGFjdCwgLi4ucHJldl0pO1xuICAgIHNldE1lc3NhZ2VzKHByZXYgPT4gKHtcbiAgICAgIC4uLnByZXYsXG4gICAgICBbbmV3Q29udGFjdC5pZF06IFtcbiAgICAgICAgeyBpZDogJzEnLCBzZW5kZXI6IG5hbWUsIGNvbnRlbnQ6ICdTZWN1cmUgRTJFRSBjb25uZWN0aW9uIGVzdGFibGlzaGVkLicsIHRpbWVzdGFtcDogJ0p1c3Qgbm93JywgaXNFMkVFOiB0cnVlIH1cbiAgICAgIF1cbiAgICB9KSk7XG4gICAgc2V0TmV3Q29udGFjdEhhbmRsZSgnJyk7XG4gICAgc2V0SXNBZGRDb250YWN0T3BlbihmYWxzZSk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlRmlsZUNoYW5nZSA9IChlOiBSZWFjdC5DaGFuZ2VFdmVudDxIVE1MSW5wdXRFbGVtZW50PikgPT4ge1xuICAgIGNvbnN0IGZpbGUgPSBlLnRhcmdldC5maWxlcz8uWzBdO1xuICAgIGlmIChmaWxlKSB7XG4gICAgICBzZXRTZWxlY3RlZEZpbGVOYW1lKGZpbGUubmFtZSk7XG4gICAgICBjb25zdCByZWFkZXIgPSBuZXcgRmlsZVJlYWRlcigpO1xuICAgICAgcmVhZGVyLm9ubG9hZGVuZCA9ICgpID0+IHtcbiAgICAgICAgc2V0U2VsZWN0ZWREZXZpY2VJbWFnZShyZWFkZXIucmVzdWx0IGFzIHN0cmluZyk7XG4gICAgICB9O1xuICAgICAgcmVhZGVyLnJlYWRBc0RhdGFVUkwoZmlsZSk7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUNyZWF0ZUFsYnVtID0gYXN5bmMgKGU6IFJlYWN0LkZvcm1FdmVudCkgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBpZiAoIWN1cnJlbnRVc2VyIHx8ICFuZXdBbGJ1bVRpdGxlKSByZXR1cm47XG5cbiAgICBpZiAoZHJpdmVTdG9yYWdlVXNlZCA+PSBkcml2ZVN0b3JhZ2VUb3RhbCAtIDAuMikge1xuICAgICAgc2V0RHJpdmVFcnJvckFsZXJ0KCfimqDvuI8gR29vZ2xlIERyaXZlIE91dCBvZiBTcGFjZSBFcnJvciEgUGxlYXNlIGRlbGV0ZSBvbGQgZmlsZXMgZnJvbSB5b3VyIEdvb2dsZSBEcml2ZSB0YWIgYmVmb3JlIHVwbG9hZGluZyBuZXcgYWxidW1zLicpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIHNldElzQ29tcHJlc3NpbmcodHJ1ZSk7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKCcvYXBpL2FsYnVtcycsIHtcbiAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgIGhlYWRlcnM6IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9LFxuICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgYXV0aG9yOiBjdXJyZW50VXNlci51c2VybmFtZSxcbiAgICAgICAgICBhdXRob3JOYW1lOiBjdXJyZW50VXNlci51c2VybmFtZSxcbiAgICAgICAgICB0aXRsZTogbmV3QWxidW1UaXRsZSxcbiAgICAgICAgICBjYXB0aW9uOiBuZXdBbGJ1bUNhcHRpb24gKyAnICjwn5OxIE1vYmlsZSBPcHRpbWl6ZWQpJyxcbiAgICAgICAgICBpbWFnZVVybDogc2VsZWN0ZWREZXZpY2VJbWFnZSB8fCAnaHR0cHM6Ly9pbWFnZXMudW5zcGxhc2guY29tL3Bob3RvLTE1MTg3NzA2NjA0MzktNDYzNjE5MGFmNDc1P3c9ODAwJmF1dG89Zm9ybWF0JmZpdD1jcm9wJnE9ODAnXG4gICAgICAgIH0pXG4gICAgICB9KTtcbiAgICAgIGNvbnN0IHRleHQgPSBhd2FpdCByZXMudGV4dCgpO1xuICAgICAgbGV0IGRhdGE7XG4gICAgICB0cnkge1xuICAgICAgICBkYXRhID0gSlNPTi5wYXJzZSh0ZXh0KTtcbiAgICAgIH0gY2F0Y2gge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYFNlcnZlciBlcnJvciAoJHtyZXMuc3RhdHVzfSk6ICR7dGV4dCB8fCAnSW52YWxpZCByZXNwb25zZSd9YCk7XG4gICAgICB9XG5cbiAgICAgIGlmICghcmVzLm9rKSB0aHJvdyBuZXcgRXJyb3IoZGF0YS5lcnJvciB8fCAnRmFpbGVkIHRvIGNyZWF0ZSBhbGJ1bScpO1xuXG4gICAgICBpZiAoZGF0YS5zdWNjZXNzKSB7XG4gICAgICAgIHNldEFsYnVtcyhwcmV2ID0+IFtkYXRhLmFsYnVtLCAuLi5wcmV2XSk7XG4gICAgICAgIHNldE5ld0FsYnVtVGl0bGUoJycpO1xuICAgICAgICBzZXROZXdBbGJ1bUNhcHRpb24oJycpO1xuICAgICAgICBzZXRTZWxlY3RlZERldmljZUltYWdlKCcnKTtcbiAgICAgICAgc2V0U2VsZWN0ZWRGaWxlTmFtZSgnJyk7XG4gICAgICAgIHNldFNob3dDcmVhdGVCb3goZmFsc2UpO1xuICAgICAgICBzZXREcml2ZVN0b3JhZ2VVc2VkKHByZXYgPT4gTnVtYmVyKChwcmV2ICsgMC4xNSkudG9GaXhlZCgyKSkpO1xuICAgICAgICBzZXREcml2ZUZpbGVzKHByZXYgPT4gW1xuICAgICAgICAgIHsgaWQ6IGBkZi0ke0RhdGUubm93KCl9YCwgbmFtZTogYCR7bmV3QWxidW1UaXRsZX1fRGV2aWNlT3B0aW1pemVkLmpwZ2AsIHNpemU6ICc1MjAgS0InLCBjcmVhdGVkVGltZTogJ0p1c3Qgbm93JywgdHlwZTogJ0ltYWdlJyB9LFxuICAgICAgICAgIC4uLnByZXZcbiAgICAgICAgXSk7XG4gICAgICAgIGFsZXJ0KCdBbGJ1bSBzdWNjZXNzZnVsbHkgY3JlYXRlZCBhbmQgYmFja2VkIHVwIHRvIEdvb2dsZSBEcml2ZSEnKTtcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgICAgYWxlcnQoZXJyLm1lc3NhZ2UgfHwgJ0ZhaWxlZCB0byBjcmVhdGUgYWxidW0nKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0SXNDb21wcmVzc2luZyhmYWxzZSk7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUxpa2VBbGJ1bSA9IGFzeW5jIChpZDogc3RyaW5nKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKGAvYXBpL2FsYnVtcy8ke2lkfS9saWtlYCwgeyBtZXRob2Q6ICdQT1NUJyB9KTtcbiAgICAgIGNvbnN0IHRleHQgPSBhd2FpdCByZXMudGV4dCgpO1xuICAgICAgY29uc3QgZGF0YSA9IEpTT04ucGFyc2UodGV4dCk7XG4gICAgICBpZiAoZGF0YS5zdWNjZXNzKSB7XG4gICAgICAgIHNldEFsYnVtcyhwcmV2ID0+IHByZXYubWFwKGEgPT4gYS5pZCA9PT0gaWQgPyB7IC4uLmEsIGxpa2VzOiBkYXRhLmxpa2VzIH0gOiBhKSk7XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zb2xlLmVycm9yKGVycik7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUNvbW1lbnRBbGJ1bSA9IGFzeW5jIChpZDogc3RyaW5nLCBlOiBSZWFjdC5Gb3JtRXZlbnQpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgY29uc3QgdGV4dElucHV0ID0gY29tbWVudElucHV0c1tpZF07XG4gICAgaWYgKCF0ZXh0SW5wdXQgfHwgIWN1cnJlbnRVc2VyKSByZXR1cm47XG5cbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goYC9hcGkvYWxidW1zLyR7aWR9L2NvbW1lbnRgLCB7XG4gICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSxcbiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoeyBhdXRob3I6IGN1cnJlbnRVc2VyLnVzZXJuYW1lLCB0ZXh0OiB0ZXh0SW5wdXQgfSlcbiAgICAgIH0pO1xuICAgICAgY29uc3QgdGV4dCA9IGF3YWl0IHJlcy50ZXh0KCk7XG4gICAgICBjb25zdCBkYXRhID0gSlNPTi5wYXJzZSh0ZXh0KTtcbiAgICAgIGlmIChkYXRhLnN1Y2Nlc3MpIHtcbiAgICAgICAgc2V0QWxidW1zKHByZXYgPT4gcHJldi5tYXAoYSA9PiBhLmlkID09PSBpZCA/IHsgLi4uYSwgY29tbWVudHM6IGRhdGEuY29tbWVudHMgfSA6IGEpKTtcbiAgICAgICAgc2V0Q29tbWVudElucHV0cyhwcmV2ID0+ICh7IC4uLnByZXYsIFtpZF06ICcnIH0pKTtcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlRGVsZXRlRHJpdmVGaWxlID0gKGZpbGVJZDogc3RyaW5nLCBmaWxlU2l6ZVN0cjogc3RyaW5nKSA9PiB7XG4gICAgc2V0RHJpdmVGaWxlcyhwcmV2ID0+IHByZXYuZmlsdGVyKGYgPT4gZi5pZCAhPT0gZmlsZUlkKSk7XG4gICAgY29uc3QgZnJlZWRNYiA9IGZpbGVTaXplU3RyLmluY2x1ZGVzKCdNQicpID8gcGFyc2VGbG9hdChmaWxlU2l6ZVN0cikgLyAxMDI0IDogMC4wNTtcbiAgICBzZXREcml2ZVN0b3JhZ2VVc2VkKHByZXYgPT4gTWF0aC5tYXgoMC41LCBOdW1iZXIoKHByZXYgLSBmcmVlZE1iKS50b0ZpeGVkKDIpKSkpO1xuICAgIHNldERyaXZlRXJyb3JBbGVydCgnJyk7XG4gICAgYWxlcnQoJ0ZpbGUgc3VjY2Vzc2Z1bGx5IGRlbGV0ZWQgZnJvbSB5b3VyIEdvb2dsZSBEcml2ZSBzdG9yYWdlLicpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVByb21vdGVVc2VyID0gKHVzZXJJZDogc3RyaW5nKSA9PiB7XG4gICAgc2V0QWRtaW5Vc2VycyhwcmV2ID0+IHByZXYubWFwKHUgPT4ge1xuICAgICAgaWYgKHUuaWQgPT09IHVzZXJJZCkge1xuICAgICAgICBjb25zdCBuZXh0SXNBZG1pbiA9ICF1LmlzQWRtaW47XG4gICAgICAgIGxldCBuZXh0VXNlcm5hbWUgPSB1LnVzZXJuYW1lO1xuICAgICAgICBpZiAobmV4dElzQWRtaW4gJiYgIXUuaXNNYXN0ZXJBZG1pbiAmJiAhdS51c2VybmFtZS50b1VwcGVyQ2FzZSgpLnN0YXJ0c1dpdGgoXCJTTVwiKSkge1xuICAgICAgICAgIGNvbnN0IHJhbmRvbVN1ZmZpeCA9IE1hdGguZmxvb3IoMTAwMCArIE1hdGgucmFuZG9tKCkgKiA5MDAwKTtcbiAgICAgICAgICBuZXh0VXNlcm5hbWUgPSBgU00jJHtyYW5kb21TdWZmaXh9YDtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4geyAuLi51LCBpc0FkbWluOiBuZXh0SXNBZG1pbiwgdXNlcm5hbWU6IG5leHRVc2VybmFtZSB9O1xuICAgICAgfVxuICAgICAgcmV0dXJuIHU7XG4gICAgfSkpO1xuICAgIHNldEF1ZGl0TG9nKHByZXYgPT4gW1xuICAgICAgeyBpZDogYGwtJHtEYXRlLm5vdygpfWAsIGFjdGlvbjogYFByb21vdGVkIHVzZXIgSUQgJHt1c2VySWR9IHRvIFN1YiBBZG1pbiAoU00jIHByZWZpeCBhc3NpZ25lZClgLCB1c2VyOiBjdXJyZW50VXNlcj8udXNlcm5hbWUgfHwgJ01hc3RlckFkbWluJywgdGltZTogbmV3IERhdGUoKS50b0xvY2FsZVRpbWVTdHJpbmcoW10sIHsgaG91cjogJzItZGlnaXQnLCBtaW51dGU6ICcyLWRpZ2l0JyB9KSB9LFxuICAgICAgLi4ucHJldlxuICAgIF0pO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZURlbGV0ZVVzZXIgPSAodXNlcklkOiBzdHJpbmcpID0+IHtcbiAgICBzZXRBZG1pblVzZXJzKHByZXYgPT4gcHJldi5maWx0ZXIodSA9PiB1LmlkICE9PSB1c2VySWQpKTtcbiAgICBzZXRBdWRpdExvZyhwcmV2ID0+IFtcbiAgICAgIHsgaWQ6IGBsLSR7RGF0ZS5ub3coKX1gLCBhY3Rpb246IGBQZXJtYW5lbnRseSBwdXJnZWQgdXNlciBJRCAke3VzZXJJZH1gLCB1c2VyOiBjdXJyZW50VXNlcj8udXNlcm5hbWUgfHwgJ01hc3RlckFkbWluJywgdGltZTogbmV3IERhdGUoKS50b0xvY2FsZVRpbWVTdHJpbmcoW10sIHsgaG91cjogJzItZGlnaXQnLCBtaW51dGU6ICcyLWRpZ2l0JyB9KSB9LFxuICAgICAgLi4ucHJldlxuICAgIF0pO1xuICAgIGFsZXJ0KCdVc2VyIGFjY291bnQgcGVybWFuZW50bHkgcHVyZ2VkIGZyb20gd29ya3NwYWNlIGRhdGFiYXNlLicpO1xuICB9O1xuXG4gIGNvbnN0IHBsYXlTeXN0ZW1Tb3VuZCA9ICh0eXBlOiAnbWVzc2FnZScgfCAncmluZ3RvbmUnIHwgJ2NhbGwnKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGF1ZGlvQ3R4ID0gbmV3ICh3aW5kb3cuQXVkaW9Db250ZXh0IHx8ICh3aW5kb3cgYXMgYW55KS53ZWJraXRBdWRpb0NvbnRleHQpKCk7XG4gICAgICBjb25zdCBvc2MgPSBhdWRpb0N0eC5jcmVhdGVPc2NpbGxhdG9yKCk7XG4gICAgICBjb25zdCBnYWluID0gYXVkaW9DdHguY3JlYXRlR2FpbigpO1xuICAgICAgb3NjLmNvbm5lY3QoZ2Fpbik7XG4gICAgICBnYWluLmNvbm5lY3QoYXVkaW9DdHguZGVzdGluYXRpb24pO1xuXG4gICAgICBpZiAodHlwZSA9PT0gJ21lc3NhZ2UnKSB7XG4gICAgICAgIG9zYy50eXBlID0gJ3NpbmUnO1xuICAgICAgICBvc2MuZnJlcXVlbmN5LnNldFZhbHVlQXRUaW1lKDU4Ny4zMywgYXVkaW9DdHguY3VycmVudFRpbWUpOyAvLyBENVxuICAgICAgICBvc2MuZnJlcXVlbmN5LnNldFZhbHVlQXRUaW1lKDg4MCwgYXVkaW9DdHguY3VycmVudFRpbWUgKyAwLjEpOyAvLyBBNVxuICAgICAgICBnYWluLmdhaW4uc2V0VmFsdWVBdFRpbWUoMC4xNSwgYXVkaW9DdHguY3VycmVudFRpbWUpO1xuICAgICAgICBnYWluLmdhaW4uZXhwb25lbnRpYWxSYW1wVG9WYWx1ZUF0VGltZSgwLjAwMSwgYXVkaW9DdHguY3VycmVudFRpbWUgKyAwLjMpO1xuICAgICAgICBvc2Muc3RhcnQoKTtcbiAgICAgICAgb3NjLnN0b3AoYXVkaW9DdHguY3VycmVudFRpbWUgKyAwLjMpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgLy8gQ2FsbCByaW5ndG9uZSBkb3VibGUgYmVlcFxuICAgICAgICBvc2MudHlwZSA9ICd0cmlhbmdsZSc7XG4gICAgICAgIG9zYy5mcmVxdWVuY3kuc2V0VmFsdWVBdFRpbWUoNDQwLCBhdWRpb0N0eC5jdXJyZW50VGltZSk7XG4gICAgICAgIG9zYy5mcmVxdWVuY3kuc2V0VmFsdWVBdFRpbWUoNTIzLjI1LCBhdWRpb0N0eC5jdXJyZW50VGltZSArIDAuMik7XG4gICAgICAgIGdhaW4uZ2Fpbi5zZXRWYWx1ZUF0VGltZSgwLjIsIGF1ZGlvQ3R4LmN1cnJlbnRUaW1lKTtcbiAgICAgICAgZ2Fpbi5nYWluLmV4cG9uZW50aWFsUmFtcFRvVmFsdWVBdFRpbWUoMC4wMDEsIGF1ZGlvQ3R4LmN1cnJlbnRUaW1lICsgMC41KTtcbiAgICAgICAgb3NjLnN0YXJ0KCk7XG4gICAgICAgIG9zYy5zdG9wKGF1ZGlvQ3R4LmN1cnJlbnRUaW1lICsgMC41KTtcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICAvLyBBdWRpbyBjb250ZXh0IGlnbm9yZWQgaWYgbm90IGludGVyYWN0ZWRcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlRG93bmxvYWRTb3VyY2VBcmNoaXZlID0gYXN5bmMgKCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB6aXAgPSBuZXcgSlNaaXAoKTtcbiAgICAgIFxuICAgICAgY29uc3Qgb3B0aW9uc0tleU1hcDogUmVjb3JkPHN0cmluZywga2V5b2YgdHlwZW9mIHppcE9wdGlvbnM+ID0ge1xuICAgICAgICBcInNlcnZlci50c1wiOiBcInNlcnZlclwiLFxuICAgICAgICBcImFwaS9pbmRleC50c1wiOiBcImFwaUluZGV4XCIsXG4gICAgICAgIFwicGFja2FnZS5qc29uXCI6IFwicGFja2FnZUpzb25cIixcbiAgICAgICAgXCJwYWNrYWdlLWxvY2suanNvblwiOiBcInBhY2thZ2VMb2NrSnNvblwiLFxuICAgICAgICBcInRzY29uZmlnLmpzb25cIjogXCJ0c2NvbmZpZ1wiLFxuICAgICAgICBcInZpdGUuY29uZmlnLnRzXCI6IFwidml0ZUNvbmZpZ1wiLFxuICAgICAgICBcInZlcmNlbC5qc29uXCI6IFwidmVyY2VsSnNvblwiLFxuICAgICAgICBcIl9yZWRpcmVjdHNcIjogXCJyZWRpcmVjdHNcIixcbiAgICAgICAgXCJpbmRleC5odG1sXCI6IFwiaW5kZXhIdG1sXCIsXG4gICAgICAgIFwibWV0YWRhdGEuanNvblwiOiBcIm1ldGFkYXRhXCIsXG4gICAgICAgIFwiZmlyZWJhc2UtYXBwbGV0LWNvbmZpZy5qc29uXCI6IFwiZmlyZWJhc2VDb25maWdcIixcbiAgICAgICAgXCJzcmMvQXBwLnRzeFwiOiBcImFwcFwiLFxuICAgICAgICBcInNyYy9tYWluLnRzeFwiOiBcIm1haW5Uc3hcIixcbiAgICAgICAgXCJzcmMvaW5kZXguY3NzXCI6IFwiaW5kZXhDc3NcIixcbiAgICAgICAgXCJzcmMvdml0ZS1lbnYuZC50c1wiOiBcInZpdGVFbnZcIixcbiAgICAgICAgXCJuZXRsaWZ5LnRvbWxcIjogXCJuZXRsaWZ5VG9tbFwiLFxuICAgICAgICBcIi5naXRpZ25vcmVcIjogXCJnaXRpZ25vcmVcIixcbiAgICAgICAgXCIubnBtcmNcIjogXCJucG1yY1wiXG4gICAgICB9O1xuXG4gICAgICBmb3IgKGNvbnN0IFtwYXRoLCBrZXldIG9mIE9iamVjdC5lbnRyaWVzKG9wdGlvbnNLZXlNYXApKSB7XG4gICAgICAgIGlmICh6aXBPcHRpb25zW2tleV0pIHtcbiAgICAgICAgICBpZiAocGF0aCA9PT0gXCJ2aXRlLmNvbmZpZy50c1wiKSB7XG4gICAgICAgICAgICB6aXAuZmlsZShcInZpdGUuY29uZmlnLnRzXCIsIGBpbXBvcnQgeyBkZWZpbmVDb25maWcgfSBmcm9tICd2aXRlJztcXG5pbXBvcnQgcmVhY3QgZnJvbSAnQHZpdGVqcy9wbHVnaW4tcmVhY3QnO1xcblxcbmV4cG9ydCBkZWZhdWx0IGRlZmluZUNvbmZpZyh7XFxuICBwbHVnaW5zOiBbcmVhY3QoKV0sXFxuICBidWlsZDoge1xcbiAgICBzb3VyY2VtYXA6IGZhbHNlXFxuICB9XFxufSk7XFxuYCk7XG4gICAgICAgICAgfSBlbHNlIGlmIChwYXRoID09PSBcImluZGV4Lmh0bWxcIikge1xuICAgICAgICAgICAgemlwLmZpbGUoXCJpbmRleC5odG1sXCIsIGA8IWRvY3R5cGUgaHRtbD5cbjxodG1sIGxhbmc9XCJlblwiPlxuICA8aGVhZD5cbiAgICA8bWV0YSBjaGFyc2V0PVwiVVRGLThcIiAvPlxuICAgIDxtZXRhIG5hbWU9XCJ2aWV3cG9ydFwiIGNvbnRlbnQ9XCJ3aWR0aD1kZXZpY2Utd2lkdGgsIGluaXRpYWwtc2NhbGU9MS4wXCIgLz5cbiAgICA8dGl0bGU+TmV4dXNDaGF0IEhUTUw1IFBvcnRhbDwvdGl0bGU+XG4gICAgPG1ldGEgbmFtZT1cImRlc2NyaXB0aW9uXCIgY29udGVudD1cIlJlc3BvbnNpdmUgd2ViIGFwcCBmZWF0dXJpbmcgbGl2ZSBjaGF0IHJvb21zLCBzY3JlZW4gcmVzb2x1dGlvbiBkZXRlY3RvciwgQUkgYXNzaXN0YW50IHBvd2VyZWQgYnkgR2VtaW5pLCBhbmQgZGVwbG95bWVudCBleHBvcnQgdG9vbHMuXCIgLz5cbiAgICA8bWV0YSBwcm9wZXJ0eT1cIm9nOnRpdGxlXCIgY29udGVudD1cIk5leHVzQ2hhdCBIVE1MNSBQb3J0YWxcIiAvPlxuICAgIDxtZXRhIHByb3BlcnR5PVwib2c6ZGVzY3JpcHRpb25cIiBjb250ZW50PVwiUmVzcG9uc2l2ZSB3ZWIgYXBwIGZlYXR1cmluZyBsaXZlIGNoYXQgcm9vbXMsIHNjcmVlbiByZXNvbHV0aW9uIGRldGVjdG9yLCBBSSBhc3Npc3RhbnQgcG93ZXJlZCBieSBHZW1pbmksIGFuZCBkZXBsb3ltZW50IGV4cG9ydCB0b29scy5cIiAvPlxuICAgIDxtZXRhIHByb3BlcnR5PVwib2c6dHlwZVwiIGNvbnRlbnQ9XCJ3ZWJzaXRlXCIgLz5cbiAgICA8bWV0YSBuYW1lPVwidHdpdHRlcjpjYXJkXCIgY29udGVudD1cInN1bW1hcnlfbGFyZ2VfaW1hZ2VcIiAvPlxuICAgIDxzY3JpcHQgc3JjPVwiaHR0cHM6Ly9jZG4udGFpbHdpbmRjc3MuY29tXCI+PC9zY3JpcHQ+XG4gIDwvaGVhZD5cbiAgPGJvZHk+XG4gICAgPGRpdiBpZD1cInJvb3RcIj48L2Rpdj5cbiAgICA8c2NyaXB0IHR5cGU9XCJtb2R1bGVcIiBzcmM9XCIvc3JjL21haW4udHN4XCI+PC9zY3JpcHQ+XG4gIDwvYm9keT5cbjwvaHRtbD5cbmApO1xuICAgICAgICAgIH0gZWxzZSBpZiAocGF0aCA9PT0gXCJ2ZXJjZWwuanNvblwiKSB7XG4gICAgICAgICAgICB6aXAuZmlsZShcInZlcmNlbC5qc29uXCIsIGB7XFxuICBcImJ1aWxkQ29tbWFuZFwiOiBcIm5wbSBydW4gYnVpbGRcIixcXG4gIFwib3V0cHV0RGlyZWN0b3J5XCI6IFwiZGlzdFwiLFxcbiAgXCJyZXdyaXRlc1wiOiBbXFxuICAgIHsgXCJzb3VyY2VcIjogXCIvYXBpLyguKilcIiwgXCJkZXN0aW5hdGlvblwiOiBcIi9hcGkvaW5kZXgudHNcIiB9LFxcbiAgICB7IFwic291cmNlXCI6IFwiLyguKilcIiwgXCJkZXN0aW5hdGlvblwiOiBcIi9pbmRleC5odG1sXCIgfVxcbiAgXSxcXG4gIFwiZnVuY3Rpb25zXCI6IHtcXG4gICAgXCJhcGkvaW5kZXgudHNcIjoge1xcbiAgICAgIFwibWF4RHVyYXRpb25cIjogMzBcXG4gICAgfVxcbiAgfVxcbn1cXG5gKTtcbiAgICAgICAgICB9IGVsc2UgaWYgKHBhdGggPT09IFwiLm5wbXJjXCIpIHtcbiAgICAgICAgICAgIHppcC5maWxlKFwiLm5wbXJjXCIsIGBhdWRpdD1mYWxzZVxcbmZ1bmQ9ZmFsc2VcXG5gKTtcbiAgICAgICAgICB9IGVsc2UgaWYgKHBhdGggPT09IFwibmV0bGlmeS50b21sXCIpIHtcbiAgICAgICAgICAgIHppcC5maWxlKFwibmV0bGlmeS50b21sXCIsIGBbYnVpbGRdXFxuICBjb21tYW5kID0gXCJucG0gcnVuIGJ1aWxkXCJcXG4gIHB1Ymxpc2ggPSBcImRpc3RcIlxcblxcbltbcmVkaXJlY3RzXV1cXG4gIGZyb20gPSBcIi8qXCJcXG4gIHRvID0gXCIvaW5kZXguaHRtbFwiXFxuICBzdGF0dXMgPSAyMDBcXG5gKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goYC8ke3BhdGh9YCk7XG4gICAgICAgICAgICAgIGlmIChyZXMub2spIHtcbiAgICAgICAgICAgICAgICBjb25zdCB0ZXh0ID0gYXdhaXQgcmVzLnRleHQoKTtcbiAgICAgICAgICAgICAgICB6aXAuZmlsZShwYXRoLCB0ZXh0KTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICBjb25zb2xlLndhcm4oYENvdWxkIG5vdCBmZXRjaCAke3BhdGh9YCwgZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIGlmICh6aXBPcHRpb25zLnJlYWRtZSkge1xuICAgICAgICB6aXAuZmlsZShcIlJFQURNRS5tZFwiLCBgIyBOZXh1c0NoYXQgJiBMaWJyZVN0eWxlIDIwMjYgV29ya3NwYWNlXFxuTWFzdGVyIEFkbWluIElEOiBNQSMzMTc1XFxuVGhlbWU6ICR7dGhlbWVDb25maWcudGhlbWVOYW1lfVxcblxcbiMjIEN1c3RvbSBBcmNoaXZlIE9wdGlvbnMgRW5hYmxlZDpcXG4ke09iamVjdC5lbnRyaWVzKHppcE9wdGlvbnMpLmZpbHRlcigoW2ssIHZdKSA9PiB2KS5tYXAoKFtrXSkgPT4gYC0gJHtrfWApLmpvaW4oJ1xcbicpfVxcblxcbiMjIFF1aWNrIFN0YXJ0OlxcbjEuIFJ1biBucG0gaW5zdGFsbFxcbjIuIFJ1biBucG0gcnVuIGRldlxcbmApO1xuICAgICAgfVxuXG4gICAgICBjb25zdCBjb250ZW50ID0gYXdhaXQgemlwLmdlbmVyYXRlQXN5bmMoeyB0eXBlOiBcImJsb2JcIiB9KTtcbiAgICAgIGNvbnN0IHVybCA9IFVSTC5jcmVhdGVPYmplY3RVUkwoY29udGVudCk7XG4gICAgICBjb25zdCBhID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYScpO1xuICAgICAgYS5ocmVmID0gdXJsO1xuICAgICAgYS5kb3dubG9hZCA9IGBOZXh1c0NoYXRfQ3VzdG9tX1NvdXJjZUFyY2hpdmVfdjQuM18ke0RhdGUubm93KCl9LnppcGA7XG4gICAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGEpO1xuICAgICAgYS5jbGljaygpO1xuICAgICAgZG9jdW1lbnQuYm9keS5yZW1vdmVDaGlsZChhKTtcbiAgICAgIFVSTC5yZXZva2VPYmplY3RVUkwodXJsKTtcbiAgICAgIHNldFppcFVwZGF0ZU1lc3NhZ2UoJ1pJUCBhcmNoaXZlIHVwZGF0ZWQgYW5kIGRvd25sb2FkZWQgc3VjY2Vzc2Z1bGx5IScpO1xuICAgICAgc2V0VGltZW91dCgoKSA9PiBzZXRaaXBVcGRhdGVNZXNzYWdlKCcnKSwgNDAwMCk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZ2VuZXJhdGluZyBjdXN0b20gemlwOlwiLCBlcnIpO1xuICAgICAgYWxlcnQoXCJGYWlsZWQgdG8gZ2VuZXJhdGUgemlwIGFyY2hpdmUuXCIpO1xuICAgIH1cbiAgfTtcblxuICAvLyBJZiBub3QgbG9nZ2VkIGluXG4gIGlmICghY3VycmVudFVzZXIpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gYmctWyNmN2Y1ZjBdIHRleHQtWyMyZDM3NDhdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNiByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW4gc2VsZWN0aW9uOmJnLVsjYTNjMWFkXSBzZWxlY3Rpb246dGV4dC1bIzJkMzc0OF1cIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIG9wYWNpdHktMjAgcG9pbnRlci1ldmVudHMtbm9uZSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICA8c3ZnIGNsYXNzTmFtZT1cInctWzE1MCVdIGgtWzE1MCVdIHRleHQtWyM5M2I1YzZdXCIgdmlld0JveD1cIjAgMCA4MDAgODAwXCIgZmlsbD1cIm5vbmVcIiB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCI+XG4gICAgICAgICAgICA8cGF0aCBkPVwiTTQwMCAxMDBDNDUwIDIwMCA1NTAgMjUwIDY1MCAzMDBDNTUwIDM1MCA0NTAgNDAwIDQwMCA1MDBDMzUwIDQwMCAyNTAgMzUwIDE1MCAzMDBDMjUwIDI1MCAzNTAgMjAwIDQwMCAxMDBaXCIgZmlsbD1cImN1cnJlbnRDb2xvclwiIGZpbGxPcGFjaXR5PVwiMC4zXCIvPlxuICAgICAgICAgICAgPHBhdGggZD1cIk02MDAgNTAwQzYzMCA1NjAgNzAwIDU4MCA3NjAgNjAwQzcwMCA2MjAgNjMwIDY0MCA2MDAgNzAwQzU3MCA2NDAgNTAwIDYyMCA0NDAgNjAwQzUwMCA1ODAgNTcwIDU2MCA2MDAgNTAwWlwiIGZpbGw9XCIjYjkxYzFjXCIgZmlsbE9wYWNpdHk9XCIwLjJcIi8+XG4gICAgICAgICAgICA8cGF0aCBkPVwiTTIwMCAyMDBDMjIwIDI0MCAyNzAgMjU1IDMxMCAyNzBDMjcwIDI4NSAyMjAgMzAwIDIwMCAzNDBDMTgwIDMwMCAxMzAgMjg1IDkwIDI3MEMxMzAgMjU1IDE4MCAyNDAgMjAwIDIwMFpcIiBmaWxsPVwiI2EzYzFhZFwiIGZpbGxPcGFjaXR5PVwiMC4zXCIvPlxuICAgICAgICAgICAgPGNpcmNsZSBjeD1cIjQwMFwiIGN5PVwiNDAwXCIgcj1cIjMwMFwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHN0cm9rZVdpZHRoPVwiMVwiIHN0cm9rZURhc2hhcnJheT1cIjQgOFwiIHN0cm9rZU9wYWNpdHk9XCIwLjRcIi8+XG4gICAgICAgICAgICA8Y2lyY2xlIGN4PVwiNDAwXCIgY3k9XCI0MDBcIiByPVwiMjAwXCIgc3Ryb2tlPVwiI2I5MWMxY1wiIHN0cm9rZVdpZHRoPVwiMVwiIHN0cm9rZURhc2hhcnJheT1cIjYgNlwiIHN0cm9rZU9wYWNpdHk9XCIwLjNcIi8+XG4gICAgICAgICAgPC9zdmc+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUvOTUgYmFja2Ryb3AtYmx1ci1tZCBib3JkZXIgYm9yZGVyLVsjZTVlMGQ4XSBwLTggcm91bmRlZC0zeGwgc2hhZG93LXhsIG1heC13LW1kIHctZnVsbCBzcGFjZS15LTYgcmVsYXRpdmUgei0xMFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgc3BhY2UteS0zXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm14LWF1dG8gZmxleCBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgICAgICAgICA8TkNMb2dvIHNpemU9XCJsZ1wiIGxvZ29Vcmw9e3RoZW1lQ29uZmlnLmxvZ29Vcmx9IC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1bIzJkMzc0OF1cIj57dGhlbWVDb25maWcudGhlbWVOYW1lfTwvaDE+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtWyM3MTgwOTZdXCI+e3RoZW1lQ29uZmlnLnBvd2VyZWRCeX08L3A+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7YXV0aEVycm9yICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctWyNmZGU4ZThdIGJvcmRlciBib3JkZXItWyNmOGI0YjRdIHAtMyByb3VuZGVkLXhsIHRleHQteHMgdGV4dC1bIzliMmMyY10gZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgPEFsZXJ0VHJpYW5nbGUgY2xhc3NOYW1lPVwidy00IGgtNCBzaHJpbmstMFwiIC8+XG4gICAgICAgICAgICAgIHthdXRoRXJyb3J9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAge2F1dGhTdWNjZXNzICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctWyNlNmZmZmFdIGJvcmRlciBib3JkZXItWyNiMmY1ZWFdIHAtMyByb3VuZGVkLXhsIHRleHQteHMgdGV4dC1bIzIzNGU1Ml0gZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgPENoZWNrIGNsYXNzTmFtZT1cInctNCBoLTQgc2hyaW5rLTBcIiAvPlxuICAgICAgICAgICAgICB7YXV0aFN1Y2Nlc3N9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAge2F1dGhWaWV3ID09PSAnbG9naW4nICYmIChcbiAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVMb2dpbn0gY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LVsjNGE1NTY4XVwiPlVzZXJuYW1lIG9yIElEPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8aW5wdXQgXG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiIFxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3VzZXJuYW1lSW5wdXR9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRVc2VybmFtZUlucHV0KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctWyNmZGZiZjddIGJvcmRlciBib3JkZXItWyNlNWUwZDhdIHJvdW5kZWQteGwgcHgtNCBweS0zIHRleHQtc20gdGV4dC1bIzJkMzc0OF0gZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1bIzkzYjVjNl1cIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LVsjNGE1NTY4XVwiPlBhc3N3b3JkPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8aW5wdXQgXG4gICAgICAgICAgICAgICAgICB0eXBlPVwicGFzc3dvcmRcIiBcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtwYXNzd29yZElucHV0fVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0UGFzc3dvcmRJbnB1dChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLVsjZmRmYmY3XSBib3JkZXIgYm9yZGVyLVsjZTVlMGQ4XSByb3VuZGVkLXhsIHB4LTQgcHktMyB0ZXh0LXNtIHRleHQtWyMyZDM3NDhdIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItWyM5M2I1YzZdXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8YnV0dG9uIFxuICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweS0zIGJnLVsjOTNiNWM2XSBob3ZlcjpiZy1bIzdmYTViOF0gdGV4dC13aGl0ZSBmb250LXNlbWlib2xkIHJvdW5kZWQteGwgdHJhbnNpdGlvbi1jb2xvcnMgc2hhZG93LW1kIHNoYWRvdy1bIzkzYjVjNl0vMzBcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgU2lnbiBJblxuICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuXG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC14cyBwdC0yXCI+XG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIiBcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEF1dGhWaWV3KCdyZWdpc3RlcicpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1bIzZiOGUyM10gaG92ZXI6dW5kZXJsaW5lIGZvbnQtbWVkaXVtXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICBDcmVhdGUgbmV3IGFjY291bnRcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIFxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiIFxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QXV0aFZpZXcoJ2ZvcmdvdCcpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1bIzcxODA5Nl0gaG92ZXI6dGV4dC1bIzJkMzc0OF1cIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIEZvcmdvdCBwYXNzd29yZD9cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHthdXRoVmlldyA9PT0gJ3JlZ2lzdGVyJyAmJiAoXG4gICAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlUmVnaXN0ZXJ9IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMS41XCI+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1bIzRhNTU2OF1cIj5VbmlxdWUgVXNlcm5hbWUgLyBJRDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGlucHV0IFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIiBcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXt1c2VybmFtZUlucHV0fVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0VXNlcm5hbWVJbnB1dChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4gYWxleF9kZXZcIlxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1bI2ZkZmJmN10gYm9yZGVyIGJvcmRlci1bI2U1ZTBkOF0gcm91bmRlZC14bCBweC00IHB5LTMgdGV4dC1zbSB0ZXh0LVsjMmQzNzQ4XSBwbGFjZWhvbGRlci1bI2EwYWVjMF0gZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1bIzkzYjVjNl1cIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LVsjNGE1NTY4XVwiPkVtYWlsIEFkZHJlc3M8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxpbnB1dCBcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJlbWFpbFwiIFxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2VtYWlsSW5wdXR9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRFbWFpbElucHV0KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiYWxleEBleGFtcGxlLmNvbVwiXG4gICAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLVsjZmRmYmY3XSBib3JkZXIgYm9yZGVyLVsjZTVlMGQ4XSByb3VuZGVkLXhsIHB4LTQgcHktMyB0ZXh0LXNtIHRleHQtWyMyZDM3NDhdIHBsYWNlaG9sZGVyLVsjYTBhZWMwXSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLVsjOTNiNWM2XVwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtWyM0YTU1NjhdXCI+TW9iaWxlIE51bWJlcjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGlucHV0IFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIiBcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXttb2JpbGVJbnB1dH1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldE1vYmlsZUlucHV0KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiKzEtNTU1LTAxOTlcIlxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLVsjZmRmYmY3XSBib3JkZXIgYm9yZGVyLVsjZTVlMGQ4XSByb3VuZGVkLXhsIHB4LTQgcHktMyB0ZXh0LXNtIHRleHQtWyMyZDM3NDhdIHBsYWNlaG9sZGVyLVsjYTBhZWMwXSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLVsjOTNiNWM2XVwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtWyM0YTU1NjhdXCI+UGFzc3dvcmQ8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxpbnB1dCBcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJwYXNzd29yZFwiIFxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3Bhc3N3b3JkSW5wdXR9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRQYXNzd29yZElucHV0KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwi4oCi4oCi4oCi4oCi4oCi4oCi4oCi4oCiXCJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctWyNmZGZiZjddIGJvcmRlciBib3JkZXItWyNlNWUwZDhdIHJvdW5kZWQteGwgcHgtNCBweS0zIHRleHQtc20gdGV4dC1bIzJkMzc0OF0gcGxhY2Vob2xkZXItWyNhMGFlYzBdIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItWyM5M2I1YzZdXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8YnV0dG9uIFxuICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweS0zIGJnLVsjOTNiNWM2XSBob3ZlcjpiZy1bIzdmYTViOF0gdGV4dC13aGl0ZSBmb250LXNlbWlib2xkIHJvdW5kZWQteGwgdHJhbnNpdGlvbi1jb2xvcnMgc2hhZG93LW1kIHNoYWRvdy1bIzkzYjVjNl0vMzBcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgUmVnaXN0ZXIgQWNjb3VudFxuICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHB0LTJcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIFxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiIFxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QXV0aFZpZXcoJ2xvZ2luJyl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtWyM2YjhlMjNdIGhvdmVyOnVuZGVybGluZSBmb250LW1lZGl1bVwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgQWxyZWFkeSBoYXZlIGFuIGFjY291bnQ/IFNpZ24gSW5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHthdXRoVmlldyA9PT0gJ2ZvcmdvdCcgJiYgKFxuICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZUZvcmdvdFBhc3N3b3JkfSBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtWyM0YTU1NjhdXCI+RW1haWwgQWRkcmVzczwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGlucHV0IFxuICAgICAgICAgICAgICAgICAgdHlwZT1cImVtYWlsXCIgXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17ZW1haWxJbnB1dH1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldEVtYWlsSW5wdXQoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJhbGV4QGV4YW1wbGUuY29tXCJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctWyNmZGZiZjddIGJvcmRlciBib3JkZXItWyNlNWUwZDhdIHJvdW5kZWQteGwgcHgtNCBweS0zIHRleHQtc20gdGV4dC1bIzJkMzc0OF0gcGxhY2Vob2xkZXItWyNhMGFlYzBdIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItWyM5M2I1YzZdXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8YnV0dG9uIFxuICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweS0zIGJnLVsjOTNiNWM2XSBob3ZlcjpiZy1bIzdmYTViOF0gdGV4dC13aGl0ZSBmb250LXNlbWlib2xkIHJvdW5kZWQteGwgdHJhbnNpdGlvbi1jb2xvcnMgc2hhZG93LW1kIHNoYWRvdy1bIzkzYjVjNl0vMzBcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgUmVxdWVzdCA4LURpZ2l0IENvZGVcbiAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBwdC0yXCI+XG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIiBcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEF1dGhWaWV3KCdsb2dpbicpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LVsjNzE4MDk2XSBob3Zlcjp0ZXh0LVsjMmQzNzQ4XVwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgQmFjayB0byBTaWduIEluXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9mb3JtPlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7YXV0aFZpZXcgPT09ICdyZXNldC1wcm9tcHQnICYmIChcbiAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVSZXNldFBhc3N3b3JkU3VibWl0fSBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAge3NpbXVsYXRlZENvZGUgJiYgKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctWyNlNmZmZmFdIGJvcmRlciBib3JkZXItWyNiMmY1ZWFdIHAtMyByb3VuZGVkLXhsIHRleHQteHMgdGV4dC1bIzIzNGU1Ml0gc3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtYm9sZFwiPvCfk6ggU2ltdWxhdGVkIFJlY292ZXJ5IENvZGU6PC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LXNtIHRyYWNraW5nLXdpZGVyIGZvbnQtYm9sZFwiPntzaW11bGF0ZWRDb2RlfTwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LVsjNGE1NTY4XVwiPkVudGVyIENvZGU8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxpbnB1dCBcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCIgXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17dGVtcENvZGVJbnB1dH1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldFRlbXBDb2RlSW5wdXQoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJDT0RFXCJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctWyNmZGZiZjddIGJvcmRlciBib3JkZXItWyNlNWUwZDhdIHJvdW5kZWQteGwgcHgtNCBweS0zIHRleHQtc20gdGV4dC1bIzJkMzc0OF0gdXBwZXJjYXNlIGZvbnQtbW9ubyB0cmFja2luZy13aWRlciBwbGFjZWhvbGRlci1bI2EwYWVjMF0gZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1bIzkzYjVjNl1cIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LVsjNGE1NTY4XVwiPk5ldyBQYXNzd29yZDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGlucHV0IFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCIgXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17bmV3UGFzc3dvcmRJbnB1dH1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldE5ld1Bhc3N3b3JkSW5wdXQoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCLigKLigKLigKLigKLigKLigKLigKLigKJcIlxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1bI2ZkZmJmN10gYm9yZGVyIGJvcmRlci1bI2U1ZTBkOF0gcm91bmRlZC14bCBweC00IHB5LTMgdGV4dC1zbSB0ZXh0LVsjMmQzNzQ4XSBwbGFjZWhvbGRlci1bI2EwYWVjMF0gZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1bIzkzYjVjNl1cIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB5LTMgYmctWyM5M2I1YzZdIGhvdmVyOmJnLVsjN2ZhNWI4XSB0ZXh0LXdoaXRlIGZvbnQtc2VtaWJvbGQgcm91bmRlZC14bCB0cmFuc2l0aW9uLWNvbG9ycyBzaGFkb3ctbWQgc2hhZG93LVsjOTNiNWM2XS8zMFwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICBSZXNldCBQYXNzd29yZCAmIExvZ2luXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9mb3JtPlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgKTtcbiAgfVxuXG4gIC8vIExvZ2dlZCBpbiB2aWV3XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gYmctWyNmN2Y1ZjBdIHRleHQtWyMyZDM3NDhdIGZsZXggZmxleC1jb2wgc2VsZWN0aW9uOmJnLVsjYTNjMWFkXSBzZWxlY3Rpb246dGV4dC1bIzJkMzc0OF1cIj5cbiAgICAgIHsvKiBNYWluIENvbnRhaW5lciAqL31cbiAgICAgIDxtYWluIGNsYXNzTmFtZT17YGZsZXgtMSBmbGV4IGZsZXgtY29sICR7YWN0aXZlVGFiID09PSAnY2hhdCcgfHwgYWN0aXZlVGFiID09PSAnaG9tZScgPyAncC0wIG1heC13LW5vbmUnIDogJ21heC13LTR4bCB3LWZ1bGwgbXgtYXV0byBwLTQgbWQ6cC02J31gfT5cblxuICAgICAgICB7ZHJpdmVFcnJvckFsZXJ0ICYmIGFjdGl2ZVRhYiAhPT0gJ2NoYXQnICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTYgYmctWyNmZGU4ZThdIGJvcmRlciBib3JkZXItWyNmOGI0YjRdIHAtNCByb3VuZGVkLTJ4bCB0ZXh0LXhzIHRleHQtWyM5YjJjMmNdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBzaGFkb3ctc21cIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgPEFsZXJ0VHJpYW5nbGUgY2xhc3NOYW1lPVwidy01IGgtNSBzaHJpbmstMCB0ZXh0LXJlZC01MDBcIiAvPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bVwiPntkcml2ZUVycm9yQWxlcnR9PC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8YnV0dG9uIFxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVUYWIoJ2RyaXZlJyl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiBiZy1yZWQtNjAwIHRleHQtd2hpdGUgcm91bmRlZC14bCBmb250LWJvbGQgaG92ZXI6YmctcmVkLTcwMCB0cmFuc2l0aW9uLWNvbG9ycyBzaGFkb3ctc21cIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICBHb29nbGUgRHJpdmVcbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuXG4gICAgICAgIHsvKiBIT01FIFBBR0U6IENvbm5lY3RlZCBVc2VycyAmIENoYXRzIExpc3QgKi99XG4gICAgICAgIHthY3RpdmVUYWIgPT09ICdob21lJyAmJiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgZmxleCBmbGV4LWNvbCBiZy13aGl0ZSBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNiBweS00IGJvcmRlci1iIGJvcmRlci1bI2U1ZTBkOF0gYmctWyNmZGZiZjddIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiByZWxhdGl2ZVwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgcm91bmRlZC1mdWxsIGJnLVsjOTNiNWM2XSB0ZXh0LXdoaXRlIGZvbnQtYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LWJhc2Ugc2hhZG93LW1kIG92ZXJmbG93LWhpZGRlblwiPlxuICAgICAgICAgICAgICAgICAge2J1c2luZXNzUHJvZmlsZS5wcm9maWxlUGhvdG8gPyAoXG4gICAgICAgICAgICAgICAgICAgIDxpbWcgc3JjPXtidXNpbmVzc1Byb2ZpbGUucHJvZmlsZVBob3RvfSBjbGFzc05hbWU9XCJ3LWZ1bGwgaC1mdWxsIG9iamVjdC1jb3ZlclwiIC8+XG4gICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICBjdXJyZW50VXNlci51c2VybmFtZS5jaGFyQXQoMCkudG9VcHBlckNhc2UoKVxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtWyMyZDM3NDhdXCI+QHtjdXJyZW50VXNlci51c2VybmFtZX08L2gyPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHJlbGF0aXZlXCI+XG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldElzQWRkQ29udGFjdE9wZW4odHJ1ZSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTIgYmctWyNmMGVkZTZdIGhvdmVyOmJnLVsjZTVlMGQ4XSB0ZXh0LVsjNGE1NTY4XSByb3VuZGVkLXhsIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgICAgICAgIHRpdGxlPVwiQ29ubmVjdCBVc2VyXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8VXNlclBsdXMgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXNUb3BNZW51T3BlbighaXNUb3BNZW51T3Blbil9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiBiZy1bI2YwZWRlNl0gaG92ZXI6YmctWyNlNWUwZDhdIHRleHQtWyM0YTU1NjhdIHJvdW5kZWQteGwgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIk1lbnVcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8TW9yZVZlcnRpY2FsIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgICAgIHtpc1RvcE1lbnVPcGVuICYmIChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSByaWdodC0wIHRvcC0xMSB3LTUyIGJnLXdoaXRlIHRleHQtWyMyZDM3NDhdIHJvdW5kZWQtMnhsIHNoYWRvdy14bCBweS0yIHotNTAgYm9yZGVyIGJvcmRlci1bI2U1ZTBkOF0gc3BhY2UteS0wLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIFxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4geyBzZXRJc1RvcE1lbnVPcGVuKGZhbHNlKTsgc2V0QWN0aXZlVGFiKCdhbGJ1bXMnKTsgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC00IHB5LTIgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gaG92ZXI6YmctWyNmN2Y1ZjBdIGZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8SW1hZ2VJY29uIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1bIzkzYjVjNl1cIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+QWxidW1zPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7IHNldElzVG9wTWVudU9wZW4oZmFsc2UpOyBzZXRBY3RpdmVUYWIoJ2RyaXZlJyk7IH19XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtNCBweS0yIHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtbWVkaXVtIGhvdmVyOmJnLVsjZjdmNWYwXSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPEhhcmREcml2ZSBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtWyM2YjhlMjNdXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkdvb2dsZSBEcml2ZTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICB7KGN1cnJlbnRVc2VyLmlzQWRtaW4gfHwgY3VycmVudFVzZXIuaXNNYXN0ZXJBZG1pbikgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4geyBzZXRJc1RvcE1lbnVPcGVuKGZhbHNlKTsgaGFuZGxlT3BlbkFkbWluU3VpdGUoKTsgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTQgcHktMiB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSBob3ZlcjpiZy1bI2Y3ZjVmMF0gZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8U2hpZWxkIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1bI2I5MWMxY11cIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5BZG1pbiBTdWl0ZTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHsgc2V0SXNUb3BNZW51T3BlbihmYWxzZSk7IHNldEFjdGl2ZVRhYignc2V0dGluZ3MnKTsgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC00IHB5LTIgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gaG92ZXI6YmctWyNmN2Y1ZjBdIGZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8U2V0dGluZ3MgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LVsjNGE1NTY4XVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5TZXR0aW5nczwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBmbGV4IGZsZXgtY29sIG92ZXJmbG93LXktYXV0b1wiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTYgcHktMy41IGJnLVsjZmRmYmY3XSBib3JkZXItYiBib3JkZXItWyNlNWUwZDhdIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LVsjNzE4MDk2XSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4+Q29ubmVjdGVkIFVzZXJzICYgQ2hhbm5lbHMgKHtjb250YWN0cy5sZW5ndGh9KTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICB7aXNIZWFkZXJTZWFyY2hPcGVuICYmIChcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0IFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VhcmNoUXVlcnl9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0U2VhcmNoUXVlcnkoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIGNvbnRhY3RzLi4uXCJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zIHB5LTEgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1bI2U1ZTBkOF0gcm91bmRlZC14bCB0ZXh0LXhzIHRleHQtWyMyZDM3NDhdIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItWyM5M2I1YzZdXCJcbiAgICAgICAgICAgICAgICAgICAgICBhdXRvRm9jdXNcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uIFxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc0hlYWRlclNlYXJjaE9wZW4oIWlzSGVhZGVyU2VhcmNoT3Blbil9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMS41IGhvdmVyOmJnLVsjZTVlMGQ4XSByb3VuZGVkLWxnIHRyYW5zaXRpb24tY29sb3JzIHRleHQtWyM3MTgwOTZdXCJcbiAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJTZWFyY2hcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8U2VhcmNoIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGl2aWRlLXkgZGl2aWRlLVsjZTVlMGQ4XVwiPlxuXG4gICAgICAgICAgICAgIHtjb250YWN0c1xuICAgICAgICAgICAgICAgIC5maWx0ZXIoYyA9PiBjLm5hbWUudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2hRdWVyeS50b0xvd2VyQ2FzZSgpKSB8fCBjLmhhbmRsZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNlYXJjaFF1ZXJ5LnRvTG93ZXJDYXNlKCkpKVxuICAgICAgICAgICAgICAgIC5tYXAoY29udGFjdCA9PiAoXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uIFxuICAgICAgICAgICAgICAgICAgICBrZXk9e2NvbnRhY3QuaWR9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICBzZXRBY3RpdmVDb250YWN0KGNvbnRhY3QpO1xuICAgICAgICAgICAgICAgICAgICAgIHNldEFjdGl2ZVRhYignY2hhdCcpO1xuICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcC00IGZsZXggaXRlbXMtY2VudGVyIGdhcC00IGhvdmVyOmJnLVsjZmRmYmY3XSB0cmFuc2l0aW9uLWNvbG9ycyB0ZXh0LWxlZnQgZ3JvdXBcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2B3LTEyIGgtMTIgcm91bmRlZC1mdWxsICR7Y29udGFjdC5hdmF0YXJCZ30gdGV4dC13aGl0ZSBmb250LWJvbGQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1iYXNlIHNoYWRvdy1tZGB9PlxuICAgICAgICAgICAgICAgICAgICAgICAge2NvbnRhY3QubmFtZS5jaGFyQXQoMCkudG9VcHBlckNhc2UoKX1cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICB7Y29udGFjdC5vbmxpbmUgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBib3R0b20tMCByaWdodC0wIHctMy41IGgtMy41IGJnLWdyZWVuLTUwMCBib3JkZXItMiBib3JkZXItd2hpdGUgcm91bmRlZC1mdWxsXCI+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgbWluLXctMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LVsjMmQzNzQ4XSBncm91cC1ob3Zlcjp0ZXh0LVsjOTNiNWM2XSB0cmFuc2l0aW9uLWNvbG9ycyB0cnVuY2F0ZVwiPntjb250YWN0Lm5hbWV9PC9oMz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtWyM3MTgwOTZdXCI+e2NvbnRhY3QudGltZXN0YW1wfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtWyM3MTgwOTZdIHRydW5jYXRlXCI+e2NvbnRhY3QubGFzdE1lc3NhZ2V9PC9wPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICB7Y29udGFjdC51bnJlYWRDb3VudCAmJiBjb250YWN0LnVucmVhZENvdW50ID4gMCA/IChcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctNSBoLTUgYmctWyM5M2I1YzZdIHRleHQtd2hpdGUgdGV4dC1bMTBweF0gZm9udC1ib2xkIHJvdW5kZWQtZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBzaGFkb3ctc21cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtjb250YWN0LnVucmVhZENvdW50fVxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApIDogbnVsbH1cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG5cbiAgICAgICAgey8qIENIQVQgVEFCICovfVxuICAgICAgICB7YWN0aXZlVGFiID09PSAnY2hhdCcgJiYgYWN0aXZlQ29udGFjdCAmJiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleC0xIGZsZXggZmxleC1jb2wgYmctd2hpdGUgb3ZlcmZsb3ctaGlkZGVuIHNoYWRvdy1ub25lXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTYgcHktNCBib3JkZXItYiBib3JkZXItWyNlNWUwZDhdIGJnLVsjZmRmYmY3XSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcmVsYXRpdmVcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVUYWIoJ2hvbWUnKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMS41IHRleHQtWyM0YTU1NjhdIGhvdmVyOmJnLVsjZjBlZGU2XSByb3VuZGVkLXhsIHRyYW5zaXRpb24tY29sb3JzIG1yLTFcIlxuICAgICAgICAgICAgICAgICAgdGl0bGU9XCJCYWNrIHRvIEhvbWVcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxBcnJvd0xlZnQgY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YHctMTAgaC0xMCByb3VuZGVkLWZ1bGwgJHthY3RpdmVDb250YWN0LmF2YXRhckJnfSB0ZXh0LXdoaXRlIGZvbnQtYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LXNtIHNoYWRvdy1tZGB9PlxuICAgICAgICAgICAgICAgICAge2FjdGl2ZUNvbnRhY3QubmFtZS5jaGFyQXQoMCkudG9VcHBlckNhc2UoKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1ib2xkIHRleHQtWyMyZDM3NDhdXCI+e2FjdGl2ZUNvbnRhY3QubmFtZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LVsjNzE4MDk2XSBibG9jayBmb250LW1vbm9cIj57YWN0aXZlQ29udGFjdC5oYW5kbGV9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bOXB4XSB0ZXh0LVsjNzE4MDk2XS84MCBibG9ja1wiPih7YWN0aXZlQ29udGFjdC5uYW1lLnNwbGl0KCcgJylbMF19KTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiByZWxhdGl2ZVwiPlxuICAgICAgICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc1ZpZGVvQ2FsbEFjdGl2ZSh0cnVlKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMi41IGJnLVsjZjBlZGU2XSBob3ZlcjpiZy1bI2U1ZTBkOF0gdGV4dC1bIzRhNTU2OF0gcm91bmRlZC14bCB0cmFuc2l0aW9uLWNvbG9ycyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGRcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxWaWRlbyBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtWyM5M2I1YzZdXCIgLz5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImhpZGRlbiBtZDppbmxpbmVcIj5TZWN1cmUgVmlkZW8gQ2FsbDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cbiAgICAgICAgICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldElzQ2hhdE1lbnVPcGVuKHByZXYgPT4gIXByZXYpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTIuNSBiZy1bI2YwZWRlNl0gaG92ZXI6YmctWyNlNWUwZDhdIHRleHQtWyM0YTU1NjhdIHJvdW5kZWQteGwgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIk1lbnUgT3B0aW9uc1wiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxNb3JlVmVydGljYWwgY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgICAge2lzQ2hhdE1lbnVPcGVuICYmIChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSByaWdodC0wIHRvcC0xMiB3LTY0IGJnLVsjMjIyYjMyXSB0ZXh0LXdoaXRlIHJvdW5kZWQtMnhsIHNoYWRvdy0yeGwgcHktMiB6LTUwIGJvcmRlciBib3JkZXItd2hpdGUvMTAgc3BhY2UteS0wLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIFxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4geyBzZXRJc0NoYXRNZW51T3BlbihmYWxzZSk7IGFsZXJ0KCdTZWFyY2ggY2hhdCBtZXNzYWdlcycpOyB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTQgcHktMi41IHRleHQtbGVmdCB0ZXh0LXNtIGhvdmVyOmJnLXdoaXRlLzEwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VhcmNoIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1ncmF5LTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5TZWFyY2g8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHsgc2V0SXNDaGF0TWVudU9wZW4oZmFsc2UpOyBzZXRBY3RpdmVUYWIoJ2RyaXZlJyk7IH19XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtNCBweS0yLjUgdGV4dC1sZWZ0IHRleHQtc20gaG92ZXI6Ymctd2hpdGUvMTAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxGb2xkZXJBcmNoaXZlIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1ncmF5LTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5NZWRpYSwgbGlua3MsIGFuZCBkb2NzPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7IHNldElzQ2hhdE1lbnVPcGVuKGZhbHNlKTsgc2V0QWN0aXZlVGFiKCdhbGJ1bXMnKTsgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC00IHB5LTIuNSB0ZXh0LWxlZnQgdGV4dC1zbSBob3ZlcjpiZy13aGl0ZS8xMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPEltYWdlSWNvbiBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtZ3JheS00MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+QWxidW1zPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7IHNldElzQ2hhdE1lbnVPcGVuKGZhbHNlKTsgc2V0QWN0aXZlVGFiKCdkcml2ZScpOyB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTQgcHktMi41IHRleHQtbGVmdCB0ZXh0LXNtIGhvdmVyOmJnLXdoaXRlLzEwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8SGFyZERyaXZlIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1ncmF5LTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5Hb29nbGUgRHJpdmU8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgeyhjdXJyZW50VXNlci5pc0FkbWluIHx8IGN1cnJlbnRVc2VyLmlzTWFzdGVyQWRtaW4pICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZU9wZW5BZG1pblN1aXRlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtNCBweS0yLjUgdGV4dC1sZWZ0IHRleHQtc20gaG92ZXI6Ymctd2hpdGUvMTAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8U2hpZWxkIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1ncmF5LTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkFkbWluIFN1aXRlPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIFxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4geyBzZXRJc0NoYXRNZW51T3BlbihmYWxzZSk7IHNldEFjdGl2ZVRhYignc2V0dGluZ3MnKTsgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC00IHB5LTIuNSB0ZXh0LWxlZnQgdGV4dC1zbSBob3ZlcjpiZy13aGl0ZS8xMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPFNldHRpbmdzIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1ncmF5LTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5TZXR0aW5nczwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci10IGJvcmRlci13aGl0ZS8xMCBteS0xXCI+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHsgc2V0SXNDaGF0TWVudU9wZW4oZmFsc2UpOyBwbGF5U3lzdGVtU291bmQoJ2NhbGwnKTsgYWxlcnQoYPCfk54gU3RhcnRpbmcgc2VjdXJlIHZvaWNlIGNhbGwgd2l0aCAke2FjdGl2ZUNvbnRhY3QubmFtZX0uLi5gKTsgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC00IHB5LTIuNSB0ZXh0LWxlZnQgdGV4dC1zbSBob3ZlcjpiZy13aGl0ZS8xMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPFBob25lIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1ncmF5LTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5Wb2ljZSBjYWxsPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7IHNldElzQ2hhdE1lbnVPcGVuKGZhbHNlKTsgcGxheVN5c3RlbVNvdW5kKCdjYWxsJyk7IHNldElzVmlkZW9DYWxsQWN0aXZlKHRydWUpOyB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTQgcHktMi41IHRleHQtbGVmdCB0ZXh0LXNtIGhvdmVyOmJnLXdoaXRlLzEwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8VmlkZW8gY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWdyYXktNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlZpZGVvIGNhbGw8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItdCBib3JkZXItd2hpdGUvMTAgbXktMVwiPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7IFxuICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRJc0NoYXRNZW51T3BlbihmYWxzZSk7IFxuICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRNZXNzYWdlcyhwcmV2ID0+ICh7IC4uLnByZXYsIFthY3RpdmVDb250YWN0LmlkXTogW10gfSkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC00IHB5LTIuNSB0ZXh0LWxlZnQgdGV4dC1zbSBob3ZlcjpiZy13aGl0ZS8xMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyB0cmFuc2l0aW9uLWNvbG9ycyB0ZXh0LXJlZC00MDBcIlxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxUcmFzaCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkNsZWFyIGNoYXQ8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgb3ZlcmZsb3cteS1hdXRvIHAtNiBzcGFjZS15LTQgYmctWyNmZGZiZjddLzUwXCI+XG4gICAgICAgICAgICAgIHsobWVzc2FnZXNbYWN0aXZlQ29udGFjdC5pZF0gfHwgW10pLm1hcChtc2cgPT4gKFxuICAgICAgICAgICAgICAgIDxkaXYga2V5PXttc2cuaWR9IGNsYXNzTmFtZT17YGZsZXggZmxleC1jb2wgJHttc2cuc2VuZGVyID09PSBjdXJyZW50VXNlci51c2VybmFtZSA/ICdpdGVtcy1lbmQnIDogJ2l0ZW1zLXN0YXJ0J31gfT5cbiAgICAgICAgICAgICAgICAgIHttc2cuaXNBZG1pbldhcm5pbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIG15LTIgYmctWyNmZmZhZjBdIGJvcmRlciBib3JkZXItWyNmZWViYzhdIHAtMyByb3VuZGVkLXhsIHRleHQteHMgdGV4dC1bIzljNDIyMV0gZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8QWxlcnRUcmlhbmdsZSBjbGFzc05hbWU9XCJ3LTQgaC00IHNocmluay0wIHRleHQtWyNkZDZiMjBdXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2Pnttc2cuY29udGVudH08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LVs4MCVdIHNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC14cyB0ZXh0LVsjNzE4MDk2XSBweC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtWyM0YTU1NjhdXCI+QHttc2cuc2VuZGVyfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPsK3PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e21zZy50aW1lc3RhbXB9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgcC00IHJvdW5kZWQtMnhsIHRleHQtc20gbGVhZGluZy1yZWxheGVkICR7bXNnLnNlbmRlciA9PT0gY3VycmVudFVzZXIudXNlcm5hbWUgPyAnYmctWyM5M2I1YzZdIHRleHQtd2hpdGUgZm9udC1tZWRpdW0gcm91bmRlZC10ci1ub25lIHNoYWRvdy1zbScgOiAnYmctd2hpdGUgdGV4dC1bIzJkMzc0OF0gYm9yZGVyIGJvcmRlci1bI2U1ZTBkOF0gcm91bmRlZC10bC1ub25lIHNoYWRvdy1zbSd9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICB7bXNnLmNvbnRlbnR9XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVNlbmRNZXNzYWdlfSBjbGFzc05hbWU9XCJwLTQgYm9yZGVyLXQgYm9yZGVyLVsjZTVlMGQ4XSBiZy13aGl0ZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGZsZXgtMSBmbGV4IGl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgICAgICAgIDxpbnB1dCBcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtjaGF0SW5wdXR9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRDaGF0SW5wdXQoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJcIlxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLVsjZmRmYmY3XSBib3JkZXIgYm9yZGVyLVsjZTVlMGQ4XSByb3VuZGVkLXhsIHBsLTQgcHItMTIgcHktMyB0ZXh0LXNtIHRleHQtWyMyZDM3NDhdIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItWyM5M2I1YzZdXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXshY2hhdElucHV0LnRyaW0oKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIHJpZ2h0LTMgcC0yIGJnLVsjOTNiNWM2XSBob3ZlcjpiZy1bIzdmYTViOF0gZGlzYWJsZWQ6b3BhY2l0eS00MCB0ZXh0LXdoaXRlIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1jb2xvcnMgc2hhZG93LXNtIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCJcbiAgICAgICAgICAgICAgICAgIHRpdGxlPVwiU2VuZCBNZXNzYWdlXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8U2VuZCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG5cbiAgICAgICAgey8qIFRBQiAyOiBBTEJVTVMgKi99XG4gICAgICAgIHthY3RpdmVUYWIgPT09ICdhbGJ1bXMnICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLVsjMGYwZjBmXSB0ZXh0LXdoaXRlIG1pbi1oLXNjcmVlbiAtbS00IG1kOi1tLTggcC00IG1kOnAtNiBzcGFjZS15LTZcIj5cbiAgICAgICAgICAgIHsvKiBUb3AgQmFyICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcGItMyBib3JkZXItYiBib3JkZXItZ3JheS04MDBcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGZvbnQtYm9sZCB0ZXh0LWJhc2UgdHJhY2tpbmctdGlnaHQgY3Vyc29yLXBvaW50ZXJcIj5cbiAgICAgICAgICAgICAgICA8c3Bhbj57Y3VycmVudFVzZXI/LnVzZXJuYW1lIHx8ICdsaWJyZV9zdHlsZV8yMDI2J308L3NwYW4+XG4gICAgICAgICAgICAgICAgPENoZXZyb25Eb3duIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1ncmF5LTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0yIGgtMiByb3VuZGVkLWZ1bGwgYmctcmVkLTUwMCBtbC0xXCI+PC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNVwiPlxuICAgICAgICAgICAgICAgIDxQbHVzIG9uQ2xpY2s9eygpID0+IHNldFNob3dDcmVhdGVCb3goIXNob3dDcmVhdGVCb3gpfSBjbGFzc05hbWU9e2B3LTYgaC02IGN1cnNvci1wb2ludGVyIHRyYW5zaXRpb24tY29sb3JzICR7c2hvd0NyZWF0ZUJveCA/ICd0ZXh0LWJsdWUtNDAwJyA6ICd0ZXh0LXdoaXRlJ31gfSAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogUHJvZmlsZSBUYWJzIE5hdmlnYXRpb246IFBpY3MgJiBWaWRlb3MgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggYm9yZGVyLXQgYm9yZGVyLWdyYXktODAwIHRleHQtZ3JheS00MDBcIj5cbiAgICAgICAgICAgICAgPGJ1dHRvbiBcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVQcm9maWxlVGFiKCdwaWNzJyl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleC0xIHB5LTMgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgZm9udC1ib2xkIHRleHQteHMgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIGN1cnNvci1wb2ludGVyIHRyYW5zaXRpb24tY29sb3JzICR7YWN0aXZlUHJvZmlsZVRhYiA9PT0gJ3BpY3MnID8gJ2JvcmRlci10LTIgYm9yZGVyLXdoaXRlIHRleHQtd2hpdGUgYmctd2hpdGUvNScgOiAnaG92ZXI6dGV4dC13aGl0ZSd9YH1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxzcGFuPlBpY3M8L3NwYW4+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8YnV0dG9uIFxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVByb2ZpbGVUYWIoJ3ZpZGVvcycpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXgtMSBweS0zIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIGZvbnQtYm9sZCB0ZXh0LXhzIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBjdXJzb3ItcG9pbnRlciB0cmFuc2l0aW9uLWNvbG9ycyAke2FjdGl2ZVByb2ZpbGVUYWIgPT09ICd2aWRlb3MnID8gJ2JvcmRlci10LTIgYm9yZGVyLXdoaXRlIHRleHQtd2hpdGUgYmctd2hpdGUvNScgOiAnaG92ZXI6dGV4dC13aGl0ZSd9YH1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxzcGFuPlZpZGVvczwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIFBvc3RzIC8gQWxidW1zIEZlZWQgVmlldyAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02IG1heC13LWxnIG14LWF1dG8gcGItMjBcIj5cbiAgICAgICAgICAgICAge2FsYnVtcy5maWx0ZXIoKGEsIGluZGV4KSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgaXNWaWRlbyA9IGEuaW1hZ2VVcmw/LmVuZHNXaXRoKCcubXA0JykgfHwgYS5pbWFnZVVybD8uaW5jbHVkZXMoJ3ZpZGVvJykgfHwgYS5pbWFnZVVybD8uaW5jbHVkZXMoJ3dlYm0nKSB8fCBpbmRleCAlIDMgPT09IDE7XG4gICAgICAgICAgICAgICAgaWYgKGFjdGl2ZVByb2ZpbGVUYWIgPT09ICdwaWNzJykgcmV0dXJuICFpc1ZpZGVvO1xuICAgICAgICAgICAgICAgIHJldHVybiBpc1ZpZGVvO1xuICAgICAgICAgICAgICB9KS5tYXAoKGEsIGluZGV4KSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgaXNMaWtlZCA9IGFsYnVtTGlrZWRbYS5pZF07XG4gICAgICAgICAgICAgICAgY29uc3QgbGlrZXNDb3VudCA9IChhLmxpa2VzIHx8IDEyKSArIChpc0xpa2VkID8gMSA6IDApO1xuICAgICAgICAgICAgICAgIGNvbnN0IGNvbW1lbnRzTGlzdCA9IGFsYnVtQ29tbWVudHNbYS5pZF0gfHwgYS5jb21tZW50cyB8fCBbXG4gICAgICAgICAgICAgICAgICB7IGlkOiAnMScsIGF1dGhvcjogJ2xpYnJlX3N0eWxlX2ZhbicsIHRleHQ6ICdBbWF6aW5nIHF1YWxpdHkgYW5kIGRlc2lnbiEg8J+UpScsIHRpbWU6ICcyaCcgfSxcbiAgICAgICAgICAgICAgICAgIHsgaWQ6ICcyJywgYXV0aG9yOiAnZmFzaGlvbl9odWInLCB0ZXh0OiAnTG92ZWQgdGhpcyBjb2xsZWN0aW9uLicsIHRpbWU6ICcxaCcgfVxuICAgICAgICAgICAgICAgIF07XG4gICAgICAgICAgICAgICAgY29uc3QgaXNWaWRlbyA9IGEuaW1hZ2VVcmw/LmVuZHNXaXRoKCcubXA0JykgfHwgYS5pbWFnZVVybD8uaW5jbHVkZXMoJ3ZpZGVvJykgfHwgYS5pbWFnZVVybD8uaW5jbHVkZXMoJ3dlYm0nKSB8fCBpbmRleCAlIDMgPT09IDE7XG5cbiAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2EuaWR9IGNsYXNzTmFtZT1cImJnLVsjMTIxMjEyXSBib3JkZXIgYm9yZGVyLWdyYXktODAwIHJvdW5kZWQtMnhsIG92ZXJmbG93LWhpZGRlbiBzaGFkb3cteGxcIj5cbiAgICAgICAgICAgICAgICAgICAgey8qIFBvc3QgSGVhZGVyICovfVxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwLTMgYm9yZGVyLWIgYm9yZGVyLWdyYXktODAwLzYwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctOCBoLTggcm91bmRlZC1mdWxsIGJnLWdyYWRpZW50LXRvLXRyIGZyb20teWVsbG93LTQwMCB0by1waW5rLTUwMCBwLVsxLjVweF1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgaC1mdWxsIHJvdW5kZWQtZnVsbCBiZy1ncmF5LTkwMCBvdmVyZmxvdy1oaWRkZW4gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZm9udC1ib2xkIHRleHQteHMgdGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0aGVtZUNvbmZpZy5sb2dvVXJsID8gPGltZyBzcmM9e3RoZW1lQ29uZmlnLmxvZ29Vcmx9IGNsYXNzTmFtZT1cInctZnVsbCBoLWZ1bGwgb2JqZWN0LWNvdmVyXCIgLz4gOiAnTFMnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2EuYXV0aG9yTmFtZSB8fCBjdXJyZW50VXNlcj8udXNlcm5hbWUgfHwgJ2xpYnJlX3N0eWxlXzIwMjYnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtYmx1ZS00MDAgdGV4dC1bMTBweF1cIj7inJM8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtZ3JheS00MDBcIj57YS50aW1lc3RhbXAgfHwgJzIgaG91cnMgYWdvJ308L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBbGJ1bVBpbm5lZChwcmV2ID0+ICh7IC4uLnByZXYsIFthLmlkXTogIShhbGJ1bVBpbm5lZFthLmlkXSA/PyAoaW5kZXggPT09IDApKSB9KSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSB0ZXh0LXhzIHB4LTIuNSBweS0xIHJvdW5kZWQtZnVsbCBib3JkZXIgdHJhbnNpdGlvbi1jb2xvcnMgJHthbGJ1bVBpbm5lZFthLmlkXSA/PyAoaW5kZXggPT09IDApID8gJ2JnLWJsdWUtNjAwLzIwIGJvcmRlci1ibHVlLTUwMCB0ZXh0LWJsdWUtNDAwJyA6ICdiZy1ncmF5LTgwMCBib3JkZXItZ3JheS03MDAgdGV4dC1ncmF5LTMwMCBob3Zlcjp0ZXh0LXdoaXRlJ31gfVxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPvCfk4w8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LXNlbWlib2xkXCI+e2FsYnVtUGlubmVkW2EuaWRdID8/IChpbmRleCA9PT0gMCkgPyAnUGlubmVkJyA6ICdQaW4nfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgey8qIFBvc3QgTWVkaWEgKFBpYyBvciBTbWFsbCBWaWRlbykgKi99XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy1mdWxsIGJnLWJsYWNrIGFzcGVjdC1zcXVhcmUgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICAgICAgICAgICAgICAgICAge2lzVmlkZW8gPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8dmlkZW8gc3JjPXthLmltYWdlVXJsfSBjb250cm9scyBjbGFzc05hbWU9XCJ3LWZ1bGwgaC1mdWxsIG9iamVjdC1jb3ZlclwiIGF1dG9QbGF5IG11dGVkIGxvb3AgLz5cbiAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGltZyBzcmM9e2EuaW1hZ2VVcmx9IGFsdD17YS50aXRsZX0gY2xhc3NOYW1lPVwidy1mdWxsIGgtZnVsbCBvYmplY3QtY292ZXJcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgeyhhbGJ1bVBpbm5lZFthLmlkXSA/PyAoaW5kZXggPT09IDApKSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC0zIHJpZ2h0LTMgYmctYmxhY2svNjAgdGV4dC13aGl0ZSB0ZXh0LVsxMHB4XSBweC0yLjUgcHktMSByb3VuZGVkLWZ1bGwgYmFja2Ryb3AtYmx1ci1zbSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj7wn5OMPC9zcGFuPiBQaW5uZWQgUG9zdFxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgey8qIEFjdGlvbiBCYXIgKExpa2UsIENvbW1lbnQsIFRhZywgU2hhcmUpIGF0IHRoZSBib3R0b20gb2YgdGhlIHBvc3QgKi99XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zLjUgc3BhY2UteS0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIExpa2UgQnV0dG9uIHdpdGggUHJlc3MgJiBIb2xkIGZvciBSZWFjdGlvbnMgKD4gMiBzZWNvbmRzKSAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtyZWFjdGlvblBvcHVwUG9zdElkID09PSBhLmlkICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgLXRvcC0xNiBsZWZ0LTAgYmctWyMxZTFlMWVdIGJvcmRlciBib3JkZXItZ3JheS03MDAgc2hhZG93LTJ4bCByb3VuZGVkLTJ4bCBwLTIgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB6LTMwIGFuaW1hdGUtaW4gZmFkZS1pbiB6b29tLWluXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtbXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBsYWJlbDogJ0xvdmUnLCBpY29uOiAn4p2k77iPJyB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgbGFiZWw6ICdMaWtlJywgaWNvbjogJ/CfkY0nIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBsYWJlbDogJ0hhaGEnLCBpY29uOiAn8J+YgicgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGxhYmVsOiAnV293JywgaWNvbjogJ/CfmK4nIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBsYWJlbDogJ0ZpcmUnLCBpY29uOiAn8J+UpScgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGxhYmVsOiAnUGFydHknLCBpY29uOiAn8J+OiScgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBdLm1hcChpdGVtID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2l0ZW0ubGFiZWx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRBbGJ1bVJlYWN0aW9ucyhwcmV2ID0+ICh7IC4uLnByZXYsIFthLmlkXTogaXRlbS5pY29uIH0pKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0QWxidW1MaWtlZChwcmV2ID0+ICh7IC4uLnByZXYsIFthLmlkXTogdHJ1ZSB9KSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFJlYWN0aW9uUG9wdXBQb3N0SWQobnVsbCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIgZ2FwLTAuNSBweC0yLjUgcHktMS41IHJvdW5kZWQteGwgaG92ZXI6YmctZ3JheS04MDAgdGV4dC13aGl0ZSB0cmFuc2l0aW9uLWFsbCBob3ZlcjpzY2FsZS0xMTBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9e2l0ZW0ubGFiZWx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1sZ1wiPntpdGVtLmljb259PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktMzAwXCI+e2l0ZW0ubGFiZWx9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uTW91c2VEb3duPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxpa2VUaW1lcnNSZWYuY3VycmVudFthLmlkXSA9IHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFJlYWN0aW9uUG9wdXBQb3N0SWQoYS5pZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sIDIwMDApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uTW91c2VVcD17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAobGlrZVRpbWVyc1JlZi5jdXJyZW50W2EuaWRdKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xlYXJUaW1lb3V0KGxpa2VUaW1lcnNSZWYuY3VycmVudFthLmlkXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGlrZVRpbWVyc1JlZi5jdXJyZW50W2EuaWRdID0gbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uTW91c2VMZWF2ZT17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAobGlrZVRpbWVyc1JlZi5jdXJyZW50W2EuaWRdKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xlYXJUaW1lb3V0KGxpa2VUaW1lcnNSZWYuY3VycmVudFthLmlkXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGlrZVRpbWVyc1JlZi5jdXJyZW50W2EuaWRdID0gbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uVG91Y2hTdGFydD17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsaWtlVGltZXJzUmVmLmN1cnJlbnRbYS5pZF0gPSBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRSZWFjdGlvblBvcHVwUG9zdElkKGEuaWQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LCAyMDAwKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvblRvdWNoRW5kPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChsaWtlVGltZXJzUmVmLmN1cnJlbnRbYS5pZF0pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGVhclRpbWVvdXQobGlrZVRpbWVyc1JlZi5jdXJyZW50W2EuaWRdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsaWtlVGltZXJzUmVmLmN1cnJlbnRbYS5pZF0gPSBudWxsO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVhY3Rpb25Qb3B1cFBvc3RJZCA9PT0gYS5pZCkgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRBbGJ1bUxpa2VkKHByZXYgPT4gKHsgLi4ucHJldiwgW2EuaWRdOiAhcHJldlthLmlkXSB9KSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9jdXM6b3V0bGluZS1ub25lIHRyYW5zaXRpb24tdHJhbnNmb3JtIGFjdGl2ZTpzY2FsZS0xMjUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJQcmVzcyAmIGhvbGQgZm9yIDIgc2Vjb25kcyBmb3IgcmVhY3Rpb25zXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SGVhcnQgY2xhc3NOYW1lPXtgdy02IGgtNiAke2lzTGlrZWQgPyAndGV4dC1yZWQtNTAwIGZpbGwtcmVkLTUwMCcgOiAndGV4dC13aGl0ZSBob3Zlcjp0ZXh0LWdyYXktMzAwJ31gfSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2FsYnVtUmVhY3Rpb25zW2EuaWRdICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBiZy1ncmF5LTgwMCB0ZXh0LXdoaXRlIHB4LTEuNSBweS0wLjUgcm91bmRlZC1mdWxsIGJvcmRlciBib3JkZXItZ3JheS03MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YWxidW1SZWFjdGlvbnNbYS5pZF19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBDb21tZW50IEJ1dHRvbiAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJmb2N1czpvdXRsaW5lLW5vbmUgaG92ZXI6dGV4dC1ncmF5LTMwMCB0ZXh0LXdoaXRlXCIgdGl0bGU9XCJDb21tZW50XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPE1lc3NhZ2VDaXJjbGUgY2xhc3NOYW1lPVwidy02IGgtNlwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICB7LyogTGlrZXMgQ291bnQgKi99XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7bGlrZXNDb3VudH0gbGlrZXNcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBDYXB0aW9uICovfVxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Ryb25nIGNsYXNzTmFtZT1cInRleHQtd2hpdGUgbXItMS41XCI+e2EuYXV0aG9yTmFtZSB8fCAnbGlicmVfc3R5bGVfMjAyNid9PC9zdHJvbmc+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtd2hpdGUgbXItMVwiPnthLnRpdGxlfTo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICB7YS5jYXB0aW9ufVxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgey8qIENvbW1lbnRzIExpc3QgKi99XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEgcHQtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LWdyYXktNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIFZpZXcgYWxsIHtjb21tZW50c0xpc3QubGVuZ3RofSBjb21tZW50c1xuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICB7Y29tbWVudHNMaXN0Lm1hcCgoYzogYW55KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtjLmlkfSBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Ryb25nIGNsYXNzTmFtZT1cInRleHQtd2hpdGUgbXItMS41XCI+QHtjLmF1dGhvcn08L3N0cm9uZz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57Yy50ZXh0fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBBZGQgQ29tbWVudCBJbnB1dCAqL31cbiAgICAgICAgICAgICAgICAgICAgICA8Zm9ybSBcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uU3VibWl0PXtlID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB0ZXh0ID0gY29tbWVudElucHV0VGV4dFthLmlkXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCF0ZXh0IHx8ICF0ZXh0LnRyaW0oKSkgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBuZXdDb21tZW50ID0geyBpZDogRGF0ZS5ub3coKS50b1N0cmluZygpLCBhdXRob3I6IGN1cnJlbnRVc2VyPy51c2VybmFtZSB8fCAndXNlcicsIHRleHQ6IHRleHQudHJpbSgpLCB0aW1lOiAnSnVzdCBub3cnIH07XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNldEFsYnVtQ29tbWVudHMocHJldiA9PiAoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnByZXYsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgW2EuaWRdOiBbLi4uKHByZXZbYS5pZF0gfHwgYS5jb21tZW50cyB8fCBbXSksIG5ld0NvbW1lbnRdXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH0pKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0Q29tbWVudElucHV0VGV4dChwcmV2ID0+ICh7IC4uLnByZXYsIFthLmlkXTogJycgfSkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB0LTIgYm9yZGVyLXQgYm9yZGVyLWdyYXktODAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCJcbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2NvbW1lbnRJbnB1dFRleHRbYS5pZF0gfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldENvbW1lbnRJbnB1dFRleHQocHJldiA9PiAoeyAuLi5wcmV2LCBbYS5pZF06IGUudGFyZ2V0LnZhbHVlIH0pKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJBZGQgYSBjb21tZW50Li4uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIGJnLXRyYW5zcGFyZW50IHRleHQteHMgdGV4dC13aGl0ZSBwbGFjZWhvbGRlci1ncmF5LTUwMCBmb2N1czpvdXRsaW5lLW5vbmVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiIGRpc2FibGVkPXshY29tbWVudElucHV0VGV4dFthLmlkXT8udHJpbSgpfSBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWJsdWUtNTAwIGhvdmVyOnRleHQtYmx1ZS00MDAgZGlzYWJsZWQ6b3BhY2l0eS00MFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICBQb3N0XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgfSl9XG5cbiAgICAgICAgICAgICAgey8qIERlZmF1bHQgcGxhY2Vob2xkZXIgcG9zdCBpZiBhbGJ1bXMgaXMgZW1wdHkgKi99XG4gICAgICAgICAgICAgIHthbGJ1bXMubGVuZ3RoID09PSAwICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLVsjMTIxMjEyXSBib3JkZXIgYm9yZGVyLWdyYXktODAwIHJvdW5kZWQtMnhsIHAtOCB0ZXh0LWNlbnRlciB0ZXh0LWdyYXktNDAwIHNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkXCI+Tm8gcG9zdHMgeWV0LjwvcD5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMFwiPkNyZWF0ZSBhIG5ldyBhbGJ1bSBvciBwb3N0IHVzaW5nIHRoZSBmb3JtIGFib3ZlITwvcD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuXG4gICAgICAgIHsvKiBUQUIgMzogRFJJVkUgKEdvb2dsZSBEcml2ZSBTdG9yYWdlICYgQ29uY2VybiBGb2xkZXIgU2hvcnRjdXRzOiBJbWFnZXMsIEZpbGVzLCBWaWRlb3MsIENoYXQgYmFja3VwLCBBbmQgbW9yZSkgKi99XG4gICAgICAgIHthY3RpdmVUYWIgPT09ICdkcml2ZScgJiYgKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS04IG1heC13LTR4bFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtWyMyZDM3NDhdXCI+R29vZ2xlIERyaXZlIEJhY2t1cCAmIFN0b3JhZ2U8L2gyPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1bIzcxODA5Nl1cIj5NYW5hZ2Ugc3luY2VkIGNsb3VkIGJhY2t1cCBmb2xkZXJzIGFuZCBmaWxlIGNhdGVnb3JpZXMuPC9wPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGJ1dHRvbiBcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVUYWIoJ2hvbWUnKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgYmctWyM5M2I1YzZdIHRleHQtd2hpdGUgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGRcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgSG9tZVxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogU3RvcmFnZSBCYXIgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGJvcmRlciBib3JkZXItWyNlNWUwZDhdIHJvdW5kZWQtMnhsIHAtNiBzcGFjZS15LTQgc2hhZG93LXNtXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LVsjNGE1NTY4XVwiPlxuICAgICAgICAgICAgICAgIDxzcGFuPlN0b3JhZ2UgVXNlZDoge2RyaXZlU3RvcmFnZVVzZWR9IEdCIG9mIHtkcml2ZVN0b3JhZ2VUb3RhbH0gR0I8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4+QWN0aXZlIFN5bmM8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBoLTMgYmctWyNmMGVkZTZdIHJvdW5kZWQtZnVsbCBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtZnVsbCBiZy1bIzkzYjVjNl1cIiBzdHlsZT17eyB3aWR0aDogYCR7KGRyaXZlU3RvcmFnZVVzZWQgLyBkcml2ZVN0b3JhZ2VUb3RhbCkgKiAxMDB9JWAgfX0+PC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBDb25jZXJuIEZvbGRlcnMgU2hvcnRjdXRzIChJbWFnZXMsIEZpbGVzLCBWaWRlb3MsIENoYXQgYmFja3VwLCBBbmQgbW9yZSkgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1bIzJkMzc0OF0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+Q29uY2VybiBGb2xkZXJzPC9oMz5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIG1kOmdyaWQtY29scy01IGdhcC00XCI+XG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkRm9sZGVyRmlsdGVyKHNlbGVjdGVkRm9sZGVyRmlsdGVyID09PSAnSW1hZ2UnID8gbnVsbCA6ICdJbWFnZScpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctd2hpdGUgYm9yZGVyIHAtNCByb3VuZGVkLTJ4bCB0ZXh0LWxlZnQgdHJhbnNpdGlvbi1hbGwgc2hhZG93LXNtIHNwYWNlLXktMiAke3NlbGVjdGVkRm9sZGVyRmlsdGVyID09PSAnSW1hZ2UnID8gJ2JvcmRlci1bIzkzYjVjNl0gYmctWyM5M2I1YzZdLzEwIGZvbnQtc2VtaWJvbGQnIDogJ2JvcmRlci1bI2U1ZTBkOF0gaG92ZXI6Ym9yZGVyLVsjOTNiNWM2XSd9YH1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTAgaC0xMCByb3VuZGVkLXhsIGJnLVsjOTNiNWM2XS8yMCB0ZXh0LVsjOTNiNWM2XSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICA8SW1hZ2VJY29uIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1bIzJkMzc0OF1cIj5JbWFnZXM8L2g0PlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1bIzcxODA5Nl1cIj5QaG90b3MgJiBNZWRpYTwvcD5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTZWxlY3RlZEZvbGRlckZpbHRlcihzZWxlY3RlZEZvbGRlckZpbHRlciA9PT0gJ0ZpbGUnID8gbnVsbCA6ICdGaWxlJyl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy13aGl0ZSBib3JkZXIgcC00IHJvdW5kZWQtMnhsIHRleHQtbGVmdCB0cmFuc2l0aW9uLWFsbCBzaGFkb3ctc20gc3BhY2UteS0yICR7c2VsZWN0ZWRGb2xkZXJGaWx0ZXIgPT09ICdGaWxlJyA/ICdib3JkZXItWyM5M2I1YzZdIGJnLVsjOTNiNWM2XS8xMCBmb250LXNlbWlib2xkJyA6ICdib3JkZXItWyNlNWUwZDhdIGhvdmVyOmJvcmRlci1bIzkzYjVjNl0nfWB9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgcm91bmRlZC14bCBiZy1bI2EzYzFhZF0vMjAgdGV4dC1bIzZiOGUyM10gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgPEZpbGVUZXh0IGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1bIzJkMzc0OF1cIj5GaWxlczwvaDQ+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LVsjNzE4MDk2XVwiPkRvY3MgJiBUcmFuc2NyaXB0czwvcD5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTZWxlY3RlZEZvbGRlckZpbHRlcihzZWxlY3RlZEZvbGRlckZpbHRlciA9PT0gJ1ZpZGVvJyA/IG51bGwgOiAnVmlkZW8nKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLXdoaXRlIGJvcmRlciBwLTQgcm91bmRlZC0yeGwgdGV4dC1sZWZ0IHRyYW5zaXRpb24tYWxsIHNoYWRvdy1zbSBzcGFjZS15LTIgJHtzZWxlY3RlZEZvbGRlckZpbHRlciA9PT0gJ1ZpZGVvJyA/ICdib3JkZXItWyM5M2I1YzZdIGJnLVsjOTNiNWM2XS8xMCBmb250LXNlbWlib2xkJyA6ICdib3JkZXItWyNlNWUwZDhdIGhvdmVyOmJvcmRlci1bIzkzYjVjNl0nfWB9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgcm91bmRlZC14bCBiZy1bI2I5MWMxY10vMjAgdGV4dC1bI2I5MWMxY10gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgPEZpbG0gY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LVsjMmQzNzQ4XVwiPlZpZGVvczwvaDQ+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LVsjNzE4MDk2XVwiPlJlY29yZGluZ3MgJiBjbGlwczwvcD5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTZWxlY3RlZEZvbGRlckZpbHRlcihzZWxlY3RlZEZvbGRlckZpbHRlciA9PT0gJ0JhY2t1cCcgPyBudWxsIDogJ0JhY2t1cCcpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctd2hpdGUgYm9yZGVyIHAtNCByb3VuZGVkLTJ4bCB0ZXh0LWxlZnQgdHJhbnNpdGlvbi1hbGwgc2hhZG93LXNtIHNwYWNlLXktMiAke3NlbGVjdGVkRm9sZGVyRmlsdGVyID09PSAnQmFja3VwJyA/ICdib3JkZXItWyM5M2I1YzZdIGJnLVsjOTNiNWM2XS8xMCBmb250LXNlbWlib2xkJyA6ICdib3JkZXItWyNlNWUwZDhdIGhvdmVyOmJvcmRlci1bIzkzYjVjNl0nfWB9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgcm91bmRlZC14bCBiZy1bIzcxODA5Nl0vMjAgdGV4dC1bIzRhNTU2OF0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgPE1lc3NhZ2VTcXVhcmVDb2RlIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1bIzJkMzc0OF1cIj5DaGF0IGJhY2t1cDwvaDQ+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LVsjNzE4MDk2XVwiPkpTT04gQXJjaGl2ZXM8L3A+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIFxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2VsZWN0ZWRGb2xkZXJGaWx0ZXIoc2VsZWN0ZWRGb2xkZXJGaWx0ZXIgPT09ICdBdWRpbycgPyBudWxsIDogJ0F1ZGlvJyl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy13aGl0ZSBib3JkZXIgcC00IHJvdW5kZWQtMnhsIHRleHQtbGVmdCB0cmFuc2l0aW9uLWFsbCBzaGFkb3ctc20gc3BhY2UteS0yICR7c2VsZWN0ZWRGb2xkZXJGaWx0ZXIgPT09ICdBdWRpbycgPyAnYm9yZGVyLVsjOTNiNWM2XSBiZy1bIzkzYjVjNl0vMTAgZm9udC1zZW1pYm9sZCcgOiAnYm9yZGVyLVsjZTVlMGQ4XSBob3Zlcjpib3JkZXItWyM5M2I1YzZdJ31gfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMCBoLTEwIHJvdW5kZWQteGwgYmctWyNlMjg3NDNdLzIwIHRleHQtWyNlMjg3NDNdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgIDxNaWMgY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LVsjMmQzNzQ4XVwiPkFuZCBtb3JlPC9oND5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtWyM3MTgwOTZdXCI+QXVkaW8gJiBDYWNoZTwvcD5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIERyaXZlIEZpbGVzIExpc3QgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGJvcmRlciBib3JkZXItWyNlNWUwZDhdIHJvdW5kZWQtMnhsIG92ZXJmbG93LWhpZGRlbiBzaGFkb3ctc20gZGl2aWRlLXkgZGl2aWRlLVsjZTVlMGQ4XVwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTUgcHktMy41IGJnLVsjZmRmYmY3XSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1bIzcxODA5Nl0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgIDxzcGFuPkNsb3VkIEZpbGVzIHtzZWxlY3RlZEZvbGRlckZpbHRlciA/IGAoJHtzZWxlY3RlZEZvbGRlckZpbHRlcn0gRm9sZGVyKWAgOiAnJ308L3NwYW4+XG4gICAgICAgICAgICAgICAge3NlbGVjdGVkRm9sZGVyRmlsdGVyICYmIChcbiAgICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gc2V0U2VsZWN0ZWRGb2xkZXJGaWx0ZXIobnVsbCl9IGNsYXNzTmFtZT1cInRleHQtWyM5M2I1YzZdIGhvdmVyOnVuZGVybGluZSB0ZXh0LVsxMXB4XSBmb250LW1lZGl1bVwiPkNsZWFyIEZpbHRlcjwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHtkcml2ZUZpbGVzXG4gICAgICAgICAgICAgICAgLmZpbHRlcihmID0+ICFzZWxlY3RlZEZvbGRlckZpbHRlciB8fCBmLnR5cGUgPT09IHNlbGVjdGVkRm9sZGVyRmlsdGVyKVxuICAgICAgICAgICAgICAgIC5tYXAoZmlsZSA9PiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IGtleT17ZmlsZS5pZH0gY2xhc3NOYW1lPVwicC00IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBob3ZlcjpiZy1bI2ZkZmJmN10gdHJhbnNpdGlvbi1jb2xvcnNcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMCBoLTEwIHJvdW5kZWQteGwgYmctWyNmMGVkZTZdIHRleHQtWyM0YTU1NjhdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8Rm9sZGVyIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1bIzkzYjVjNl1cIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1bIzJkMzc0OF1cIj57ZmlsZS5uYW1lfTwvaDQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtWyM3MTgwOTZdXCI+e2ZpbGUuc2l6ZX0gwrcge2ZpbGUuY3JlYXRlZFRpbWV9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gYmctWyM5M2I1YzZdLzIwIHRleHQtWyMyZDM3NDhdIHB4LTIuNSBweS0xIHJvdW5kZWQtZnVsbCBmb250LW1vbm9cIj57ZmlsZS50eXBlfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIFxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlRGVsZXRlRHJpdmVGaWxlKGZpbGUuaWQsIGZpbGUuc2l6ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTIgdGV4dC1yZWQtNTAwIGhvdmVyOmJnLXJlZC01MCByb3VuZGVkLXhsIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiRGVsZXRlIEZpbGVcIlxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxUcmFzaDIgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG5cbiAgICAgICAgey8qIFRBQiA0OiBBRE1JTiBTVUlURSAqL31cbiAgICAgICAge2FjdGl2ZVRhYiA9PT0gJ2FkbWluJyAmJiAoY3VycmVudFVzZXIuaXNBZG1pbiB8fCBjdXJyZW50VXNlci5pc01hc3RlckFkbWluKSAmJiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LThcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LVsjMmQzNzQ4XVwiPk1hc3RlciBBZG1pbiBTdWl0ZTwvaDI+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LVsjNzE4MDk2XVwiPkZ1bGwgd2hpdGUtbGFiZWwgYnJhbmRpbmcgY29udHJvbHMgYW5kIHVzZXIgcGVybWlzc2lvbiBtYW5hZ2VtZW50LjwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlVGFiKCdob21lJyl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIGJnLVsjOTNiNWM2XSB0ZXh0LXdoaXRlIHJvdW5kZWQteGwgdGV4dC14cyBmb250LXNlbWlib2xkXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIEhvbWVcbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIEJyYW5kaW5nICYgV2hpdGUtTGFiZWwgQ29udHJvbHMgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGJvcmRlciBib3JkZXItWyNlNWUwZDhdIHJvdW5kZWQtM3hsIHAtNiBzcGFjZS15LTYgc2hhZG93LXNtXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTQgcGItNCBib3JkZXItYiBib3JkZXItWyNlNWUwZDhdXCI+XG4gICAgICAgICAgICAgICAgPE5DTG9nbyBzaXplPVwibGdcIiBsb2dvVXJsPXt0aGVtZUNvbmZpZy5sb2dvVXJsfSAvPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1bIzJkMzc0OF1cIj5BcHAgTG9nbyBQcmV2aWV3PC9oND5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1bIzcxODA5Nl1cIj5VcGxvYWQgeW91ciBjdXN0b20gbG9nbyBiZWxvdyB0byB1cGRhdGUgdGhpcyBwcmV2aWV3IGFuZCBicmFuZGluZyBhY3Jvc3MgdGhlIGFwcC48L3A+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtWyM0YTU1NjhdXCI+QXBwIE5hbWU8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGlucHV0IFxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt0aGVtZUNvbmZpZy50aGVtZU5hbWV9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldFRoZW1lQ29uZmlnKHsgLi4udGhlbWVDb25maWcsIHRoZW1lTmFtZTogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1bI2ZkZmJmN10gYm9yZGVyIGJvcmRlci1bI2U1ZTBkOF0gcm91bmRlZC14bCBweC00IHB5LTIuNSB0ZXh0LXNtIHRleHQtWyMyZDM3NDhdXCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMS41XCI+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LVsjNGE1NTY4XVwiPlNsb2dhbiAvIFN1YnRpdGxlPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dCBcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dGhlbWVDb25maWcuc2xvZ2FufVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRUaGVtZUNvbmZpZyh7IC4uLnRoZW1lQ29uZmlnLCBzbG9nYW46IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctWyNmZGZiZjddIGJvcmRlciBib3JkZXItWyNlNWUwZDhdIHJvdW5kZWQteGwgcHgtNCBweS0yLjUgdGV4dC1zbSB0ZXh0LVsjMmQzNzQ4XVwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1bIzRhNTU2OF1cIj5Qb3dlcmVkIEJ5IFRleHQ8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGlucHV0IFxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt0aGVtZUNvbmZpZy5wb3dlcmVkQnl9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldFRoZW1lQ29uZmlnKHsgLi4udGhlbWVDb25maWcsIHBvd2VyZWRCeTogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1bI2ZkZmJmN10gYm9yZGVyIGJvcmRlci1bI2U1ZTBkOF0gcm91bmRlZC14bCBweC00IHB5LTIuNSB0ZXh0LXNtIHRleHQtWyMyZDM3NDhdXCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMS41XCI+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LVsjNGE1NTY4XVwiPkxvZ288L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBiZy1bI2ZkZmJmN10gYm9yZGVyIGJvcmRlci1bI2U1ZTBkOF0gcm91bmRlZC14bCBweC00IHB5LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LVsjNzE4MDk2XSB0cnVuY2F0ZSBmbGV4LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7bG9nb0ZpbGVOYW1lIHx8ICh0aGVtZUNvbmZpZy5sb2dvVXJsID8gJ0xvZ28gdXBsb2FkZWQgc3VjY2Vzc2Z1bGx5JyA6ICdObyBsb2dvIGNob3NlbicpfVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJweC00IHB5LTIgYmctWyM5M2I1YzZdIGhvdmVyOmJnLVsjN2ZhNWI4XSB0ZXh0LXdoaXRlIHJvdW5kZWQtbGcgdGV4dC14cyBmb250LXNlbWlib2xkIGN1cnNvci1wb2ludGVyIHNoYWRvdy1zbSB0cmFuc2l0aW9uLWNvbG9ycyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBzaHJpbmstMCBzZWxlY3Qtbm9uZVwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxVcGxvYWRJY29uIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIFVwbG9hZCBMb2dvXG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0IFxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImZpbGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXB0PVwiaW1hZ2UvKlwiXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGZpbGUgPSBlLnRhcmdldC5maWxlcz8uWzBdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZmlsZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldExvZ29GaWxlTmFtZShmaWxlLm5hbWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHJlYWRlciA9IG5ldyBGaWxlUmVhZGVyKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVhZGVyLm9ubG9hZGVuZCA9ICgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFRoZW1lQ29uZmlnKHsgLi4udGhlbWVDb25maWcsIGxvZ29Vcmw6IHJlYWRlci5yZXN1bHQgYXMgc3RyaW5nIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVhZGVyLnJlYWRBc0RhdGFVUkwoZmlsZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoaWRkZW5cIlxuICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtWyM0YTU1NjhdXCI+QWJvdXQgVXMgVGV4dDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPHRleHRhcmVhIFxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3RoZW1lQ29uZmlnLmFib3V0VGV4dH1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldFRoZW1lQ29uZmlnKHsgLi4udGhlbWVDb25maWcsIGFib3V0VGV4dDogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgICByb3dzPXsyfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLVsjZmRmYmY3XSBib3JkZXIgYm9yZGVyLVsjZTVlMGQ4XSByb3VuZGVkLXhsIHB4LTQgcHktMi41IHRleHQtc20gdGV4dC1bIzJkMzc0OF1cIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1bIzRhNTU2OF1cIj5Db2xvciBUaGVtZSBBY2NlbnQ8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgIHtbJyM5M2I1YzYnLCAnIzZiOGUyMycsICcjYjkxYzFjJywgJyNlMjg3NDMnLCAnIzRmNDZlNScsICcjMmQzNzQ4J10ubWFwKGNvbG9yID0+IChcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIGtleT17Y29sb3J9XG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0VGhlbWVDb25maWcoeyAuLi50aGVtZUNvbmZpZywgcHJpbWFyeUNvbG9yOiBjb2xvciB9KX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B3LTggaC04IHJvdW5kZWQtZnVsbCBib3JkZXItMiB0cmFuc2l0aW9uLWFsbCAke3RoZW1lQ29uZmlnLnByaW1hcnlDb2xvciA9PT0gY29sb3IgPyAnYm9yZGVyLVsjMmQzNzQ4XSBzY2FsZS0xMTAgc2hhZG93LW1kJyA6ICdib3JkZXItdHJhbnNwYXJlbnQnfWB9XG4gICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiBjb2xvciB9fVxuICAgICAgICAgICAgICAgICAgICA+PC9idXR0b24+XG4gICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LVsjNGE1NTY4XVwiPlRoZW1lIE1vZGU8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMyBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgeyhbJ0xpZ2h0JywgJ0RhcmsnLCAnU3lzdGVtIGRlZmF1bHQnXSBhcyBjb25zdCkubWFwKG1vZGUgPT4gKFxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAga2V5PXttb2RlfVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFRoZW1lTW9kZShtb2RlKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC00IHB5LTIgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgYm9yZGVyIHRyYW5zaXRpb24tYWxsICR7dGhlbWVNb2RlID09PSBtb2RlID8gJ2JnLVsjOTNiNWM2XSB0ZXh0LXdoaXRlIGJvcmRlci1bIzkzYjVjNl0gc2hhZG93LXNtJyA6ICdiZy1bI2ZkZmJmN10gdGV4dC1bIzRhNTU2OF0gYm9yZGVyLVsjZTVlMGQ4XSBob3ZlcjpiZy1bI2Y1ZjJlYl0nfWB9XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICB7bW9kZX1cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC00IGJvcmRlci10IGJvcmRlci1bI2U1ZTBkOF0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIHthZG1pblNhdmVNc2cgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmVlbi02MDAgYmctZ3JlZW4tNTAgcHgtMyBweS0xLjUgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWdyZWVuLTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIHthZG1pblNhdmVNc2d9XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBzZXRBZG1pblNhdmVNc2coJ0FkbWluIHNldHRpbmdzIHNhdmVkIHN1Y2Nlc3NmdWxseSEnKTtcbiAgICAgICAgICAgICAgICAgICAgc2V0VGltZW91dCgoKSA9PiBzZXRBZG1pblNhdmVNc2coJycpLCAzMDAwKTtcbiAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC02IHB5LTIuNSBiZy1bIzkzYjVjNl0gaG92ZXI6YmctWyM3ZmE1YjhdIHRleHQtd2hpdGUgZm9udC1zZW1pYm9sZCByb3VuZGVkLXhsIHRleHQteHMgdHJhbnNpdGlvbi1jb2xvcnMgc2hhZG93LXNtIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8Q2hlY2sgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgICBTYXZlIENoYW5nZXNcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIFByb21vdGUgVXNlciB0byBBZG1pbiAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgYm9yZGVyIGJvcmRlci1bI2U1ZTBkOF0gcm91bmRlZC0zeGwgcC02IHNwYWNlLXktNCBzaGFkb3ctc21cIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtYm9sZCB0ZXh0LVsjMmQzNzQ4XSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgPFVzZXJDaGVjayBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtWyM5M2I1YzZdXCIgLz5cbiAgICAgICAgICAgICAgICAgIFVzZXIgQWNjZXNzICYgQWRtaW4gUHJvbW90aW9uXG4gICAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgICB7Y3VycmVudFVzZXIuaXNNYXN0ZXJBZG1pbiAmJiAoXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBiZy1yZWQtMTAwIHRleHQtcmVkLTcwMCBweC0zIHB5LTEgcm91bmRlZC1mdWxsIGZvbnQtYm9sZCBmb250LW1vbm9cIj5cbiAgICAgICAgICAgICAgICAgICAg8J+RkSBNYXN0ZXIgQWRtaW4gTGV2ZWwgQWNjZXNzXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtWyNlNWUwZDhdXCI+XG4gICAgICAgICAgICAgICAge2FkbWluVXNlcnMubWFwKHUgPT4gKFxuICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e3UuaWR9IGNsYXNzTmFtZT1cInB5LTMgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LVsjMmQzNzQ4XVwiPkB7dS51c2VybmFtZX0ge3UuaXNNYXN0ZXJBZG1pbiAmJiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBiZy1yZWQtMTAwIHRleHQtcmVkLTcwMCBweC0yIHB5LTAuNSByb3VuZGVkIGZvbnQtbW9ubyBtbC0xXCI+TUFTVEVSIEFETUlOPC9zcGFuPn08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1bIzcxODA5Nl1cIj57dS5lbWFpbH0gwrcge3UuZGV2aWNlfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgdGV4dC14cyBweC0yLjUgcHktMSByb3VuZGVkLWZ1bGwgZm9udC1zZW1pYm9sZCAke3UuaXNBZG1pbiA/ICdiZy1ncmVlbi0xMDAgdGV4dC1ncmVlbi04MDAnIDogJ2JnLWdyYXktMTAwIHRleHQtZ3JheS02MDAnfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAge3UuaXNBZG1pbiA/ICdBZG1pbicgOiAnU3RhbmRhcmQnfVxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICB7IXUuaXNNYXN0ZXJBZG1pbiAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVByb21vdGVVc2VyKHUuaWQpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMgcHktMS41IGJnLVsjOTNiNWM2XSBob3ZlcjpiZy1bIzdmYTViOF0gdGV4dC13aGl0ZSByb3VuZGVkLXhsIHRleHQteHMgZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dS5pc0FkbWluID8gJ0RlbW90ZScgOiAnUHJvbW90ZSd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICB7Y3VycmVudFVzZXIuaXNNYXN0ZXJBZG1pbiAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZURlbGV0ZVVzZXIodS5pZCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zIHB5LTEuNSBiZy1yZWQtNjAwIGhvdmVyOmJnLXJlZC03MDAgdGV4dC13aGl0ZSByb3VuZGVkLXhsIHRleHQteHMgZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIk1hc3RlciBBZG1pbiBPbmx5OiBQdXJnZSBVc2VyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQdXJnZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIE1hc3RlciBBZG1pbiBFeGNsdXNpdmUgU3lzdGVtIEJyb2FkY2FzdCAqL31cbiAgICAgICAgICAgIHtjdXJyZW50VXNlci5pc01hc3RlckFkbWluICYmIChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1bI2ZmZmFmMF0gYm9yZGVyIGJvcmRlci1bI2ZlZWJjOF0gcm91bmRlZC0zeGwgcC02IHNwYWNlLXktNCBzaGFkb3ctc21cIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICA8U2hpZWxkIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1bI2RkNmIyMF1cIiAvPlxuICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWJvbGQgdGV4dC1bIzljNDIyMV1cIj5NYXN0ZXIgQWRtaW4gRXhjbHVzaXZlOiBHbG9iYWwgU3lzdGVtIEJyb2FkY2FzdDwvaDM+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LVsjNzE4MDk2XVwiPkFzIE1hc3RlciBBZG1pbiwgeW91IGhhdmUgc3VwcmVtZSBhdXRob3JpdHkgdG8gYnJvYWRjYXN0IHVyZ2VudCBzeXN0ZW0td2lkZSBhbm5vdW5jZW1lbnRzIHRvIGFsbCBhY3RpdmUgY2hhdHMgYW5kIHVzZXJzIHNpbXVsdGFuZW91c2x5LjwvcD5cbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMiBwdC0xXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0IFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCIgXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJUeXBlIHVyZ2VudCBzeXN0ZW0gYnJvYWRjYXN0IGFubm91bmNlbWVudC4uLlwiXG4gICAgICAgICAgICAgICAgICAgICAgaWQ9XCJtYXN0ZXItYnJvYWRjYXN0LWlucHV0XCJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTEgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1bI2U1ZTBkOF0gcm91bmRlZC14bCBweC00IHB5LTIuNSB0ZXh0LXhzIHRleHQtWyMyZDM3NDhdXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGlucHV0ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ21hc3Rlci1icm9hZGNhc3QtaW5wdXQnKSBhcyBIVE1MSW5wdXRFbGVtZW50O1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFpbnB1dCB8fCAhaW5wdXQudmFsdWUudHJpbSgpKSByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBicm9hZGNhc3RUZXh0ID0gYPCfmqggTUFTVEVSIEFETUlOIEJST0FEQ0FTVDogJHtpbnB1dC52YWx1ZX1gO1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0TWVzc2FnZXMocHJldiA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHVwZGF0ZWQgPSB7IC4uLnByZXYgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgT2JqZWN0LmtleXModXBkYXRlZCkuZm9yRWFjaChjb250YWN0SWQgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZWRbY29udGFjdElkXSA9IFtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC4uLih1cGRhdGVkW2NvbnRhY3RJZF0gfHwgW10pLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZDogRGF0ZS5ub3coKS50b1N0cmluZygpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZW5kZXI6IGN1cnJlbnRVc2VyLnVzZXJuYW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250ZW50OiBicm9hZGNhc3RUZXh0LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9Mb2NhbGVUaW1lU3RyaW5nKFtdLCB7IGhvdXI6ICcyLWRpZ2l0JywgbWludXRlOiAnMi1kaWdpdCcgfSksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzQWRtaW5XYXJuaW5nOiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc0UyRUU6IHRydWVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHVwZGF0ZWQ7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEF1ZGl0TG9nKHByZXYgPT4gW1xuICAgICAgICAgICAgICAgICAgICAgICAgICB7IGlkOiBgbC0ke0RhdGUubm93KCl9YCwgYWN0aW9uOiBgR2xvYmFsIEJyb2FkY2FzdDogXCIke2lucHV0LnZhbHVlfVwiYCwgdXNlcjogY3VycmVudFVzZXIudXNlcm5hbWUsIHRpbWU6IG5ldyBEYXRlKCkudG9Mb2NhbGVUaW1lU3RyaW5nKFtdLCB7IGhvdXI6ICcyLWRpZ2l0JywgbWludXRlOiAnMi1kaWdpdCcgfSkgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4ucHJldlxuICAgICAgICAgICAgICAgICAgICAgICAgXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpbnB1dC52YWx1ZSA9ICcnO1xuICAgICAgICAgICAgICAgICAgICAgICAgYWxlcnQoJ0Jyb2FkY2FzdCBzdWNjZXNzZnVsbHkgc2VudCB0byBhbGwgYWN0aXZlIGNoYXRzIHdvcmtzcGFjZS13aWRlIScpO1xuICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNSBweS0yLjUgYmctWyNiOTFjMWNdIGhvdmVyOmJnLVsjYTExNjE2XSB0ZXh0LXdoaXRlIHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGQgdHJhbnNpdGlvbi1jb2xvcnMgc2hyaW5rLTAgc2hhZG93LXNtXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIEJyb2FkY2FzdCBOb3dcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuXG4gICAgICAgICAgICB7LyogU291cmNlIENvZGUgQXJjaGl2ZSBDdXN0b21pemVyICYgQ29tbWFuZCBQYW5lbCAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgYm9yZGVyIGJvcmRlci1bI2U1ZTBkOF0gcm91bmRlZC0zeGwgcC02IHNwYWNlLXktNSBzaGFkb3ctc21cIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gYm9yZGVyLWIgYm9yZGVyLVsjZTVlMGQ4XSBwYi00XCI+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1ib2xkIHRleHQtWyMyZDM3NDhdIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxGb2xkZXJBcmNoaXZlIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1bIzkzYjVjNl1cIiAvPlxuICAgICAgICAgICAgICAgICAgICBNYXN0ZXIgQWRtaW4gWklQIEFyY2hpdmUgQ29tbWFuZCAmIEN1c3RvbWl6ZXJcbiAgICAgICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtWyM3MTgwOTZdIG10LTAuNVwiPlRvZ2dsZSBmaWxlcyB0byBpbmNsdWRlIG9yIGV4Y2x1ZGUuIEFsbCAxNCBjb3JlIHByb2plY3QgZmlsZXMgYXJlIGluY2x1ZGVkIGJ5IGRlZmF1bHQuPC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0WmlwT3B0aW9ucyh7IHNlcnZlcjogdHJ1ZSwgYXBpSW5kZXg6IHRydWUsIGFwcDogdHJ1ZSwgcGFja2FnZUpzb246IHRydWUsIHBhY2thZ2VMb2NrSnNvbjogdHJ1ZSwgdHNjb25maWc6IHRydWUsIHZpdGVDb25maWc6IHRydWUsIHZlcmNlbEpzb246IHRydWUsIHJlZGlyZWN0czogdHJ1ZSwgaW5kZXhIdG1sOiB0cnVlLCBtZXRhZGF0YTogdHJ1ZSwgZmlyZWJhc2VDb25maWc6IHRydWUsIHJlYWRtZTogdHJ1ZSwgbWFpblRzeDogdHJ1ZSwgaW5kZXhDc3M6IHRydWUsIHZpdGVFbnY6IHRydWUsIG5ldGxpZnlUb21sOiB0cnVlLCBnaXRpZ25vcmU6IHRydWUsIG5wbXJjOiB0cnVlIH0pfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0yLjUgcHktMSBiZy1ncmF5LTEwMCBob3ZlcjpiZy1ncmF5LTIwMCB0ZXh0LVsjMmQzNzQ4XSByb3VuZGVkLWxnIHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICBTZWxlY3QgQWxsXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0WmlwT3B0aW9ucyh7IHNlcnZlcjogZmFsc2UsIGFwaUluZGV4OiBmYWxzZSwgYXBwOiBmYWxzZSwgcGFja2FnZUpzb246IGZhbHNlLCBwYWNrYWdlTG9ja0pzb246IGZhbHNlLCB0c2NvbmZpZzogZmFsc2UsIHZpdGVDb25maWc6IGZhbHNlLCB2ZXJjZWxKc29uOiBmYWxzZSwgcmVkaXJlY3RzOiBmYWxzZSwgaW5kZXhIdG1sOiBmYWxzZSwgbWV0YWRhdGE6IGZhbHNlLCBmaXJlYmFzZUNvbmZpZzogZmFsc2UsIHJlYWRtZTogZmFsc2UsIG1haW5Uc3g6IGZhbHNlLCBpbmRleENzczogZmFsc2UsIHZpdGVFbnY6IGZhbHNlLCBuZXRsaWZ5VG9tbDogZmFsc2UsIGdpdGlnbm9yZTogZmFsc2UsIG5wbXJjOiBmYWxzZSB9KX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMi41IHB5LTEgYmctZ3JheS0xMDAgaG92ZXI6YmctZ3JheS0yMDAgdGV4dC1bIzJkMzc0OF0gcm91bmRlZC1sZyB0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgRGVzZWxlY3QgQWxsXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIG1kOmdyaWQtY29scy00IGdhcC0zXCI+XG4gICAgICAgICAgICAgICAge1tcbiAgICAgICAgICAgICAgICAgIHsga2V5OiAnc2VydmVyJywgbGFiZWw6ICdzZXJ2ZXIudHMgKEJhY2tlbmQpJyB9LFxuICAgICAgICAgICAgICAgICAgeyBrZXk6ICdhcGlJbmRleCcsIGxhYmVsOiAnYXBpL2luZGV4LnRzIChTZXJ2ZXJsZXNzKScsIHN0YXRlS2V5OiAnYXBpSW5kZXgnIH0sXG4gICAgICAgICAgICAgICAgICB7IGtleTogJ2FwcCcsIGxhYmVsOiAnc3JjL0FwcC50c3ggKE1haW4gQXBwKScgfSxcbiAgICAgICAgICAgICAgICAgIHsga2V5OiAncGFja2FnZUpzb24nLCBsYWJlbDogJ3BhY2thZ2UuanNvbicgfSxcbiAgICAgICAgICAgICAgICAgIHsga2V5OiAncGFja2FnZUxvY2tKc29uJywgbGFiZWw6ICdwYWNrYWdlLWxvY2suanNvbicsIHN0YXRlS2V5OiAncGFja2FnZUxvY2tKc29uJyB9LFxuICAgICAgICAgICAgICAgICAgeyBrZXk6ICd0c2NvbmZpZy5qc29uJywgbGFiZWw6ICd0c2NvbmZpZy5qc29uJywgc3RhdGVLZXk6ICd0c2NvbmZpZycgfSxcbiAgICAgICAgICAgICAgICAgIHsga2V5OiAndml0ZUNvbmZpZycsIGxhYmVsOiAndml0ZS5jb25maWcudHMnIH0sXG4gICAgICAgICAgICAgICAgICB7IGtleTogJ3ZlcmNlbEpzb24nLCBsYWJlbDogJ3ZlcmNlbC5qc29uJywgc3RhdGVLZXk6ICd2ZXJjZWxKc29uJyB9LFxuICAgICAgICAgICAgICAgICAgeyBrZXk6ICdyZWRpcmVjdHMnLCBsYWJlbDogJ19yZWRpcmVjdHMgKENsb3VkZmxhcmUvTmV0bGlmeSknLCBzdGF0ZUtleTogJ3JlZGlyZWN0cycgfSxcbiAgICAgICAgICAgICAgICAgIHsga2V5OiAnaW5kZXhIdG1sJywgbGFiZWw6ICdpbmRleC5odG1sJyB9LFxuICAgICAgICAgICAgICAgICAgeyBrZXk6ICdtZXRhZGF0YScsIGxhYmVsOiAnbWV0YWRhdGEuanNvbicgfSxcbiAgICAgICAgICAgICAgICAgIHsga2V5OiAnZmlyZWJhc2VDb25maWcnLCBsYWJlbDogJ2ZpcmViYXNlLWFwcGxldC1jb25maWcuanNvbicgfSxcbiAgICAgICAgICAgICAgICAgIHsga2V5OiAnbWFpblRzeCcsIGxhYmVsOiAnc3JjL21haW4udHN4JyB9LFxuICAgICAgICAgICAgICAgICAgeyBrZXk6ICdpbmRleENzcycsIGxhYmVsOiAnc3JjL2luZGV4LmNzcycgfSxcbiAgICAgICAgICAgICAgICAgIHsga2V5OiAndml0ZUVudicsIGxhYmVsOiAnc3JjL3ZpdGUtZW52LmQudHMnIH0sXG4gICAgICAgICAgICAgICAgICB7IGtleTogJ25ldGxpZnlUb21sJywgbGFiZWw6ICduZXRsaWZ5LnRvbWwnLCBzdGF0ZUtleTogJ25ldGxpZnlUb21sJyB9LFxuICAgICAgICAgICAgICAgICAgeyBrZXk6ICdnaXRpZ25vcmUnLCBsYWJlbDogJy5naXRpZ25vcmUnIH0sXG4gICAgICAgICAgICAgICAgICB7IGtleTogJ25wbXJjJywgbGFiZWw6ICcubnBtcmMnLCBzdGF0ZUtleTogJ25wbXJjJyB9LFxuICAgICAgICAgICAgICAgICAgeyBrZXk6ICdyZWFkbWUnLCBsYWJlbDogJ1JFQURNRS5tZCcgfVxuICAgICAgICAgICAgICAgIF0ubWFwKGl0ZW0gPT4ge1xuICAgICAgICAgICAgICAgICAgY29uc3QgdmFsID0gKHppcE9wdGlvbnMgYXMgYW55KVtpdGVtLnN0YXRlS2V5IHx8IGl0ZW0ua2V5XTtcbiAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBrZXk9e2l0ZW0ua2V5fSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41IGJnLVsjZmRmYmY3XSBib3JkZXIgYm9yZGVyLVsjZTVlMGQ4XSByb3VuZGVkLXhsIHAtMyBjdXJzb3ItcG9pbnRlciBob3Zlcjpib3JkZXItWyM5M2I1YzZdIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0IFxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3ZhbH1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldFppcE9wdGlvbnMoeyAuLi56aXBPcHRpb25zLCBbaXRlbS5zdGF0ZUtleSB8fCBpdGVtLmtleV06IGUudGFyZ2V0LmNoZWNrZWQgfSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkIGJvcmRlci1bI2U1ZTBkOF0gdGV4dC1bIzkzYjVjNl0gZm9jdXM6cmluZy1bIzkzYjVjNl1cIlxuICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LVsjMmQzNzQ4XSB0cnVuY2F0ZVwiPntpdGVtLmxhYmVsfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB0LTIgYm9yZGVyLXQgYm9yZGVyLVsjZTVlMGQ4XVwiPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICB7emlwVXBkYXRlTWVzc2FnZSAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyZWVuLTYwMCBiZy1ncmVlbi01MCBweC0zIHB5LTEuNSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItZ3JlZW4tMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAge3ppcFVwZGF0ZU1lc3NhZ2V9XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZURvd25sb2FkU291cmNlQXJjaGl2ZX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTYgcHktMyBiZy1bIzkzYjVjNl0gaG92ZXI6YmctWyM3ZmE1YjhdIHRleHQtd2hpdGUgZm9udC1ib2xkIHJvdW5kZWQteGwgdGV4dC14cyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0cmFuc2l0aW9uLWNvbG9ycyBzaGFkb3ctc21cIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxEb3dubG9hZCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgICAgIFVwZGF0ZSAmIERvd25sb2FkIFVwZGF0ZWQgWklQXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG5cbiAgICAgICAgey8qIFRBQiA1OiBTRVRUSU5HUyAqL31cbiAgICAgICAge2FjdGl2ZVRhYiA9PT0gJ3NldHRpbmdzJyAmJiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTggbWF4LXctMnhsXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtWyMyZDM3NDhdXCI+U2V0dGluZ3MgJiBXb3Jrc3BhY2UgSW5mbzwvaDI+XG4gICAgICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlVGFiKCdob21lJyl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIGJnLVsjOTNiNWM2XSB0ZXh0LXdoaXRlIHJvdW5kZWQteGwgdGV4dC14cyBmb250LXNlbWlib2xkXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIEhvbWVcbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIFxuICAgICAgICAgICAgey8qIFRoZSBCcmFuZGVkIFN0cmlwICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBib3JkZXIgYm9yZGVyLVsjZTVlMGQ4XSByb3VuZGVkLTN4bCBwLTYgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHNoYWRvdy1zbVwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00XCI+XG4gICAgICAgICAgICAgICAgPE5DTG9nbyBzaXplPVwibWRcIiBsb2dvVXJsPXt0aGVtZUNvbmZpZy5sb2dvVXJsfSAvPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1bIzJkMzc0OF1cIj57dGhlbWVDb25maWcudGhlbWVOYW1lfTwvaDM+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbW9ubyB0ZXh0LVsjNzE4MDk2XSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj57dGhlbWVDb25maWcuc2xvZ2FufTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0Q3VycmVudFVzZXIobnVsbCl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yLjUgYmctWyNmMGVkZTZdIGhvdmVyOmJnLVsjZTVlMGQ4XSB0ZXh0LVsjMmQzNzQ4XSByb3VuZGVkLXhsIHRleHQteHMgZm9udC1zZW1pYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBib3JkZXIgYm9yZGVyLVsjZTVlMGQ4XSB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgICAgdGl0bGU9XCJTaWduIE91dFwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8TG9nT3V0IGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICAgIFNpZ24gT3V0XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgYm9yZGVyIGJvcmRlci1bI2U1ZTBkOF0gcm91bmRlZC0yeGwgcC02IHNwYWNlLXktMyBzaGFkb3ctc21cIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtWyM3MTgwOTZdXCI+U2lnbmVkIGluIHVzZXIgSUQ6IDxzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC1bIzJkMzc0OF1cIj5Ae2N1cnJlbnRVc2VyLnVzZXJuYW1lfTwvc3Ryb25nPjwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1bIzcxODA5Nl1cIj5DdXJyZW50IERldmljZToge2N1cnJlbnRVc2VyLmRldmljZX08L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtWyM3MTgwOTZdXCI+R2VvLUxvY2F0aW9uOiB7Y3VycmVudFVzZXIuZ2VvTG9jYXRpb259PC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LVsjNzE4MDk2XSBwdC0yIGJvcmRlci10IGJvcmRlci1bI2U1ZTBkOF1cIj57dGhlbWVDb25maWcuYWJvdXRUZXh0fTwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBCdXNpbmVzcyBQcm9maWxlICYgVmVyaWZpZWQgU3RhdHVzICgxNiBFbGVtZW50cykgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGJvcmRlciBib3JkZXItWyNlNWUwZDhdIHJvdW5kZWQtM3hsIHAtNiBzcGFjZS15LTYgc2hhZG93LXNtXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGJvcmRlci1iIGJvcmRlci1bI2U1ZTBkOF0gcGItNFwiPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1bIzJkMzc0OF0gZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgQnVzaW5lc3MgUHJvZmlsZSAmIFZlcmlmaWVkIFN0YXR1c1xuICAgICAgICAgICAgICAgICAgICB7Z2V0QnVzaW5lc3NWZXJpZmljYXRpb25TdGF0dXMoYnVzaW5lc3NQcm9maWxlKS5pc1ZlcmlmaWVkICYmIChcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiZy1ibHVlLTYwMCB0ZXh0LXdoaXRlIHJvdW5kZWQtZnVsbCBwLTAuNSB0ZXh0LXhzIGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB3LTUgaC01IHNoYWRvdy1zbVwiIHRpdGxlPVwiVmVyaWZpZWQgQnVzaW5lc3MgKEJsdWUgVGljaylcIj7inJM8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LVsjNzE4MDk2XVwiPkZpbGwg4omlODAlICgxMyBvZiAxNiBkZXRhaWxzKSB0byBhdXRvbWF0aWNhbGx5IGVhcm4gdGhlIFZlcmlmaWVkIEJ1c2luZXNzIEJsdWUgVGljayBiYWRnZS48L3A+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXJpZ2h0XCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2B0ZXh0LXhzIHB4LTMgcHktMS41IHJvdW5kZWQtZnVsbCBmb250LWJvbGQgJHtnZXRCdXNpbmVzc1ZlcmlmaWNhdGlvblN0YXR1cyhidXNpbmVzc1Byb2ZpbGUpLmlzVmVyaWZpZWQgPyAnYmctYmx1ZS0xMDAgdGV4dC1ibHVlLTgwMCcgOiAnYmctYW1iZXItMTAwIHRleHQtYW1iZXItODAwJ31gfT5cbiAgICAgICAgICAgICAgICAgICAge2dldEJ1c2luZXNzVmVyaWZpY2F0aW9uU3RhdHVzKGJ1c2luZXNzUHJvZmlsZSkuc2NvcmV9JSBDb21wbGV0ZSAoe2dldEJ1c2luZXNzVmVyaWZpY2F0aW9uU3RhdHVzKGJ1c2luZXNzUHJvZmlsZSkuZmlsbGVkQ291bnR9LzE2KVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTRcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMS41XCI+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LVsjNGE1NTY4XVwiPjEuIEJ1c2luZXNzIE5hbWU8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGlucHV0IFxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtidXNpbmVzc1Byb2ZpbGUuYnVzaW5lc3NOYW1lfVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRCdXNpbmVzc1Byb2ZpbGUoeyAuLi5idXNpbmVzc1Byb2ZpbGUsIGJ1c2luZXNzTmFtZTogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1bI2ZkZmJmN10gYm9yZGVyIGJvcmRlci1bI2U1ZTBkOF0gcm91bmRlZC14bCBweC00IHB5LTIuNSB0ZXh0LXNtIHRleHQtWyMyZDM3NDhdXCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMS41XCI+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LVsjNGE1NTY4XVwiPjIuIEJ1c2luZXNzIFVzZXJuYW1lPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dCBcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YnVzaW5lc3NQcm9maWxlLmJ1c2luZXNzVXNlcm5hbWV9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldEJ1c2luZXNzUHJvZmlsZSh7IC4uLmJ1c2luZXNzUHJvZmlsZSwgYnVzaW5lc3NVc2VybmFtZTogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1bI2ZkZmJmN10gYm9yZGVyIGJvcmRlci1bI2U1ZTBkOF0gcm91bmRlZC14bCBweC00IHB5LTIuNSB0ZXh0LXNtIHRleHQtWyMyZDM3NDhdXCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMS41XCI+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LVsjNGE1NTY4XVwiPjMuIEJ1c2luZXNzIENhdGVnb3J5PC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dCBcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YnVzaW5lc3NQcm9maWxlLmJ1c2luZXNzQ2F0ZWdvcnl9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldEJ1c2luZXNzUHJvZmlsZSh7IC4uLmJ1c2luZXNzUHJvZmlsZSwgYnVzaW5lc3NDYXRlZ29yeTogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1bI2ZkZmJmN10gYm9yZGVyIGJvcmRlci1bI2U1ZTBkOF0gcm91bmRlZC14bCBweC00IHB5LTIuNSB0ZXh0LXNtIHRleHQtWyMyZDM3NDhdXCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMS41XCI+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LVsjNGE1NTY4XVwiPjQuIEVtYWlsIEFkZHJlc3M8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGlucHV0IFxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZW1haWxcIlxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YnVzaW5lc3NQcm9maWxlLmVtYWlsQWRkcmVzc31cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0QnVzaW5lc3NQcm9maWxlKHsgLi4uYnVzaW5lc3NQcm9maWxlLCBlbWFpbEFkZHJlc3M6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctWyNmZGZiZjddIGJvcmRlciBib3JkZXItWyNlNWUwZDhdIHJvdW5kZWQteGwgcHgtNCBweS0yLjUgdGV4dC1zbSB0ZXh0LVsjMmQzNzQ4XVwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1bIzRhNTU2OF1cIj41LiBQaHlzaWNhbCBBZGRyZXNzIC8gTWFwIExvY2F0aW9uPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dCBcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YnVzaW5lc3NQcm9maWxlLnBoeXNpY2FsQWRkcmVzc31cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0QnVzaW5lc3NQcm9maWxlKHsgLi4uYnVzaW5lc3NQcm9maWxlLCBwaHlzaWNhbEFkZHJlc3M6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctWyNmZGZiZjddIGJvcmRlciBib3JkZXItWyNlNWUwZDhdIHJvdW5kZWQteGwgcHgtNCBweS0yLjUgdGV4dC1zbSB0ZXh0LVsjMmQzNzQ4XVwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1bIzRhNTU2OF1cIj42LiBTZXJ2aWNlIEFyZWE8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGlucHV0IFxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtidXNpbmVzc1Byb2ZpbGUuc2VydmljZUFyZWF9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldEJ1c2luZXNzUHJvZmlsZSh7IC4uLmJ1c2luZXNzUHJvZmlsZSwgc2VydmljZUFyZWE6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctWyNmZGZiZjddIGJvcmRlciBib3JkZXItWyNlNWUwZDhdIHJvdW5kZWQteGwgcHgtNCBweS0yLjUgdGV4dC1zbSB0ZXh0LVsjMmQzNzQ4XVwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1bIzRhNTU2OF1cIj43LiBCdXNpbmVzcyBIb3VyczwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8aW5wdXQgXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2J1c2luZXNzUHJvZmlsZS5idXNpbmVzc0hvdXJzfVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRCdXNpbmVzc1Byb2ZpbGUoeyAuLi5idXNpbmVzc1Byb2ZpbGUsIGJ1c2luZXNzSG91cnM6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctWyNmZGZiZjddIGJvcmRlciBib3JkZXItWyNlNWUwZDhdIHJvdW5kZWQteGwgcHgtNCBweS0yLjUgdGV4dC1zbSB0ZXh0LVsjMmQzNzQ4XVwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1bIzRhNTU2OF1cIj44LiBXZWJzaXRlcyAoVVJMcyk8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGlucHV0IFxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtidXNpbmVzc1Byb2ZpbGUud2Vic2l0ZXN9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldEJ1c2luZXNzUHJvZmlsZSh7IC4uLmJ1c2luZXNzUHJvZmlsZSwgd2Vic2l0ZXM6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctWyNmZGZiZjddIGJvcmRlciBib3JkZXItWyNlNWUwZDhdIHJvdW5kZWQteGwgcHgtNCBweS0yLjUgdGV4dC1zbSB0ZXh0LVsjMmQzNzQ4XVwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1bIzRhNTU2OF1cIj45LiBMaW5rZWQgU29jaWFsIEFjY291bnRzIChGYWNlYm9vayAmIEluc3RhZ3JhbSk8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGlucHV0IFxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtidXNpbmVzc1Byb2ZpbGUuZmFjZWJvb2tJbnN0YWdyYW19XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldEJ1c2luZXNzUHJvZmlsZSh7IC4uLmJ1c2luZXNzUHJvZmlsZSwgZmFjZWJvb2tJbnN0YWdyYW06IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctWyNmZGZiZjddIGJvcmRlciBib3JkZXItWyNlNWUwZDhdIHJvdW5kZWQteGwgcHgtNCBweS0yLjUgdGV4dC1zbSB0ZXh0LVsjMmQzNzQ4XVwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1bIzRhNTU2OF1cIj4xMC4gU2VydmljZXMgKFBheW1lbnQgJiBQYXJraW5nIG9wdGlvbnMpPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dCBcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YnVzaW5lc3NQcm9maWxlLnBheW1lbnRQYXJraW5nT3B0aW9uc31cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0QnVzaW5lc3NQcm9maWxlKHsgLi4uYnVzaW5lc3NQcm9maWxlLCBwYXltZW50UGFya2luZ09wdGlvbnM6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctWyNmZGZiZjddIGJvcmRlciBib3JkZXItWyNlNWUwZDhdIHJvdW5kZWQteGwgcHgtNCBweS0yLjUgdGV4dC1zbSB0ZXh0LVsjMmQzNzQ4XVwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1bIzRhNTU2OF1cIj4xMS4gQWJvdXQgLyBTdGF0dXMgTWVzc2FnZTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8aW5wdXQgXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2J1c2luZXNzUHJvZmlsZS5zdGF0dXNNZXNzYWdlfVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRCdXNpbmVzc1Byb2ZpbGUoeyAuLi5idXNpbmVzc1Byb2ZpbGUsIHN0YXR1c01lc3NhZ2U6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctWyNmZGZiZjddIGJvcmRlciBib3JkZXItWyNlNWUwZDhdIHJvdW5kZWQteGwgcHgtNCBweS0yLjUgdGV4dC1zbSB0ZXh0LVsjMmQzNzQ4XVwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMS41XCI+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1bIzRhNTU2OF1cIj4xMi4gQnVzaW5lc3MgRGVzY3JpcHRpb248L2xhYmVsPlxuICAgICAgICAgICAgICAgIDx0ZXh0YXJlYSBcbiAgICAgICAgICAgICAgICAgIHJvd3M9ezJ9XG4gICAgICAgICAgICAgICAgICB2YWx1ZT17YnVzaW5lc3NQcm9maWxlLmJ1c2luZXNzRGVzY3JpcHRpb259XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRCdXNpbmVzc1Byb2ZpbGUoeyAuLi5idXNpbmVzc1Byb2ZpbGUsIGJ1c2luZXNzRGVzY3JpcHRpb246IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLVsjZmRmYmY3XSBib3JkZXIgYm9yZGVyLVsjZTVlMGQ4XSByb3VuZGVkLXhsIHB4LTQgcHktMi41IHRleHQtc20gdGV4dC1bIzJkMzc0OF1cIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiAxMywgMTQsIDE1OiBQcm9maWxlIFBob3RvLCBDb3ZlciBQaG90bywgQ2F0YWxvZyAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC00IHB0LTIgYm9yZGVyLXQgYm9yZGVyLVsjZTVlMGQ4XVwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtWyM0YTU1NjhdXCI+MTMuIFByb2ZpbGUgUGhvdG88L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBiZy1bI2ZkZmJmN10gYm9yZGVyIGJvcmRlci1bI2U1ZTBkOF0gcm91bmRlZC14bCBweC00IHB5LTJcIj5cbiAgICAgICAgICAgICAgICAgICAge2J1c2luZXNzUHJvZmlsZS5wcm9maWxlUGhvdG8gPyAoXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBmbGV4LTEgbWluLXctMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGltZyBzcmM9e2J1c2luZXNzUHJvZmlsZS5wcm9maWxlUGhvdG99IGNsYXNzTmFtZT1cInctOCBoLTggcm91bmRlZC1mdWxsIG9iamVjdC1jb3ZlciBzaHJpbmstMCBib3JkZXIgYm9yZGVyLVsjZTVlMGQ4XVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtWyMyZDM3NDhdIHRydW5jYXRlXCI+UHJvZmlsZSBQaG90byBBY3RpdmU8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIFxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QnVzaW5lc3NQcm9maWxlKHsgLi4uYnVzaW5lc3NQcm9maWxlLCBwcm9maWxlUGhvdG86ICcnIH0pfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEgaG92ZXI6YmctcmVkLTUwIHRleHQtcmVkLTUwMCByb3VuZGVkLWxnIHRyYW5zaXRpb24tY29sb3JzIG1sLWF1dG9cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIlJlbW92ZSBQaG90b1wiXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxUcmFzaDIgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LVsjNzE4MDk2XSB0cnVuY2F0ZSBmbGV4LTFcIj5TZWxlY3QgZnJvbSBkZXZpY2U8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJweC00IHB5LTIgYmctWyM5M2I1YzZdIGhvdmVyOmJnLVsjN2ZhNWI4XSB0ZXh0LXdoaXRlIHJvdW5kZWQtbGcgdGV4dC14cyBmb250LXNlbWlib2xkIGN1cnNvci1wb2ludGVyIHNoYWRvdy1zbSB0cmFuc2l0aW9uLWNvbG9ycyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBzaHJpbmstMCBzZWxlY3Qtbm9uZVwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxVcGxvYWRJY29uIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIFVwbG9hZCBQaG90b1xuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCBcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJmaWxlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY2VwdD1cImltYWdlLypcIlxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBmaWxlID0gZS50YXJnZXQuZmlsZXM/LlswXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGZpbGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCByZWFkZXIgPSBuZXcgRmlsZVJlYWRlcigpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRlci5vbmxvYWRlbmQgPSAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRCdXNpbmVzc1Byb2ZpbGUoeyAuLi5idXNpbmVzc1Byb2ZpbGUsIHByb2ZpbGVQaG90bzogcmVhZGVyLnJlc3VsdCBhcyBzdHJpbmcgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWFkZXIucmVhZEFzRGF0YVVSTChmaWxlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImhpZGRlblwiXG4gICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1bIzRhNTU2OF1cIj4xNC4gQ292ZXIgUGhvdG88L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBiZy1bI2ZkZmJmN10gYm9yZGVyIGJvcmRlci1bI2U1ZTBkOF0gcm91bmRlZC14bCBweC00IHB5LTJcIj5cbiAgICAgICAgICAgICAgICAgICAge2J1c2luZXNzUHJvZmlsZS5jb3ZlclBob3RvID8gKFxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgZmxleC0xIG1pbi13LTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbWcgc3JjPXtidXNpbmVzc1Byb2ZpbGUuY292ZXJQaG90b30gY2xhc3NOYW1lPVwidy0xMiBoLTggcm91bmRlZCBvYmplY3QtY292ZXIgc2hyaW5rLTAgYm9yZGVyIGJvcmRlci1bI2U1ZTBkOF1cIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LVsjMmQzNzQ4XSB0cnVuY2F0ZVwiPkNvdmVyIFBob3RvIEFjdGl2ZTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRCdXNpbmVzc1Byb2ZpbGUoeyAuLi5idXNpbmVzc1Byb2ZpbGUsIGNvdmVyUGhvdG86ICcnIH0pfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEgaG92ZXI6YmctcmVkLTUwIHRleHQtcmVkLTUwMCByb3VuZGVkLWxnIHRyYW5zaXRpb24tY29sb3JzIG1sLWF1dG9cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIlJlbW92ZSBDb3ZlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxUcmFzaDIgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LVsjNzE4MDk2XSB0cnVuY2F0ZSBmbGV4LTFcIj5TZWxlY3QgZnJvbSBkZXZpY2U8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJweC00IHB5LTIgYmctWyM5M2I1YzZdIGhvdmVyOmJnLVsjN2ZhNWI4XSB0ZXh0LXdoaXRlIHJvdW5kZWQtbGcgdGV4dC14cyBmb250LXNlbWlib2xkIGN1cnNvci1wb2ludGVyIHNoYWRvdy1zbSB0cmFuc2l0aW9uLWNvbG9ycyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBzaHJpbmstMCBzZWxlY3Qtbm9uZVwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxVcGxvYWRJY29uIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIFVwbG9hZCBDb3ZlclxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCBcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJmaWxlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY2VwdD1cImltYWdlLypcIlxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBmaWxlID0gZS50YXJnZXQuZmlsZXM/LlswXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGZpbGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCByZWFkZXIgPSBuZXcgRmlsZVJlYWRlcigpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRlci5vbmxvYWRlbmQgPSAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRCdXNpbmVzc1Byb2ZpbGUoeyAuLi5idXNpbmVzc1Byb2ZpbGUsIGNvdmVyUGhvdG86IHJlYWRlci5yZXN1bHQgYXMgc3RyaW5nIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVhZGVyLnJlYWRBc0RhdGFVUkwoZmlsZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoaWRkZW5cIlxuICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIDE1LiBDYXRhbG9nIChQcm9kdWN0cyAmIFNlcnZpY2VzKSAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTMgcHQtMiBib3JkZXItdCBib3JkZXItWyNlNWUwZDhdXCI+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtWyMyZDM3NDhdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+MTUuIENhdGFsb2cgKFByb2R1Y3RzICYgU2VydmljZXMpIOKAlCB7YnVzaW5lc3NQcm9maWxlLmNhdGFsb2dJdGVtcy5sZW5ndGh9IGl0ZW1zPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1bIzcxODA5Nl1cIj5VcGRhdGVkIGluc3RhbnRseSBpbiBBbGJ1bSBzZWN0aW9uPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgICAge2J1c2luZXNzUHJvZmlsZS5jYXRhbG9nSXRlbXMubWFwKGl0ZW0gPT4gKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17aXRlbS5pZH0gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGJnLVsjZmRmYmY3XSBib3JkZXIgYm9yZGVyLVsjZTVlMGQ4XSByb3VuZGVkLXhsIHAtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtWyMyZDM3NDhdXCI+e2l0ZW0ubmFtZX0gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1vbm8gdGV4dC1ncmVlbi03MDAgZm9udC1zZW1pYm9sZCBtbC0yXCI+e2l0ZW0ucHJpY2V9PC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtWyM3MTgwOTZdXCI+e2l0ZW0uZGVzY3JpcHRpb259PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB1cGRhdGVkID0gYnVzaW5lc3NQcm9maWxlLmNhdGFsb2dJdGVtcy5maWx0ZXIoYyA9PiBjLmlkICE9PSBpdGVtLmlkKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0QnVzaW5lc3NQcm9maWxlKHsgLi4uYnVzaW5lc3NQcm9maWxlLCBjYXRhbG9nSXRlbXM6IHVwZGF0ZWQgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNjAwIGhvdmVyOnRleHQtcmVkLTgwMCBwLTFcIlxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxUcmFzaCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMyBnYXAtMiBwdC0yXCI+XG4gICAgICAgICAgICAgICAgICA8aW5wdXQgXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJQcm9kdWN0L1NlcnZpY2UgbmFtZVwiXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtuZXdDYXROYW1lfVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXROZXdDYXROYW1lKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctWyNmZGZiZjddIGJvcmRlciBib3JkZXItWyNlNWUwZDhdIHJvdW5kZWQteGwgcHgtMyBweS0yIHRleHQteHMgdGV4dC1bIzJkMzc0OF1cIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dCBcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlByaWNlIChlLmcuICQ0OS45OSlcIlxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17bmV3Q2F0UHJpY2V9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldE5ld0NhdFByaWNlKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctWyNmZGZiZjddIGJvcmRlciBib3JkZXItWyNlNWUwZDhdIHJvdW5kZWQteGwgcHgtMyBweS0yIHRleHQteHMgdGV4dC1bIzJkMzc0OF1cIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXQgXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2hvcnQgZGVzY3JpcHRpb25cIlxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtuZXdDYXREZXNjfVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldE5ld0NhdERlc2MoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLVsjZmRmYmY3XSBib3JkZXIgYm9yZGVyLVsjZTVlMGQ4XSByb3VuZGVkLXhsIHB4LTMgcHktMiB0ZXh0LXhzIHRleHQtWyMyZDM3NDhdIGZsZXgtMVwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAobmV3Q2F0TmFtZS50cmltKCkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgbmV3SXRlbSA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZDogYGNhdC0ke0RhdGUubm93KCl9YCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lOiBuZXdDYXROYW1lLnRyaW0oKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcmljZTogbmV3Q2F0UHJpY2UudHJpbSgpIHx8ICckMC4wMCcsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVzY3JpcHRpb246IG5ld0NhdERlc2MudHJpbSgpXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNldEJ1c2luZXNzUHJvZmlsZSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLi4uYnVzaW5lc3NQcm9maWxlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhdGFsb2dJdGVtczogWy4uLmJ1c2luZXNzUHJvZmlsZS5jYXRhbG9nSXRlbXMsIG5ld0l0ZW1dXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICBzZXROZXdDYXROYW1lKCcnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0TmV3Q2F0UHJpY2UoJycpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICBzZXROZXdDYXREZXNjKCcnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMgcHktMiBiZy1bIzkzYjVjNl0gaG92ZXI6YmctWyM3ZmE1YjhdIHRleHQtd2hpdGUgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgc2hyaW5rLTBcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgQWRkXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtNCBib3JkZXItdCBib3JkZXItWyNlNWUwZDhdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICB7Yml6U2F2ZU1zZyAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyZWVuLTYwMCBiZy1ncmVlbi01MCBweC0zIHB5LTEuNSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItZ3JlZW4tMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAge2JpelNhdmVNc2d9XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBzZXRCaXpTYXZlTXNnKCdCdXNpbmVzcyBQcm9maWxlICYgQ2F0YWxvZyBzYXZlZCBzdWNjZXNzZnVsbHkhJyk7XG4gICAgICAgICAgICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0Qml6U2F2ZU1zZygnJyksIDMwMDApO1xuICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTYgcHktMi41IGJnLVsjOTNiNWM2XSBob3ZlcjpiZy1bIzdmYTViOF0gdGV4dC13aGl0ZSBmb250LXNlbWlib2xkIHJvdW5kZWQteGwgdGV4dC14cyB0cmFuc2l0aW9uLWNvbG9ycyBzaGFkb3ctc20gZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxDaGVjayBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgICAgIFNhdmUgQnVzaW5lc3MgUHJvZmlsZVxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuXG4gICAgICA8L21haW4+XG5cbiAgICAgIHsvKiBBZGQgQ29udGFjdCBNb2RhbCAqL31cbiAgICAgIHtpc0FkZENvbnRhY3RPcGVuICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIGJnLVsjMmQzNzQ4XS82MCBiYWNrZHJvcC1ibHVyLXNtIHotNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC02XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBib3JkZXIgYm9yZGVyLVsjZTVlMGQ4XSByb3VuZGVkLTN4bCBtYXgtdy1tZCB3LWZ1bGwgcC02IHNwYWNlLXktNCBzaGFkb3ctMnhsXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBib3JkZXItYiBib3JkZXItWyNlNWUwZDhdIHBiLTNcIj5cbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtWyMyZDM3NDhdXCI+Q29ubmVjdCBOZXcgVXNlcjwvaDM+XG4gICAgICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXNBZGRDb250YWN0T3BlbihmYWxzZSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1bIzcxODA5Nl0gaG92ZXI6dGV4dC1bIzJkMzc0OF1cIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAg4pyVXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlQWRkQ29udGFjdH0gY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LVsjNGE1NTY4XVwiPlVzZXJuYW1lIG9yIEhhbmRsZTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGlucHV0IFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e25ld0NvbnRhY3RIYW5kbGV9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXROZXdDb250YWN0SGFuZGxlKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZS5nLiBhbGV4X2RldlwiXG4gICAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLVsjZmRmYmY3XSBib3JkZXIgYm9yZGVyLVsjZTVlMGQ4XSByb3VuZGVkLXhsIHB4LTQgcHktMyB0ZXh0LXNtIHRleHQtWyMyZDM3NDhdIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItWyM5M2I1YzZdXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGJ1dHRvbiBcbiAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHktMyBiZy1bIzkzYjVjNl0gaG92ZXI6YmctWyM3ZmE1YjhdIHRleHQtd2hpdGUgZm9udC1zZW1pYm9sZCByb3VuZGVkLXhsIHRleHQtc20gdHJhbnNpdGlvbi1jb2xvcnMgc2hhZG93LXNtXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIENvbm5lY3QgJiBPcGVuIENoYXRcbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIFZpZGVvIENhbGwgTW9kYWwgKi99XG4gICAgICB7aXNWaWRlb0NhbGxBY3RpdmUgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgYmctWyMyZDM3NDhdLzYwIGJhY2tkcm9wLWJsdXItc20gei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTZcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGJvcmRlciBib3JkZXItWyNlNWUwZDhdIHJvdW5kZWQtM3hsIG1heC13LXhsIHctZnVsbCBwLTYgc3BhY2UteS00IHNoYWRvdy0yeGxcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGJvcmRlci1iIGJvcmRlci1bI2U1ZTBkOF0gcGItM1wiPlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1bIzJkMzc0OF1cIj5WaWRlbyBDYWxsPC9oMz5cbiAgICAgICAgICAgICAgPGJ1dHRvbiBcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc1ZpZGVvQ2FsbEFjdGl2ZShmYWxzZSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0xLjUgYmctcmVkLTYwMCB0ZXh0LXdoaXRlIHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGRcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgRW5kXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtNjQgYmctWyNmN2Y1ZjBdIHJvdW5kZWQtMnhsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQteHMgdGV4dC1bIzcxODA5Nl1cIj5cbiAgICAgICAgICAgICAgU2VjdXJlIEVuY3J5cHRlZCBWaWRlbyBTdHJlYW0gQWN0aXZlXG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7LyogQWRtaW4gUGFzc3dvcmQgUHJvdGVjdGlvbiBNb2RhbCAqL31cbiAgICAgIHtpc0FkbWluUGFzc3dvcmRNb2RhbE9wZW4gJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgYmctWyMyZDM3NDhdLzYwIGJhY2tkcm9wLWJsdXItc20gei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTZcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGJvcmRlciBib3JkZXItWyNlNWUwZDhdIHJvdW5kZWQtM3hsIG1heC13LW1kIHctZnVsbCBwLTYgc3BhY2UteS00IHNoYWRvdy0yeGxcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGJvcmRlci1iIGJvcmRlci1bI2U1ZTBkOF0gcGItM1wiPlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1bIzJkMzc0OF0gZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8U2hpZWxkIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1bI2I5MWMxY11cIiAvPlxuICAgICAgICAgICAgICAgIEFkbWluIFN1aXRlIFBhc3N3b3JkIFByb3RlY3Rpb25cbiAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgPGJ1dHRvbiBcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc0FkbWluUGFzc3dvcmRNb2RhbE9wZW4oZmFsc2UpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtWyM3MTgwOTZdIGhvdmVyOnRleHQtWyMyZDM3NDhdXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIOKclVxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVZlcmlmeUFkbWluUGFzc3dvcmR9IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtWyM3MTgwOTZdXCI+RW50ZXIgeW91ciBhZG1pbiBzZWN1cml0eSBwYXNzd29yZCB0byBhY2Nlc3MgdGhlIE1hc3RlciBBZG1pbiBTdWl0ZSBhbmQgd2hpdGUtbGFiZWwgYnJhbmRpbmcgY29udHJvbHMuPC9wPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMS41XCI+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1bIzRhNTU2OF1cIj5BZG1pbiBQYXNzd29yZDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGlucHV0IFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXthZG1pblBhc3N3b3JkSW5wdXR9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRBZG1pblBhc3N3b3JkSW5wdXQoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBwYXNzd29yZCAoZS5nLiBhZG1pbjEyMylcIlxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgICAgIGF1dG9Gb2N1c1xuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLVsjZmRmYmY3XSBib3JkZXIgYm9yZGVyLVsjZTVlMGQ4XSByb3VuZGVkLXhsIHB4LTQgcHktMyB0ZXh0LXNtIHRleHQtWyMyZDM3NDhdIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItWyM5M2I1YzZdXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAge2FkbWluUGFzc3dvcmRFcnJvciAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtcmVkLTYwMCBiZy1yZWQtNTAgcC0yIHJvdW5kZWQtbGdcIj57YWRtaW5QYXNzd29yZEVycm9yfTwvZGl2PlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTMgcHQtMlwiPlxuICAgICAgICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldElzQWRtaW5QYXNzd29yZE1vZGFsT3BlbihmYWxzZSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTEgcHktMi41IGJnLWdyYXktMTAwIGhvdmVyOmJnLWdyYXktMjAwIHRleHQtWyM0YTU1NjhdIGZvbnQtc2VtaWJvbGQgcm91bmRlZC14bCB0ZXh0LXhzIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICBDYW5jZWxcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTEgcHktMi41IGJnLVsjYjkxYzFjXSBob3ZlcjpiZy1bI2ExMTYxNl0gdGV4dC13aGl0ZSBmb250LXNlbWlib2xkIHJvdW5kZWQteGwgdGV4dC14cyB0cmFuc2l0aW9uLWNvbG9ycyBzaGFkb3ctc21cIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIFZlcmlmeSAmIE9wZW5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIENyZWF0ZSBOZXcgQWxidW0gLyBQb3N0IE1vZGFsIChJbnNpZGUgKyBvcHRpb24pICovfVxuICAgICAge3Nob3dDcmVhdGVCb3ggJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgYmctYmxhY2svNzAgYmFja2Ryb3AtYmx1ci1zbSB6LTUwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctWyMxYzFjMWVdIGJvcmRlciBib3JkZXItZ3JheS04MDAgcm91bmRlZC0zeGwgbWF4LXctbGcgdy1mdWxsIHAtNiBzcGFjZS15LTQgc2hhZG93LTJ4bCBhbmltYXRlLWluIGZhZGUtaW4gem9vbS1pbi05NSBkdXJhdGlvbi0yMDBcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGJvcmRlci1iIGJvcmRlci1ncmF5LTgwMCBwYi0zXCI+XG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPkNyZWF0ZSBOZXcgQWxidW0gLyBQb3N0PC9oMz5cbiAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRTaG93Q3JlYXRlQm94KGZhbHNlKX0gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMCBob3Zlcjp0ZXh0LXdoaXRlIHRleHQtc21cIj7inJU8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZUNyZWF0ZUFsYnVtfSBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTFcIj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNDAwXCI+QWxidW0gVGl0bGU8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxpbnB1dCBcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtuZXdBbGJ1bVRpdGxlfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0TmV3QWxidW1UaXRsZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkFsYnVtIFRpdGxlXCJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctYmxhY2sgYm9yZGVyIGJvcmRlci1ncmF5LTgwMCByb3VuZGVkLXhsIHB4LTQgcHktMyB0ZXh0LXNtIHRleHQtd2hpdGUgcGxhY2Vob2xkZXItZ3JheS01MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1ibHVlLTUwMFwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTQwMFwiPkNhcHRpb248L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxpbnB1dCBcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtuZXdBbGJ1bUNhcHRpb259XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXROZXdBbGJ1bUNhcHRpb24oZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJDYXB0aW9uXCJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1ibGFjayBib3JkZXIgYm9yZGVyLWdyYXktODAwIHJvdW5kZWQteGwgcHgtNCBweS0zIHRleHQtc20gdGV4dC13aGl0ZSBwbGFjZWhvbGRlci1ncmF5LTUwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTFcIj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNDAwXCI+TWVkaWEgZmlsZTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInctZnVsbCBiZy1ibGFjayBib3JkZXIgYm9yZGVyLWdyYXktODAwIHJvdW5kZWQteGwgcHgtNCBweS0zIHRleHQteHMgdGV4dC1ncmF5LTQwMCBjdXJzb3ItcG9pbnRlciBob3Zlcjpib3JkZXItZ3JheS03MDAgdHJhbnNpdGlvbi1jb2xvcnMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgIDxVcGxvYWRJY29uIGNsYXNzTmFtZT1cInctNCBoLTQgc2hyaW5rLTAgdGV4dC1ibHVlLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0cnVuY2F0ZVwiPntzZWxlY3RlZEZpbGVOYW1lIHx8ICdTZWxlY3QgZnJvbSBkZXZpY2UnfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dCBcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImZpbGVcIlxuICAgICAgICAgICAgICAgICAgICBhY2NlcHQ9XCJpbWFnZS8qLHZpZGVvLypcIlxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlRmlsZUNoYW5nZX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaGlkZGVuXCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtMiBmbGV4IGp1c3RpZnktZW5kIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd0NyZWF0ZUJveChmYWxzZSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIuNSBiZy1ncmF5LTgwMCBob3ZlcjpiZy1ncmF5LTcwMCB0ZXh0LXdoaXRlIHJvdW5kZWQteGwgdGV4dC14cyBmb250LXNlbWlib2xkXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICBDYW5jZWxcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNDb21wcmVzc2luZ31cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTYgcHktMi41IGJnLWJsdWUtNjAwIGhvdmVyOmJnLWJsdWUtNTAwIGRpc2FibGVkOm9wYWNpdHktNTAgdGV4dC13aGl0ZSBmb250LXNlbWlib2xkIHJvdW5kZWQteGwgdGV4dC14cyBzaGFkb3ctc21cIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIHtpc0NvbXByZXNzaW5nID8gJ0NvbXByZXNzaW5nLi4uJyA6ICdQb3N0J31cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL2FwcC9hcHBsZXQvc3JjL0FwcC50c3gifQ==