/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import __vite__cjsImport0_express from "/node_modules/.vite/deps/express.js?v=010d7dd6"; const express = __vite__cjsImport0_express.__esModule ? __vite__cjsImport0_express.default : __vite__cjsImport0_express;
import path from "/@id/__vite-browser-external:path";
import __vite__cjsImport2_url from "/@id/__vite-browser-external:url"; const fileURLToPath = __vite__cjsImport2_url["fileURLToPath"];
import { GoogleGenAI } from "/node_modules/.vite/deps/@google_genai.js?v=6363704b";
try {
  const dotenv = await import('/node_modules/.vite/deps/dotenv.js?v=783b0297').then(m => ((m) => m?.__esModule ? m : { ...typeof m === "object" && !Array.isArray(m) || typeof m === "function" ? m : {}, default: m })(m.default));
  dotenv.default.config();
} catch (e) {
}
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
let users = [
  {
    id: "user-master",
    username: "MA#3175",
    email: "master@nexuschat.io",
    mobile: "+1-555-0100",
    device: "Chrome / macOS",
    geoLocation: "San Francisco, US",
    passwordHash: "7500bs31",
    isAdmin: true,
    isMasterAdmin: true
  },
  {
    id: "user-subadmin",
    username: "SM#3175",
    email: "subadmin@nexuschat.io",
    mobile: "+1-555-0150",
    device: "Firefox / Windows",
    geoLocation: "New York, US",
    passwordHash: "admin123",
    isAdmin: true,
    isMasterAdmin: false
  },
  {
    id: "user-alex",
    username: "alex_dev",
    email: "alex@example.com",
    mobile: "+1-555-0199",
    device: "Safari / iOS",
    geoLocation: "Tokyo, JP",
    passwordHash: "password123",
    isAdmin: false,
    isMasterAdmin: false
  }
];
let globalTheme = {
  themeName: "NexusChat Workspace",
  logoUrl: "",
  chatBackground: "bg-[#f7f5f0]",
  primaryColor: "sage",
  poweredBy: "Powered by NexusCloud White-Label Engine",
  aboutText: "Secure white-label communication portal tailored for schools, colleges, groups, and working centers."
};
let albums = [
  {
    id: "album-1",
    author: "alex_dev",
    authorName: "Alex Chen",
    title: "Campus & Workspace Life",
    caption: "Sharing moments from our daily collaboration center.",
    imageUrl: "https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=800&auto=format&fit=crop&q=80",
    likes: 14,
    comments: [
      { id: "c1", author: "MA#3175", text: "Great collaborative spirit!", time: "2h ago" }
    ],
    timestamp: "Yesterday"
  }
];
let sheetsAuditLog = [
  {
    timestamp: (/* @__PURE__ */ new Date()).toISOString(),
    event: "REGISTRATION_CAPTURE",
    username: "MA#3175",
    email: "master@nexuschat.io",
    mobile: "+1-555-0100",
    device: "Chrome / macOS",
    geoLocation: "San Francisco, US"
  }
];
const app = express();
app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ limit: "50mb", extended: true }));
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      "User-Agent": "aistudio-build"
    }
  }
});
app.post("/api/auth/register", (req, res) => {
  const username = (req.body.username || "").trim();
  const email = (req.body.email || "").trim();
  const mobile = req.body.mobile;
  const device = req.body.device;
  const geoLocation = req.body.geoLocation;
  const password = req.body.password;
  if (!username || !email || !password) {
    return res.status(400).json({ error: "Username, email and password are required" });
  }
  if (users.some((u) => u.username.toLowerCase() === username.toLowerCase() || u.email.toLowerCase() === email.toLowerCase())) {
    return res.status(400).json({ error: "Username or email already exists" });
  }
  const newUser = {
    id: `user-${Date.now()}`,
    username,
    email,
    mobile: mobile || "+1-555-0000",
    device: device || "Unknown Device",
    geoLocation: geoLocation || "Global / VPN",
    passwordHash: password,
    isAdmin: false,
    isMasterAdmin: false
  };
  users.push(newUser);
  sheetsAuditLog.push({
    timestamp: (/* @__PURE__ */ new Date()).toISOString(),
    event: "REGISTRATION_CAPTURE",
    username: newUser.username,
    email: newUser.email,
    mobile: newUser.mobile,
    device: newUser.device,
    geoLocation: newUser.geoLocation
  });
  res.json({ success: true, user: { id: newUser.id, username: newUser.username, email: newUser.email, isAdmin: newUser.isAdmin, isMasterAdmin: newUser.isMasterAdmin } });
});
app.post("/api/auth/login", (req, res) => {
  const usernameOrEmail = (req.body.usernameOrEmail || "").trim();
  const password = req.body.password;
  let user = users.find((u) => u.username.toLowerCase() === usernameOrEmail.toLowerCase() || u.email.toLowerCase() === usernameOrEmail.toLowerCase());
  if (!user) {
    if (usernameOrEmail.toUpperCase().startsWith("MA#")) {
      user = {
        id: `user-${Date.now()}`,
        username: usernameOrEmail,
        email: `${usernameOrEmail.toLowerCase()}@nexuschat.io`,
        mobile: "+1-555-0100",
        device: "Browser / Desktop",
        geoLocation: "San Francisco, US",
        passwordHash: password,
        isAdmin: true,
        isMasterAdmin: true
      };
      users.push(user);
    } else if (usernameOrEmail.toUpperCase().startsWith("SM")) {
      user = {
        id: `user-${Date.now()}`,
        username: usernameOrEmail,
        email: `${usernameOrEmail.toLowerCase()}@nexuschat.io`,
        mobile: "+1-555-0150",
        device: "Browser / Desktop",
        geoLocation: "New York, US",
        passwordHash: password,
        isAdmin: true,
        isMasterAdmin: false
      };
      users.push(user);
    }
  }
  if (!user || user.passwordHash !== password) {
    return res.status(401).json({ error: "Invalid credentials (Check username and password)" });
  }
  if (user.username.toUpperCase().startsWith("MA#")) {
    user.isAdmin = true;
    user.isMasterAdmin = true;
  } else if (user.username.toUpperCase().startsWith("SM")) {
    user.isAdmin = true;
    user.isMasterAdmin = false;
  }
  res.json({
    success: true,
    user: {
      id: user.id,
      username: user.username,
      email: user.email,
      mobile: user.mobile,
      device: user.device,
      geoLocation: user.geoLocation,
      isAdmin: user.isAdmin,
      isMasterAdmin: user.isMasterAdmin,
      mustChangePassword: user.mustChangePassword
    }
  });
});
app.post("/api/auth/update-password", (req, res) => {
  const { userId, currentPassword, newPassword } = req.body;
  const user = users.find((u) => u.id === userId);
  if (!user) return res.status(404).json({ error: "User not found" });
  if (user.passwordHash !== currentPassword) return res.status(400).json({ error: "Current password is incorrect" });
  user.passwordHash = newPassword;
  res.json({ success: true, message: "Password updated successfully" });
});
app.post("/api/auth/forgot-password", (req, res) => {
  const { email, device, mobile, geoLocation } = req.body;
  const user = users.find((u) => u.email === email);
  if (!user) {
    return res.status(404).json({ error: "Email address not found in registry" });
  }
  let matches = 0;
  if (user.email.toLowerCase() === email.toLowerCase()) matches++;
  if (user.device && device && user.device.toLowerCase().includes(device.toLowerCase())) matches++;
  if (user.mobile && mobile && user.mobile === mobile) matches++;
  if (user.geoLocation && geoLocation && user.geoLocation.toLowerCase().includes(geoLocation.toLowerCase())) matches++;
  if (matches < 3) {
    return res.status(403).json({
      error: `Verification failed. Only matched ${matches}/3 required attributes (Device, Email, Mobile, Geo-location).`
    });
  }
  const tempCode = Math.random().toString(36).substring(2, 10).toUpperCase();
  user.temporaryCode = tempCode;
  user.tempCodeExpires = Date.now() + 15 * 60 * 1e3;
  user.mustChangePassword = true;
  res.json({
    success: true,
    message: `Verification successful (${matches}/4 attributes matched). Temporary 8-digit code sent to ${email}`,
    simulatedEmailCode: tempCode
  });
});
app.post("/api/auth/reset-password", (req, res) => {
  const { email, tempCode, newPassword } = req.body;
  const user = users.find((u) => u.email === email);
  if (!user || user.temporaryCode !== tempCode) {
    return res.status(400).json({ error: "Invalid temporary code or email" });
  }
  if (user.tempCodeExpires && Date.now() > user.tempCodeExpires) {
    return res.status(400).json({ error: "Temporary code has expired." });
  }
  user.passwordHash = newPassword;
  user.temporaryCode = void 0;
  user.tempCodeExpires = void 0;
  user.mustChangePassword = false;
  res.json({ success: true, message: "Password updated successfully. You can now login." });
});
app.post("/api/chat/check-privacy", async (req, res) => {
  try {
    const { message } = req.body;
    if (!message) return res.json({ containsPersonalDetails: false });
    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: `Analyze if the following chat message contains sharing of personal sensitive details such as a mobile phone number, email address, physical address, credit card, or passport number. Return JSON with format {"containsPersonalDetails": boolean, "detectedItem": string}:

"${message}"`,
      config: {
        responseMimeType: "application/json"
      }
    });
    const result = JSON.parse(response.text || "{}");
    res.json(result);
  } catch (err) {
    console.error("Gemini privacy check error:", err);
    res.json({ containsPersonalDetails: false });
  }
});
app.get("/api/admin/users", (req, res) => {
  res.json({ users, auditLog: sheetsAuditLog, theme: globalTheme });
});
app.post("/api/admin/promote", (req, res) => {
  const { userId, makeAdmin } = req.body;
  const target = users.find((u) => u.id === userId);
  if (!target) return res.status(404).json({ error: "User not found" });
  target.isAdmin = makeAdmin;
  res.json({ success: true, users });
});
app.post("/api/admin/theme", (req, res) => {
  const { themeName, logoUrl, chatBackground, primaryColor, poweredBy, aboutText } = req.body;
  if (themeName) globalTheme.themeName = themeName;
  if (logoUrl !== void 0) globalTheme.logoUrl = logoUrl;
  if (chatBackground) globalTheme.chatBackground = chatBackground;
  if (primaryColor) globalTheme.primaryColor = primaryColor;
  if (poweredBy !== void 0) globalTheme.poweredBy = poweredBy;
  if (aboutText !== void 0) globalTheme.aboutText = aboutText;
  res.json({ success: true, theme: globalTheme });
});
app.get("/api/albums", (req, res) => {
  res.json({ albums });
});
app.post("/api/albums", (req, res) => {
  const { author, authorName, title, caption, imageUrl } = req.body;
  const newAlbum = {
    id: `album-${Date.now()}`,
    author: author || "user",
    authorName: authorName || "Anonymous",
    title: title || "My Album",
    caption: caption || "",
    imageUrl: imageUrl || "https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&auto=format&fit=crop&q=80",
    likes: 0,
    comments: [],
    timestamp: "Just now"
  };
  albums.unshift(newAlbum);
  res.json({ success: true, album: newAlbum });
});
app.post("/api/albums/:id/like", (req, res) => {
  const { id } = req.params;
  const album = albums.find((a) => a.id === id);
  if (album) {
    album.likes += 1;
    res.json({ success: true, likes: album.likes });
  } else {
    res.status(404).json({ error: "Album not found" });
  }
});
app.post("/api/albums/:id/comment", (req, res) => {
  const { id } = req.params;
  const { author, text } = req.body;
  const album = albums.find((a) => a.id === id);
  if (album) {
    const comment = { id: `c-${Date.now()}`, author: author || "User", text, time: "Just now" };
    album.comments.push(comment);
    res.json({ success: true, comments: album.comments });
  } else {
    res.status(404).json({ error: "Album not found" });
  }
});
export default app;

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGxpY2Vuc2VcbiAqIFNQRFgtTGljZW5zZS1JZGVudGlmaWVyOiBBcGFjaGUtMi4wXG4gKi9cblxuaW1wb3J0IGV4cHJlc3MgZnJvbSBcImV4cHJlc3NcIjtcbmltcG9ydCBwYXRoIGZyb20gXCJwYXRoXCI7XG5pbXBvcnQgeyBmaWxlVVJMVG9QYXRoIH0gZnJvbSBcInVybFwiO1xuaW1wb3J0IHsgR29vZ2xlR2VuQUkgfSBmcm9tIFwiQGdvb2dsZS9nZW5haVwiO1xuXG50cnkge1xuICBjb25zdCBkb3RlbnYgPSBhd2FpdCBpbXBvcnQoXCJkb3RlbnZcIik7XG4gIGRvdGVudi5kZWZhdWx0LmNvbmZpZygpO1xufSBjYXRjaCAoZSkge1xuICAvLyBFbnZpcm9ubWVudCB2YXJpYWJsZXMgcHJvdmlkZWQgZGlyZWN0bHkgYnkgVmVyY2VsIC8gc2VydmVybGVzcyBydW50aW1lXG59XG5cbmNvbnN0IF9fZmlsZW5hbWUgPSBmaWxlVVJMVG9QYXRoKGltcG9ydC5tZXRhLnVybCk7XG5jb25zdCBfX2Rpcm5hbWUgPSBwYXRoLmRpcm5hbWUoX19maWxlbmFtZSk7XG5cbmludGVyZmFjZSBVc2VyUmVjb3JkIHtcbiAgaWQ6IHN0cmluZztcbiAgdXNlcm5hbWU6IHN0cmluZztcbiAgZW1haWw6IHN0cmluZztcbiAgbW9iaWxlOiBzdHJpbmc7XG4gIGRldmljZTogc3RyaW5nO1xuICBnZW9Mb2NhdGlvbjogc3RyaW5nO1xuICBwYXNzd29yZEhhc2g6IHN0cmluZztcbiAgaXNBZG1pbjogYm9vbGVhbjtcbiAgaXNNYXN0ZXJBZG1pbjogYm9vbGVhbjtcbiAgdGVtcG9yYXJ5Q29kZT86IHN0cmluZztcbiAgdGVtcENvZGVFeHBpcmVzPzogbnVtYmVyO1xuICBtdXN0Q2hhbmdlUGFzc3dvcmQ/OiBib29sZWFuO1xufVxuXG5pbnRlcmZhY2UgQWRtaW5UaGVtZSB7XG4gIHRoZW1lTmFtZTogc3RyaW5nO1xuICBsb2dvVXJsOiBzdHJpbmc7XG4gIGNoYXRCYWNrZ3JvdW5kOiBzdHJpbmc7XG4gIHByaW1hcnlDb2xvcjogc3RyaW5nO1xuICBwb3dlcmVkQnk6IHN0cmluZztcbiAgYWJvdXRUZXh0OiBzdHJpbmc7XG59XG5cbmxldCB1c2VyczogVXNlclJlY29yZFtdID0gW1xuICB7XG4gICAgaWQ6IFwidXNlci1tYXN0ZXJcIixcbiAgICB1c2VybmFtZTogXCJNQSMzMTc1XCIsXG4gICAgZW1haWw6IFwibWFzdGVyQG5leHVzY2hhdC5pb1wiLFxuICAgIG1vYmlsZTogXCIrMS01NTUtMDEwMFwiLFxuICAgIGRldmljZTogXCJDaHJvbWUgLyBtYWNPU1wiLFxuICAgIGdlb0xvY2F0aW9uOiBcIlNhbiBGcmFuY2lzY28sIFVTXCIsXG4gICAgcGFzc3dvcmRIYXNoOiBcIjc1MDBiczMxXCIsXG4gICAgaXNBZG1pbjogdHJ1ZSxcbiAgICBpc01hc3RlckFkbWluOiB0cnVlXG4gIH0sXG4gIHtcbiAgICBpZDogXCJ1c2VyLXN1YmFkbWluXCIsXG4gICAgdXNlcm5hbWU6IFwiU00jMzE3NVwiLFxuICAgIGVtYWlsOiBcInN1YmFkbWluQG5leHVzY2hhdC5pb1wiLFxuICAgIG1vYmlsZTogXCIrMS01NTUtMDE1MFwiLFxuICAgIGRldmljZTogXCJGaXJlZm94IC8gV2luZG93c1wiLFxuICAgIGdlb0xvY2F0aW9uOiBcIk5ldyBZb3JrLCBVU1wiLFxuICAgIHBhc3N3b3JkSGFzaDogXCJhZG1pbjEyM1wiLFxuICAgIGlzQWRtaW46IHRydWUsXG4gICAgaXNNYXN0ZXJBZG1pbjogZmFsc2VcbiAgfSxcbiAge1xuICAgIGlkOiBcInVzZXItYWxleFwiLFxuICAgIHVzZXJuYW1lOiBcImFsZXhfZGV2XCIsXG4gICAgZW1haWw6IFwiYWxleEBleGFtcGxlLmNvbVwiLFxuICAgIG1vYmlsZTogXCIrMS01NTUtMDE5OVwiLFxuICAgIGRldmljZTogXCJTYWZhcmkgLyBpT1NcIixcbiAgICBnZW9Mb2NhdGlvbjogXCJUb2t5bywgSlBcIixcbiAgICBwYXNzd29yZEhhc2g6IFwicGFzc3dvcmQxMjNcIixcbiAgICBpc0FkbWluOiBmYWxzZSxcbiAgICBpc01hc3RlckFkbWluOiBmYWxzZVxuICB9XG5dO1xuXG5sZXQgZ2xvYmFsVGhlbWU6IEFkbWluVGhlbWUgPSB7XG4gIHRoZW1lTmFtZTogXCJOZXh1c0NoYXQgV29ya3NwYWNlXCIsXG4gIGxvZ29Vcmw6IFwiXCIsXG4gIGNoYXRCYWNrZ3JvdW5kOiBcImJnLVsjZjdmNWYwXVwiLFxuICBwcmltYXJ5Q29sb3I6IFwic2FnZVwiLFxuICBwb3dlcmVkQnk6IFwiUG93ZXJlZCBieSBOZXh1c0Nsb3VkIFdoaXRlLUxhYmVsIEVuZ2luZVwiLFxuICBhYm91dFRleHQ6IFwiU2VjdXJlIHdoaXRlLWxhYmVsIGNvbW11bmljYXRpb24gcG9ydGFsIHRhaWxvcmVkIGZvciBzY2hvb2xzLCBjb2xsZWdlcywgZ3JvdXBzLCBhbmQgd29ya2luZyBjZW50ZXJzLlwiXG59O1xuXG5sZXQgYWxidW1zID0gW1xuICB7XG4gICAgaWQ6IFwiYWxidW0tMVwiLFxuICAgIGF1dGhvcjogXCJhbGV4X2RldlwiLFxuICAgIGF1dGhvck5hbWU6IFwiQWxleCBDaGVuXCIsXG4gICAgdGl0bGU6IFwiQ2FtcHVzICYgV29ya3NwYWNlIExpZmVcIixcbiAgICBjYXB0aW9uOiBcIlNoYXJpbmcgbW9tZW50cyBmcm9tIG91ciBkYWlseSBjb2xsYWJvcmF0aW9uIGNlbnRlci5cIixcbiAgICBpbWFnZVVybDogXCJodHRwczovL2ltYWdlcy51bnNwbGFzaC5jb20vcGhvdG8tMTUyMjA3MTgyMDA4MS0wMDlmMDEyOWM3MWM/dz04MDAmYXV0bz1mb3JtYXQmZml0PWNyb3AmcT04MFwiLFxuICAgIGxpa2VzOiAxNCxcbiAgICBjb21tZW50czogW1xuICAgICAgeyBpZDogJ2MxJywgYXV0aG9yOiAnTUEjMzE3NScsIHRleHQ6ICdHcmVhdCBjb2xsYWJvcmF0aXZlIHNwaXJpdCEnLCB0aW1lOiAnMmggYWdvJyB9XG4gICAgXSxcbiAgICB0aW1lc3RhbXA6ICdZZXN0ZXJkYXknXG4gIH1cbl07XG5cbmxldCBzaGVldHNBdWRpdExvZzogQXJyYXk8e1xuICB0aW1lc3RhbXA6IHN0cmluZztcbiAgZXZlbnQ6IHN0cmluZztcbiAgdXNlcm5hbWU6IHN0cmluZztcbiAgZW1haWw6IHN0cmluZztcbiAgbW9iaWxlOiBzdHJpbmc7XG4gIGRldmljZTogc3RyaW5nO1xuICBnZW9Mb2NhdGlvbjogc3RyaW5nO1xufT4gPSBbXG4gIHtcbiAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICBldmVudDogXCJSRUdJU1RSQVRJT05fQ0FQVFVSRVwiLFxuICAgIHVzZXJuYW1lOiBcIk1BIzMxNzVcIixcbiAgICBlbWFpbDogXCJtYXN0ZXJAbmV4dXNjaGF0LmlvXCIsXG4gICAgbW9iaWxlOiBcIisxLTU1NS0wMTAwXCIsXG4gICAgZGV2aWNlOiBcIkNocm9tZSAvIG1hY09TXCIsXG4gICAgZ2VvTG9jYXRpb246IFwiU2FuIEZyYW5jaXNjbywgVVNcIlxuICB9XG5dO1xuXG5jb25zdCBhcHAgPSBleHByZXNzKCk7XG5hcHAudXNlKGV4cHJlc3MuanNvbih7IGxpbWl0OiAnNTBtYicgfSkpO1xuYXBwLnVzZShleHByZXNzLnVybGVuY29kZWQoeyBsaW1pdDogJzUwbWInLCBleHRlbmRlZDogdHJ1ZSB9KSk7XG5cbmNvbnN0IGFpID0gbmV3IEdvb2dsZUdlbkFJKHtcbiAgYXBpS2V5OiBwcm9jZXNzLmVudi5HRU1JTklfQVBJX0tFWSxcbiAgaHR0cE9wdGlvbnM6IHtcbiAgICBoZWFkZXJzOiB7XG4gICAgICAnVXNlci1BZ2VudCc6ICdhaXN0dWRpby1idWlsZCcsXG4gICAgfVxuICB9XG59KTtcblxuLy8gQVBJIFJvdXRlc1xuYXBwLnBvc3QoXCIvYXBpL2F1dGgvcmVnaXN0ZXJcIiwgKHJlcSwgcmVzKSA9PiB7XG4gIGNvbnN0IHVzZXJuYW1lID0gKHJlcS5ib2R5LnVzZXJuYW1lIHx8IFwiXCIpLnRyaW0oKTtcbiAgY29uc3QgZW1haWwgPSAocmVxLmJvZHkuZW1haWwgfHwgXCJcIikudHJpbSgpO1xuICBjb25zdCBtb2JpbGUgPSByZXEuYm9keS5tb2JpbGU7XG4gIGNvbnN0IGRldmljZSA9IHJlcS5ib2R5LmRldmljZTtcbiAgY29uc3QgZ2VvTG9jYXRpb24gPSByZXEuYm9keS5nZW9Mb2NhdGlvbjtcbiAgY29uc3QgcGFzc3dvcmQgPSByZXEuYm9keS5wYXNzd29yZDtcbiAgXG4gIGlmICghdXNlcm5hbWUgfHwgIWVtYWlsIHx8ICFwYXNzd29yZCkge1xuICAgIHJldHVybiByZXMuc3RhdHVzKDQwMCkuanNvbih7IGVycm9yOiBcIlVzZXJuYW1lLCBlbWFpbCBhbmQgcGFzc3dvcmQgYXJlIHJlcXVpcmVkXCIgfSk7XG4gIH1cblxuICBpZiAodXNlcnMuc29tZSh1ID0+IHUudXNlcm5hbWUudG9Mb3dlckNhc2UoKSA9PT0gdXNlcm5hbWUudG9Mb3dlckNhc2UoKSB8fCB1LmVtYWlsLnRvTG93ZXJDYXNlKCkgPT09IGVtYWlsLnRvTG93ZXJDYXNlKCkpKSB7XG4gICAgcmV0dXJuIHJlcy5zdGF0dXMoNDAwKS5qc29uKHsgZXJyb3I6IFwiVXNlcm5hbWUgb3IgZW1haWwgYWxyZWFkeSBleGlzdHNcIiB9KTtcbiAgfVxuXG4gIGNvbnN0IG5ld1VzZXI6IFVzZXJSZWNvcmQgPSB7XG4gICAgaWQ6IGB1c2VyLSR7RGF0ZS5ub3coKX1gLFxuICAgIHVzZXJuYW1lLFxuICAgIGVtYWlsLFxuICAgIG1vYmlsZTogbW9iaWxlIHx8IFwiKzEtNTU1LTAwMDBcIixcbiAgICBkZXZpY2U6IGRldmljZSB8fCBcIlVua25vd24gRGV2aWNlXCIsXG4gICAgZ2VvTG9jYXRpb246IGdlb0xvY2F0aW9uIHx8IFwiR2xvYmFsIC8gVlBOXCIsXG4gICAgcGFzc3dvcmRIYXNoOiBwYXNzd29yZCxcbiAgICBpc0FkbWluOiBmYWxzZSxcbiAgICBpc01hc3RlckFkbWluOiBmYWxzZVxuICB9O1xuXG4gIHVzZXJzLnB1c2gobmV3VXNlcik7XG5cbiAgc2hlZXRzQXVkaXRMb2cucHVzaCh7XG4gICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgZXZlbnQ6IFwiUkVHSVNUUkFUSU9OX0NBUFRVUkVcIixcbiAgICB1c2VybmFtZTogbmV3VXNlci51c2VybmFtZSxcbiAgICBlbWFpbDogbmV3VXNlci5lbWFpbCxcbiAgICBtb2JpbGU6IG5ld1VzZXIubW9iaWxlLFxuICAgIGRldmljZTogbmV3VXNlci5kZXZpY2UsXG4gICAgZ2VvTG9jYXRpb246IG5ld1VzZXIuZ2VvTG9jYXRpb25cbiAgfSk7XG5cbiAgcmVzLmpzb24oeyBzdWNjZXNzOiB0cnVlLCB1c2VyOiB7IGlkOiBuZXdVc2VyLmlkLCB1c2VybmFtZTogbmV3VXNlci51c2VybmFtZSwgZW1haWw6IG5ld1VzZXIuZW1haWwsIGlzQWRtaW46IG5ld1VzZXIuaXNBZG1pbiwgaXNNYXN0ZXJBZG1pbjogbmV3VXNlci5pc01hc3RlckFkbWluIH0gfSk7XG59KTtcblxuYXBwLnBvc3QoXCIvYXBpL2F1dGgvbG9naW5cIiwgKHJlcSwgcmVzKSA9PiB7XG4gIGNvbnN0IHVzZXJuYW1lT3JFbWFpbCA9IChyZXEuYm9keS51c2VybmFtZU9yRW1haWwgfHwgXCJcIikudHJpbSgpO1xuICBjb25zdCBwYXNzd29yZCA9IHJlcS5ib2R5LnBhc3N3b3JkO1xuICBsZXQgdXNlciA9IHVzZXJzLmZpbmQodSA9PiB1LnVzZXJuYW1lLnRvTG93ZXJDYXNlKCkgPT09IHVzZXJuYW1lT3JFbWFpbC50b0xvd2VyQ2FzZSgpIHx8IHUuZW1haWwudG9Mb3dlckNhc2UoKSA9PT0gdXNlcm5hbWVPckVtYWlsLnRvTG93ZXJDYXNlKCkpO1xuXG4gIGlmICghdXNlcikge1xuICAgIGlmICh1c2VybmFtZU9yRW1haWwudG9VcHBlckNhc2UoKS5zdGFydHNXaXRoKFwiTUEjXCIpKSB7XG4gICAgICB1c2VyID0ge1xuICAgICAgICBpZDogYHVzZXItJHtEYXRlLm5vdygpfWAsXG4gICAgICAgIHVzZXJuYW1lOiB1c2VybmFtZU9yRW1haWwsXG4gICAgICAgIGVtYWlsOiBgJHt1c2VybmFtZU9yRW1haWwudG9Mb3dlckNhc2UoKX1AbmV4dXNjaGF0LmlvYCxcbiAgICAgICAgbW9iaWxlOiBcIisxLTU1NS0wMTAwXCIsXG4gICAgICAgIGRldmljZTogXCJCcm93c2VyIC8gRGVza3RvcFwiLFxuICAgICAgICBnZW9Mb2NhdGlvbjogXCJTYW4gRnJhbmNpc2NvLCBVU1wiLFxuICAgICAgICBwYXNzd29yZEhhc2g6IHBhc3N3b3JkLFxuICAgICAgICBpc0FkbWluOiB0cnVlLFxuICAgICAgICBpc01hc3RlckFkbWluOiB0cnVlXG4gICAgICB9O1xuICAgICAgdXNlcnMucHVzaCh1c2VyKTtcbiAgICB9IGVsc2UgaWYgKHVzZXJuYW1lT3JFbWFpbC50b1VwcGVyQ2FzZSgpLnN0YXJ0c1dpdGgoXCJTTVwiKSkge1xuICAgICAgdXNlciA9IHtcbiAgICAgICAgaWQ6IGB1c2VyLSR7RGF0ZS5ub3coKX1gLFxuICAgICAgICB1c2VybmFtZTogdXNlcm5hbWVPckVtYWlsLFxuICAgICAgICBlbWFpbDogYCR7dXNlcm5hbWVPckVtYWlsLnRvTG93ZXJDYXNlKCl9QG5leHVzY2hhdC5pb2AsXG4gICAgICAgIG1vYmlsZTogXCIrMS01NTUtMDE1MFwiLFxuICAgICAgICBkZXZpY2U6IFwiQnJvd3NlciAvIERlc2t0b3BcIixcbiAgICAgICAgZ2VvTG9jYXRpb246IFwiTmV3IFlvcmssIFVTXCIsXG4gICAgICAgIHBhc3N3b3JkSGFzaDogcGFzc3dvcmQsXG4gICAgICAgIGlzQWRtaW46IHRydWUsXG4gICAgICAgIGlzTWFzdGVyQWRtaW46IGZhbHNlXG4gICAgICB9O1xuICAgICAgdXNlcnMucHVzaCh1c2VyKTtcbiAgICB9XG4gIH1cblxuICBpZiAoIXVzZXIgfHwgdXNlci5wYXNzd29yZEhhc2ggIT09IHBhc3N3b3JkKSB7XG4gICAgcmV0dXJuIHJlcy5zdGF0dXMoNDAxKS5qc29uKHsgZXJyb3I6IFwiSW52YWxpZCBjcmVkZW50aWFscyAoQ2hlY2sgdXNlcm5hbWUgYW5kIHBhc3N3b3JkKVwiIH0pO1xuICB9XG5cbiAgaWYgKHVzZXIudXNlcm5hbWUudG9VcHBlckNhc2UoKS5zdGFydHNXaXRoKFwiTUEjXCIpKSB7XG4gICAgdXNlci5pc0FkbWluID0gdHJ1ZTtcbiAgICB1c2VyLmlzTWFzdGVyQWRtaW4gPSB0cnVlO1xuICB9IGVsc2UgaWYgKHVzZXIudXNlcm5hbWUudG9VcHBlckNhc2UoKS5zdGFydHNXaXRoKFwiU01cIikpIHtcbiAgICB1c2VyLmlzQWRtaW4gPSB0cnVlO1xuICAgIHVzZXIuaXNNYXN0ZXJBZG1pbiA9IGZhbHNlO1xuICB9XG5cbiAgcmVzLmpzb24oe1xuICAgIHN1Y2Nlc3M6IHRydWUsXG4gICAgdXNlcjoge1xuICAgICAgaWQ6IHVzZXIuaWQsXG4gICAgICB1c2VybmFtZTogdXNlci51c2VybmFtZSxcbiAgICAgIGVtYWlsOiB1c2VyLmVtYWlsLFxuICAgICAgbW9iaWxlOiB1c2VyLm1vYmlsZSxcbiAgICAgIGRldmljZTogdXNlci5kZXZpY2UsXG4gICAgICBnZW9Mb2NhdGlvbjogdXNlci5nZW9Mb2NhdGlvbixcbiAgICAgIGlzQWRtaW46IHVzZXIuaXNBZG1pbixcbiAgICAgIGlzTWFzdGVyQWRtaW46IHVzZXIuaXNNYXN0ZXJBZG1pbixcbiAgICAgIG11c3RDaGFuZ2VQYXNzd29yZDogdXNlci5tdXN0Q2hhbmdlUGFzc3dvcmRcbiAgICB9XG4gIH0pO1xufSk7XG5cbmFwcC5wb3N0KFwiL2FwaS9hdXRoL3VwZGF0ZS1wYXNzd29yZFwiLCAocmVxLCByZXMpID0+IHtcbiAgY29uc3QgeyB1c2VySWQsIGN1cnJlbnRQYXNzd29yZCwgbmV3UGFzc3dvcmQgfSA9IHJlcS5ib2R5O1xuICBjb25zdCB1c2VyID0gdXNlcnMuZmluZCh1ID0+IHUuaWQgPT09IHVzZXJJZCk7XG5cbiAgaWYgKCF1c2VyKSByZXR1cm4gcmVzLnN0YXR1cyg0MDQpLmpzb24oeyBlcnJvcjogXCJVc2VyIG5vdCBmb3VuZFwiIH0pO1xuICBpZiAodXNlci5wYXNzd29yZEhhc2ggIT09IGN1cnJlbnRQYXNzd29yZCkgcmV0dXJuIHJlcy5zdGF0dXMoNDAwKS5qc29uKHsgZXJyb3I6IFwiQ3VycmVudCBwYXNzd29yZCBpcyBpbmNvcnJlY3RcIiB9KTtcblxuICB1c2VyLnBhc3N3b3JkSGFzaCA9IG5ld1Bhc3N3b3JkO1xuICByZXMuanNvbih7IHN1Y2Nlc3M6IHRydWUsIG1lc3NhZ2U6IFwiUGFzc3dvcmQgdXBkYXRlZCBzdWNjZXNzZnVsbHlcIiB9KTtcbn0pO1xuXG5hcHAucG9zdChcIi9hcGkvYXV0aC9mb3Jnb3QtcGFzc3dvcmRcIiwgKHJlcSwgcmVzKSA9PiB7XG4gIGNvbnN0IHsgZW1haWwsIGRldmljZSwgbW9iaWxlLCBnZW9Mb2NhdGlvbiB9ID0gcmVxLmJvZHk7XG4gIGNvbnN0IHVzZXIgPSB1c2Vycy5maW5kKHUgPT4gdS5lbWFpbCA9PT0gZW1haWwpO1xuXG4gIGlmICghdXNlcikge1xuICAgIHJldHVybiByZXMuc3RhdHVzKDQwNCkuanNvbih7IGVycm9yOiBcIkVtYWlsIGFkZHJlc3Mgbm90IGZvdW5kIGluIHJlZ2lzdHJ5XCIgfSk7XG4gIH1cblxuICBsZXQgbWF0Y2hlcyA9IDA7XG4gIGlmICh1c2VyLmVtYWlsLnRvTG93ZXJDYXNlKCkgPT09IGVtYWlsLnRvTG93ZXJDYXNlKCkpIG1hdGNoZXMrKztcbiAgaWYgKHVzZXIuZGV2aWNlICYmIGRldmljZSAmJiB1c2VyLmRldmljZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGRldmljZS50b0xvd2VyQ2FzZSgpKSkgbWF0Y2hlcysrO1xuICBpZiAodXNlci5tb2JpbGUgJiYgbW9iaWxlICYmIHVzZXIubW9iaWxlID09PSBtb2JpbGUpIG1hdGNoZXMrKztcbiAgaWYgKHVzZXIuZ2VvTG9jYXRpb24gJiYgZ2VvTG9jYXRpb24gJiYgdXNlci5nZW9Mb2NhdGlvbi50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGdlb0xvY2F0aW9uLnRvTG93ZXJDYXNlKCkpKSBtYXRjaGVzKys7XG5cbiAgaWYgKG1hdGNoZXMgPCAzKSB7XG4gICAgcmV0dXJuIHJlcy5zdGF0dXMoNDAzKS5qc29uKHsgXG4gICAgICBlcnJvcjogYFZlcmlmaWNhdGlvbiBmYWlsZWQuIE9ubHkgbWF0Y2hlZCAke21hdGNoZXN9LzMgcmVxdWlyZWQgYXR0cmlidXRlcyAoRGV2aWNlLCBFbWFpbCwgTW9iaWxlLCBHZW8tbG9jYXRpb24pLmAgXG4gICAgfSk7XG4gIH1cblxuICBjb25zdCB0ZW1wQ29kZSA9IE1hdGgucmFuZG9tKCkudG9TdHJpbmcoMzYpLnN1YnN0cmluZygyLCAxMCkudG9VcHBlckNhc2UoKTtcbiAgdXNlci50ZW1wb3JhcnlDb2RlID0gdGVtcENvZGU7XG4gIHVzZXIudGVtcENvZGVFeHBpcmVzID0gRGF0ZS5ub3coKSArIDE1ICogNjAgKiAxMDAwO1xuICB1c2VyLm11c3RDaGFuZ2VQYXNzd29yZCA9IHRydWU7XG5cbiAgcmVzLmpzb24oe1xuICAgIHN1Y2Nlc3M6IHRydWUsXG4gICAgbWVzc2FnZTogYFZlcmlmaWNhdGlvbiBzdWNjZXNzZnVsICgke21hdGNoZXN9LzQgYXR0cmlidXRlcyBtYXRjaGVkKS4gVGVtcG9yYXJ5IDgtZGlnaXQgY29kZSBzZW50IHRvICR7ZW1haWx9YCxcbiAgICBzaW11bGF0ZWRFbWFpbENvZGU6IHRlbXBDb2RlXG4gIH0pO1xufSk7XG5cbmFwcC5wb3N0KFwiL2FwaS9hdXRoL3Jlc2V0LXBhc3N3b3JkXCIsIChyZXEsIHJlcykgPT4ge1xuICBjb25zdCB7IGVtYWlsLCB0ZW1wQ29kZSwgbmV3UGFzc3dvcmQgfSA9IHJlcS5ib2R5O1xuICBjb25zdCB1c2VyID0gdXNlcnMuZmluZCh1ID0+IHUuZW1haWwgPT09IGVtYWlsKTtcblxuICBpZiAoIXVzZXIgfHwgdXNlci50ZW1wb3JhcnlDb2RlICE9PSB0ZW1wQ29kZSkge1xuICAgIHJldHVybiByZXMuc3RhdHVzKDQwMCkuanNvbih7IGVycm9yOiBcIkludmFsaWQgdGVtcG9yYXJ5IGNvZGUgb3IgZW1haWxcIiB9KTtcbiAgfVxuXG4gIGlmICh1c2VyLnRlbXBDb2RlRXhwaXJlcyAmJiBEYXRlLm5vdygpID4gdXNlci50ZW1wQ29kZUV4cGlyZXMpIHtcbiAgICByZXR1cm4gcmVzLnN0YXR1cyg0MDApLmpzb24oeyBlcnJvcjogXCJUZW1wb3JhcnkgY29kZSBoYXMgZXhwaXJlZC5cIiB9KTtcbiAgfVxuXG4gIHVzZXIucGFzc3dvcmRIYXNoID0gbmV3UGFzc3dvcmQ7XG4gIHVzZXIudGVtcG9yYXJ5Q29kZSA9IHVuZGVmaW5lZDtcbiAgdXNlci50ZW1wQ29kZUV4cGlyZXMgPSB1bmRlZmluZWQ7XG4gIHVzZXIubXVzdENoYW5nZVBhc3N3b3JkID0gZmFsc2U7XG5cbiAgcmVzLmpzb24oeyBzdWNjZXNzOiB0cnVlLCBtZXNzYWdlOiBcIlBhc3N3b3JkIHVwZGF0ZWQgc3VjY2Vzc2Z1bGx5LiBZb3UgY2FuIG5vdyBsb2dpbi5cIiB9KTtcbn0pO1xuXG5hcHAucG9zdChcIi9hcGkvY2hhdC9jaGVjay1wcml2YWN5XCIsIGFzeW5jIChyZXEsIHJlcykgPT4ge1xuICB0cnkge1xuICAgIGNvbnN0IHsgbWVzc2FnZSB9ID0gcmVxLmJvZHk7XG4gICAgaWYgKCFtZXNzYWdlKSByZXR1cm4gcmVzLmpzb24oeyBjb250YWluc1BlcnNvbmFsRGV0YWlsczogZmFsc2UgfSk7XG5cbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFpLm1vZGVscy5nZW5lcmF0ZUNvbnRlbnQoe1xuICAgICAgbW9kZWw6IFwiZ2VtaW5pLTMuOC1mbGFzaFwiLFxuICAgICAgY29udGVudHM6IGBBbmFseXplIGlmIHRoZSBmb2xsb3dpbmcgY2hhdCBtZXNzYWdlIGNvbnRhaW5zIHNoYXJpbmcgb2YgcGVyc29uYWwgc2Vuc2l0aXZlIGRldGFpbHMgc3VjaCBhcyBhIG1vYmlsZSBwaG9uZSBudW1iZXIsIGVtYWlsIGFkZHJlc3MsIHBoeXNpY2FsIGFkZHJlc3MsIGNyZWRpdCBjYXJkLCBvciBwYXNzcG9ydCBudW1iZXIuIFJldHVybiBKU09OIHdpdGggZm9ybWF0IHtcImNvbnRhaW5zUGVyc29uYWxEZXRhaWxzXCI6IGJvb2xlYW4sIFwiZGV0ZWN0ZWRJdGVtXCI6IHN0cmluZ306XFxuXFxuXCIke21lc3NhZ2V9XCJgLFxuICAgICAgY29uZmlnOiB7XG4gICAgICAgIHJlc3BvbnNlTWltZVR5cGU6IFwiYXBwbGljYXRpb24vanNvblwiXG4gICAgICB9XG4gICAgfSk7XG5cbiAgICBjb25zdCByZXN1bHQgPSBKU09OLnBhcnNlKHJlc3BvbnNlLnRleHQgfHwgXCJ7fVwiKTtcbiAgICByZXMuanNvbihyZXN1bHQpO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBjb25zb2xlLmVycm9yKFwiR2VtaW5pIHByaXZhY3kgY2hlY2sgZXJyb3I6XCIsIGVycik7XG4gICAgcmVzLmpzb24oeyBjb250YWluc1BlcnNvbmFsRGV0YWlsczogZmFsc2UgfSk7XG4gIH1cbn0pO1xuXG5hcHAuZ2V0KFwiL2FwaS9hZG1pbi91c2Vyc1wiLCAocmVxLCByZXMpID0+IHtcbiAgcmVzLmpzb24oeyB1c2VycywgYXVkaXRMb2c6IHNoZWV0c0F1ZGl0TG9nLCB0aGVtZTogZ2xvYmFsVGhlbWUgfSk7XG59KTtcblxuYXBwLnBvc3QoXCIvYXBpL2FkbWluL3Byb21vdGVcIiwgKHJlcSwgcmVzKSA9PiB7XG4gIGNvbnN0IHsgdXNlcklkLCBtYWtlQWRtaW4gfSA9IHJlcS5ib2R5O1xuICBjb25zdCB0YXJnZXQgPSB1c2Vycy5maW5kKHUgPT4gdS5pZCA9PT0gdXNlcklkKTtcbiAgaWYgKCF0YXJnZXQpIHJldHVybiByZXMuc3RhdHVzKDQwNCkuanNvbih7IGVycm9yOiBcIlVzZXIgbm90IGZvdW5kXCIgfSk7XG5cbiAgdGFyZ2V0LmlzQWRtaW4gPSBtYWtlQWRtaW47XG4gIHJlcy5qc29uKHsgc3VjY2VzczogdHJ1ZSwgdXNlcnMgfSk7XG59KTtcblxuYXBwLnBvc3QoXCIvYXBpL2FkbWluL3RoZW1lXCIsIChyZXEsIHJlcykgPT4ge1xuICBjb25zdCB7IHRoZW1lTmFtZSwgbG9nb1VybCwgY2hhdEJhY2tncm91bmQsIHByaW1hcnlDb2xvciwgcG93ZXJlZEJ5LCBhYm91dFRleHQgfSA9IHJlcS5ib2R5O1xuICBpZiAodGhlbWVOYW1lKSBnbG9iYWxUaGVtZS50aGVtZU5hbWUgPSB0aGVtZU5hbWU7XG4gIGlmIChsb2dvVXJsICE9PSB1bmRlZmluZWQpIGdsb2JhbFRoZW1lLmxvZ29VcmwgPSBsb2dvVXJsO1xuICBpZiAoY2hhdEJhY2tncm91bmQpIGdsb2JhbFRoZW1lLmNoYXRCYWNrZ3JvdW5kID0gY2hhdEJhY2tncm91bmQ7XG4gIGlmIChwcmltYXJ5Q29sb3IpIGdsb2JhbFRoZW1lLnByaW1hcnlDb2xvciA9IHByaW1hcnlDb2xvcjtcbiAgaWYgKHBvd2VyZWRCeSAhPT0gdW5kZWZpbmVkKSBnbG9iYWxUaGVtZS5wb3dlcmVkQnkgPSBwb3dlcmVkQnk7XG4gIGlmIChhYm91dFRleHQgIT09IHVuZGVmaW5lZCkgZ2xvYmFsVGhlbWUuYWJvdXRUZXh0ID0gYWJvdXRUZXh0O1xuXG4gIHJlcy5qc29uKHsgc3VjY2VzczogdHJ1ZSwgdGhlbWU6IGdsb2JhbFRoZW1lIH0pO1xufSk7XG5cbmFwcC5nZXQoXCIvYXBpL2FsYnVtc1wiLCAocmVxLCByZXMpID0+IHtcbiAgcmVzLmpzb24oeyBhbGJ1bXMgfSk7XG59KTtcblxuYXBwLnBvc3QoXCIvYXBpL2FsYnVtc1wiLCAocmVxLCByZXMpID0+IHtcbiAgY29uc3QgeyBhdXRob3IsIGF1dGhvck5hbWUsIHRpdGxlLCBjYXB0aW9uLCBpbWFnZVVybCB9ID0gcmVxLmJvZHk7XG4gIGNvbnN0IG5ld0FsYnVtID0ge1xuICAgIGlkOiBgYWxidW0tJHtEYXRlLm5vdygpfWAsXG4gICAgYXV0aG9yOiBhdXRob3IgfHwgXCJ1c2VyXCIsXG4gICAgYXV0aG9yTmFtZTogYXV0aG9yTmFtZSB8fCBcIkFub255bW91c1wiLFxuICAgIHRpdGxlOiB0aXRsZSB8fCBcIk15IEFsYnVtXCIsXG4gICAgY2FwdGlvbjogY2FwdGlvbiB8fCBcIlwiLFxuICAgIGltYWdlVXJsOiBpbWFnZVVybCB8fCBcImh0dHBzOi8vaW1hZ2VzLnVuc3BsYXNoLmNvbS9waG90by0xNTE4NzcwNjYwNDM5LTQ2MzYxOTBhZjQ3NT93PTgwMCZhdXRvPWZvcm1hdCZmaXQ9Y3JvcCZxPTgwXCIsXG4gICAgbGlrZXM6IDAsXG4gICAgY29tbWVudHM6IFtdLFxuICAgIHRpbWVzdGFtcDogXCJKdXN0IG5vd1wiXG4gIH07XG4gIGFsYnVtcy51bnNoaWZ0KG5ld0FsYnVtKTtcbiAgcmVzLmpzb24oeyBzdWNjZXNzOiB0cnVlLCBhbGJ1bTogbmV3QWxidW0gfSk7XG59KTtcblxuYXBwLnBvc3QoXCIvYXBpL2FsYnVtcy86aWQvbGlrZVwiLCAocmVxLCByZXMpID0+IHtcbiAgY29uc3QgeyBpZCB9ID0gcmVxLnBhcmFtcztcbiAgY29uc3QgYWxidW0gPSBhbGJ1bXMuZmluZChhID0+IGEuaWQgPT09IGlkKTtcbiAgaWYgKGFsYnVtKSB7XG4gICAgYWxidW0ubGlrZXMgKz0gMTtcbiAgICByZXMuanNvbih7IHN1Y2Nlc3M6IHRydWUsIGxpa2VzOiBhbGJ1bS5saWtlcyB9KTtcbiAgfSBlbHNlIHtcbiAgICByZXMuc3RhdHVzKDQwNCkuanNvbih7IGVycm9yOiBcIkFsYnVtIG5vdCBmb3VuZFwiIH0pO1xuICB9XG59KTtcblxuYXBwLnBvc3QoXCIvYXBpL2FsYnVtcy86aWQvY29tbWVudFwiLCAocmVxLCByZXMpID0+IHtcbiAgY29uc3QgeyBpZCB9ID0gcmVxLnBhcmFtcztcbiAgY29uc3QgeyBhdXRob3IsIHRleHQgfSA9IHJlcS5ib2R5O1xuICBjb25zdCBhbGJ1bSA9IGFsYnVtcy5maW5kKGEgPT4gYS5pZCA9PT0gaWQpO1xuICBpZiAoYWxidW0pIHtcbiAgICBjb25zdCBjb21tZW50ID0geyBpZDogYGMtJHtEYXRlLm5vdygpfWAsIGF1dGhvcjogYXV0aG9yIHx8IFwiVXNlclwiLCB0ZXh0LCB0aW1lOiBcIkp1c3Qgbm93XCIgfTtcbiAgICBhbGJ1bS5jb21tZW50cy5wdXNoKGNvbW1lbnQpO1xuICAgIHJlcy5qc29uKHsgc3VjY2VzczogdHJ1ZSwgY29tbWVudHM6IGFsYnVtLmNvbW1lbnRzIH0pO1xuICB9IGVsc2Uge1xuICAgIHJlcy5zdGF0dXMoNDA0KS5qc29uKHsgZXJyb3I6IFwiQWxidW0gbm90IGZvdW5kXCIgfSk7XG4gIH1cbn0pO1xuXG4vLyBFeHBvcnQgZGVmYXVsdCBhcHAgZm9yIFZlcmNlbCBTZXJ2ZXJsZXNzIEZ1bmN0aW9uc1xuZXhwb3J0IGRlZmF1bHQgYXBwO1xuIl0sIm1hcHBpbmdzIjoiQUFBQTtBQUFBO0FBQUE7QUFBQTtBQUtBLE9BQU8sYUFBYTtBQUNwQixPQUFPLFVBQVU7QUFDakIsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUyxtQkFBbUI7QUFFNUIsSUFBSTtBQUNGLFFBQU0sU0FBUyxNQUFNLE9BQU8sUUFBUTtBQUNwQyxTQUFPLFFBQVEsT0FBTztBQUN4QixTQUFTLEdBQUc7QUFFWjtBQUVBLE1BQU0sYUFBYSxjQUFjLFlBQVksR0FBRztBQUNoRCxNQUFNLFlBQVksS0FBSyxRQUFRLFVBQVU7QUEwQnpDLElBQUksUUFBc0I7QUFBQSxFQUN4QjtBQUFBLElBQ0UsSUFBSTtBQUFBLElBQ0osVUFBVTtBQUFBLElBQ1YsT0FBTztBQUFBLElBQ1AsUUFBUTtBQUFBLElBQ1IsUUFBUTtBQUFBLElBQ1IsYUFBYTtBQUFBLElBQ2IsY0FBYztBQUFBLElBQ2QsU0FBUztBQUFBLElBQ1QsZUFBZTtBQUFBLEVBQ2pCO0FBQUEsRUFDQTtBQUFBLElBQ0UsSUFBSTtBQUFBLElBQ0osVUFBVTtBQUFBLElBQ1YsT0FBTztBQUFBLElBQ1AsUUFBUTtBQUFBLElBQ1IsUUFBUTtBQUFBLElBQ1IsYUFBYTtBQUFBLElBQ2IsY0FBYztBQUFBLElBQ2QsU0FBUztBQUFBLElBQ1QsZUFBZTtBQUFBLEVBQ2pCO0FBQUEsRUFDQTtBQUFBLElBQ0UsSUFBSTtBQUFBLElBQ0osVUFBVTtBQUFBLElBQ1YsT0FBTztBQUFBLElBQ1AsUUFBUTtBQUFBLElBQ1IsUUFBUTtBQUFBLElBQ1IsYUFBYTtBQUFBLElBQ2IsY0FBYztBQUFBLElBQ2QsU0FBUztBQUFBLElBQ1QsZUFBZTtBQUFBLEVBQ2pCO0FBQ0Y7QUFFQSxJQUFJLGNBQTBCO0FBQUEsRUFDNUIsV0FBVztBQUFBLEVBQ1gsU0FBUztBQUFBLEVBQ1QsZ0JBQWdCO0FBQUEsRUFDaEIsY0FBYztBQUFBLEVBQ2QsV0FBVztBQUFBLEVBQ1gsV0FBVztBQUNiO0FBRUEsSUFBSSxTQUFTO0FBQUEsRUFDWDtBQUFBLElBQ0UsSUFBSTtBQUFBLElBQ0osUUFBUTtBQUFBLElBQ1IsWUFBWTtBQUFBLElBQ1osT0FBTztBQUFBLElBQ1AsU0FBUztBQUFBLElBQ1QsVUFBVTtBQUFBLElBQ1YsT0FBTztBQUFBLElBQ1AsVUFBVTtBQUFBLE1BQ1IsRUFBRSxJQUFJLE1BQU0sUUFBUSxXQUFXLE1BQU0sK0JBQStCLE1BQU0sU0FBUztBQUFBLElBQ3JGO0FBQUEsSUFDQSxXQUFXO0FBQUEsRUFDYjtBQUNGO0FBRUEsSUFBSSxpQkFRQztBQUFBLEVBQ0g7QUFBQSxJQUNFLFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxJQUNsQyxPQUFPO0FBQUEsSUFDUCxVQUFVO0FBQUEsSUFDVixPQUFPO0FBQUEsSUFDUCxRQUFRO0FBQUEsSUFDUixRQUFRO0FBQUEsSUFDUixhQUFhO0FBQUEsRUFDZjtBQUNGO0FBRUEsTUFBTSxNQUFNLFFBQVE7QUFDcEIsSUFBSSxJQUFJLFFBQVEsS0FBSyxFQUFFLE9BQU8sT0FBTyxDQUFDLENBQUM7QUFDdkMsSUFBSSxJQUFJLFFBQVEsV0FBVyxFQUFFLE9BQU8sUUFBUSxVQUFVLEtBQUssQ0FBQyxDQUFDO0FBRTdELE1BQU0sS0FBSyxJQUFJLFlBQVk7QUFBQSxFQUN6QixRQUFRLFFBQVEsSUFBSTtBQUFBLEVBQ3BCLGFBQWE7QUFBQSxJQUNYLFNBQVM7QUFBQSxNQUNQLGNBQWM7QUFBQSxJQUNoQjtBQUFBLEVBQ0Y7QUFDRixDQUFDO0FBR0QsSUFBSSxLQUFLLHNCQUFzQixDQUFDLEtBQUssUUFBUTtBQUMzQyxRQUFNLFlBQVksSUFBSSxLQUFLLFlBQVksSUFBSSxLQUFLO0FBQ2hELFFBQU0sU0FBUyxJQUFJLEtBQUssU0FBUyxJQUFJLEtBQUs7QUFDMUMsUUFBTSxTQUFTLElBQUksS0FBSztBQUN4QixRQUFNLFNBQVMsSUFBSSxLQUFLO0FBQ3hCLFFBQU0sY0FBYyxJQUFJLEtBQUs7QUFDN0IsUUFBTSxXQUFXLElBQUksS0FBSztBQUUxQixNQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxVQUFVO0FBQ3BDLFdBQU8sSUFBSSxPQUFPLEdBQUcsRUFBRSxLQUFLLEVBQUUsT0FBTyw0Q0FBNEMsQ0FBQztBQUFBLEVBQ3BGO0FBRUEsTUFBSSxNQUFNLEtBQUssT0FBSyxFQUFFLFNBQVMsWUFBWSxNQUFNLFNBQVMsWUFBWSxLQUFLLEVBQUUsTUFBTSxZQUFZLE1BQU0sTUFBTSxZQUFZLENBQUMsR0FBRztBQUN6SCxXQUFPLElBQUksT0FBTyxHQUFHLEVBQUUsS0FBSyxFQUFFLE9BQU8sbUNBQW1DLENBQUM7QUFBQSxFQUMzRTtBQUVBLFFBQU0sVUFBc0I7QUFBQSxJQUMxQixJQUFJLFFBQVEsS0FBSyxJQUFJLENBQUM7QUFBQSxJQUN0QjtBQUFBLElBQ0E7QUFBQSxJQUNBLFFBQVEsVUFBVTtBQUFBLElBQ2xCLFFBQVEsVUFBVTtBQUFBLElBQ2xCLGFBQWEsZUFBZTtBQUFBLElBQzVCLGNBQWM7QUFBQSxJQUNkLFNBQVM7QUFBQSxJQUNULGVBQWU7QUFBQSxFQUNqQjtBQUVBLFFBQU0sS0FBSyxPQUFPO0FBRWxCLGlCQUFlLEtBQUs7QUFBQSxJQUNsQixZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsSUFDbEMsT0FBTztBQUFBLElBQ1AsVUFBVSxRQUFRO0FBQUEsSUFDbEIsT0FBTyxRQUFRO0FBQUEsSUFDZixRQUFRLFFBQVE7QUFBQSxJQUNoQixRQUFRLFFBQVE7QUFBQSxJQUNoQixhQUFhLFFBQVE7QUFBQSxFQUN2QixDQUFDO0FBRUQsTUFBSSxLQUFLLEVBQUUsU0FBUyxNQUFNLE1BQU0sRUFBRSxJQUFJLFFBQVEsSUFBSSxVQUFVLFFBQVEsVUFBVSxPQUFPLFFBQVEsT0FBTyxTQUFTLFFBQVEsU0FBUyxlQUFlLFFBQVEsY0FBYyxFQUFFLENBQUM7QUFDeEssQ0FBQztBQUVELElBQUksS0FBSyxtQkFBbUIsQ0FBQyxLQUFLLFFBQVE7QUFDeEMsUUFBTSxtQkFBbUIsSUFBSSxLQUFLLG1CQUFtQixJQUFJLEtBQUs7QUFDOUQsUUFBTSxXQUFXLElBQUksS0FBSztBQUMxQixNQUFJLE9BQU8sTUFBTSxLQUFLLE9BQUssRUFBRSxTQUFTLFlBQVksTUFBTSxnQkFBZ0IsWUFBWSxLQUFLLEVBQUUsTUFBTSxZQUFZLE1BQU0sZ0JBQWdCLFlBQVksQ0FBQztBQUVoSixNQUFJLENBQUMsTUFBTTtBQUNULFFBQUksZ0JBQWdCLFlBQVksRUFBRSxXQUFXLEtBQUssR0FBRztBQUNuRCxhQUFPO0FBQUEsUUFDTCxJQUFJLFFBQVEsS0FBSyxJQUFJLENBQUM7QUFBQSxRQUN0QixVQUFVO0FBQUEsUUFDVixPQUFPLEdBQUcsZ0JBQWdCLFlBQVksQ0FBQztBQUFBLFFBQ3ZDLFFBQVE7QUFBQSxRQUNSLFFBQVE7QUFBQSxRQUNSLGFBQWE7QUFBQSxRQUNiLGNBQWM7QUFBQSxRQUNkLFNBQVM7QUFBQSxRQUNULGVBQWU7QUFBQSxNQUNqQjtBQUNBLFlBQU0sS0FBSyxJQUFJO0FBQUEsSUFDakIsV0FBVyxnQkFBZ0IsWUFBWSxFQUFFLFdBQVcsSUFBSSxHQUFHO0FBQ3pELGFBQU87QUFBQSxRQUNMLElBQUksUUFBUSxLQUFLLElBQUksQ0FBQztBQUFBLFFBQ3RCLFVBQVU7QUFBQSxRQUNWLE9BQU8sR0FBRyxnQkFBZ0IsWUFBWSxDQUFDO0FBQUEsUUFDdkMsUUFBUTtBQUFBLFFBQ1IsUUFBUTtBQUFBLFFBQ1IsYUFBYTtBQUFBLFFBQ2IsY0FBYztBQUFBLFFBQ2QsU0FBUztBQUFBLFFBQ1QsZUFBZTtBQUFBLE1BQ2pCO0FBQ0EsWUFBTSxLQUFLLElBQUk7QUFBQSxJQUNqQjtBQUFBLEVBQ0Y7QUFFQSxNQUFJLENBQUMsUUFBUSxLQUFLLGlCQUFpQixVQUFVO0FBQzNDLFdBQU8sSUFBSSxPQUFPLEdBQUcsRUFBRSxLQUFLLEVBQUUsT0FBTyxvREFBb0QsQ0FBQztBQUFBLEVBQzVGO0FBRUEsTUFBSSxLQUFLLFNBQVMsWUFBWSxFQUFFLFdBQVcsS0FBSyxHQUFHO0FBQ2pELFNBQUssVUFBVTtBQUNmLFNBQUssZ0JBQWdCO0FBQUEsRUFDdkIsV0FBVyxLQUFLLFNBQVMsWUFBWSxFQUFFLFdBQVcsSUFBSSxHQUFHO0FBQ3ZELFNBQUssVUFBVTtBQUNmLFNBQUssZ0JBQWdCO0FBQUEsRUFDdkI7QUFFQSxNQUFJLEtBQUs7QUFBQSxJQUNQLFNBQVM7QUFBQSxJQUNULE1BQU07QUFBQSxNQUNKLElBQUksS0FBSztBQUFBLE1BQ1QsVUFBVSxLQUFLO0FBQUEsTUFDZixPQUFPLEtBQUs7QUFBQSxNQUNaLFFBQVEsS0FBSztBQUFBLE1BQ2IsUUFBUSxLQUFLO0FBQUEsTUFDYixhQUFhLEtBQUs7QUFBQSxNQUNsQixTQUFTLEtBQUs7QUFBQSxNQUNkLGVBQWUsS0FBSztBQUFBLE1BQ3BCLG9CQUFvQixLQUFLO0FBQUEsSUFDM0I7QUFBQSxFQUNGLENBQUM7QUFDSCxDQUFDO0FBRUQsSUFBSSxLQUFLLDZCQUE2QixDQUFDLEtBQUssUUFBUTtBQUNsRCxRQUFNLEVBQUUsUUFBUSxpQkFBaUIsWUFBWSxJQUFJLElBQUk7QUFDckQsUUFBTSxPQUFPLE1BQU0sS0FBSyxPQUFLLEVBQUUsT0FBTyxNQUFNO0FBRTVDLE1BQUksQ0FBQyxLQUFNLFFBQU8sSUFBSSxPQUFPLEdBQUcsRUFBRSxLQUFLLEVBQUUsT0FBTyxpQkFBaUIsQ0FBQztBQUNsRSxNQUFJLEtBQUssaUJBQWlCLGdCQUFpQixRQUFPLElBQUksT0FBTyxHQUFHLEVBQUUsS0FBSyxFQUFFLE9BQU8sZ0NBQWdDLENBQUM7QUFFakgsT0FBSyxlQUFlO0FBQ3BCLE1BQUksS0FBSyxFQUFFLFNBQVMsTUFBTSxTQUFTLGdDQUFnQyxDQUFDO0FBQ3RFLENBQUM7QUFFRCxJQUFJLEtBQUssNkJBQTZCLENBQUMsS0FBSyxRQUFRO0FBQ2xELFFBQU0sRUFBRSxPQUFPLFFBQVEsUUFBUSxZQUFZLElBQUksSUFBSTtBQUNuRCxRQUFNLE9BQU8sTUFBTSxLQUFLLE9BQUssRUFBRSxVQUFVLEtBQUs7QUFFOUMsTUFBSSxDQUFDLE1BQU07QUFDVCxXQUFPLElBQUksT0FBTyxHQUFHLEVBQUUsS0FBSyxFQUFFLE9BQU8sc0NBQXNDLENBQUM7QUFBQSxFQUM5RTtBQUVBLE1BQUksVUFBVTtBQUNkLE1BQUksS0FBSyxNQUFNLFlBQVksTUFBTSxNQUFNLFlBQVksRUFBRztBQUN0RCxNQUFJLEtBQUssVUFBVSxVQUFVLEtBQUssT0FBTyxZQUFZLEVBQUUsU0FBUyxPQUFPLFlBQVksQ0FBQyxFQUFHO0FBQ3ZGLE1BQUksS0FBSyxVQUFVLFVBQVUsS0FBSyxXQUFXLE9BQVE7QUFDckQsTUFBSSxLQUFLLGVBQWUsZUFBZSxLQUFLLFlBQVksWUFBWSxFQUFFLFNBQVMsWUFBWSxZQUFZLENBQUMsRUFBRztBQUUzRyxNQUFJLFVBQVUsR0FBRztBQUNmLFdBQU8sSUFBSSxPQUFPLEdBQUcsRUFBRSxLQUFLO0FBQUEsTUFDMUIsT0FBTyxxQ0FBcUMsT0FBTztBQUFBLElBQ3JELENBQUM7QUFBQSxFQUNIO0FBRUEsUUFBTSxXQUFXLEtBQUssT0FBTyxFQUFFLFNBQVMsRUFBRSxFQUFFLFVBQVUsR0FBRyxFQUFFLEVBQUUsWUFBWTtBQUN6RSxPQUFLLGdCQUFnQjtBQUNyQixPQUFLLGtCQUFrQixLQUFLLElBQUksSUFBSSxLQUFLLEtBQUs7QUFDOUMsT0FBSyxxQkFBcUI7QUFFMUIsTUFBSSxLQUFLO0FBQUEsSUFDUCxTQUFTO0FBQUEsSUFDVCxTQUFTLDRCQUE0QixPQUFPLDBEQUEwRCxLQUFLO0FBQUEsSUFDM0csb0JBQW9CO0FBQUEsRUFDdEIsQ0FBQztBQUNILENBQUM7QUFFRCxJQUFJLEtBQUssNEJBQTRCLENBQUMsS0FBSyxRQUFRO0FBQ2pELFFBQU0sRUFBRSxPQUFPLFVBQVUsWUFBWSxJQUFJLElBQUk7QUFDN0MsUUFBTSxPQUFPLE1BQU0sS0FBSyxPQUFLLEVBQUUsVUFBVSxLQUFLO0FBRTlDLE1BQUksQ0FBQyxRQUFRLEtBQUssa0JBQWtCLFVBQVU7QUFDNUMsV0FBTyxJQUFJLE9BQU8sR0FBRyxFQUFFLEtBQUssRUFBRSxPQUFPLGtDQUFrQyxDQUFDO0FBQUEsRUFDMUU7QUFFQSxNQUFJLEtBQUssbUJBQW1CLEtBQUssSUFBSSxJQUFJLEtBQUssaUJBQWlCO0FBQzdELFdBQU8sSUFBSSxPQUFPLEdBQUcsRUFBRSxLQUFLLEVBQUUsT0FBTyw4QkFBOEIsQ0FBQztBQUFBLEVBQ3RFO0FBRUEsT0FBSyxlQUFlO0FBQ3BCLE9BQUssZ0JBQWdCO0FBQ3JCLE9BQUssa0JBQWtCO0FBQ3ZCLE9BQUsscUJBQXFCO0FBRTFCLE1BQUksS0FBSyxFQUFFLFNBQVMsTUFBTSxTQUFTLG9EQUFvRCxDQUFDO0FBQzFGLENBQUM7QUFFRCxJQUFJLEtBQUssMkJBQTJCLE9BQU8sS0FBSyxRQUFRO0FBQ3RELE1BQUk7QUFDRixVQUFNLEVBQUUsUUFBUSxJQUFJLElBQUk7QUFDeEIsUUFBSSxDQUFDLFFBQVMsUUFBTyxJQUFJLEtBQUssRUFBRSx5QkFBeUIsTUFBTSxDQUFDO0FBRWhFLFVBQU0sV0FBVyxNQUFNLEdBQUcsT0FBTyxnQkFBZ0I7QUFBQSxNQUMvQyxPQUFPO0FBQUEsTUFDUCxVQUFVO0FBQUE7QUFBQSxHQUFtUixPQUFPO0FBQUEsTUFDcFMsUUFBUTtBQUFBLFFBQ04sa0JBQWtCO0FBQUEsTUFDcEI7QUFBQSxJQUNGLENBQUM7QUFFRCxVQUFNLFNBQVMsS0FBSyxNQUFNLFNBQVMsUUFBUSxJQUFJO0FBQy9DLFFBQUksS0FBSyxNQUFNO0FBQUEsRUFDakIsU0FBUyxLQUFLO0FBQ1osWUFBUSxNQUFNLCtCQUErQixHQUFHO0FBQ2hELFFBQUksS0FBSyxFQUFFLHlCQUF5QixNQUFNLENBQUM7QUFBQSxFQUM3QztBQUNGLENBQUM7QUFFRCxJQUFJLElBQUksb0JBQW9CLENBQUMsS0FBSyxRQUFRO0FBQ3hDLE1BQUksS0FBSyxFQUFFLE9BQU8sVUFBVSxnQkFBZ0IsT0FBTyxZQUFZLENBQUM7QUFDbEUsQ0FBQztBQUVELElBQUksS0FBSyxzQkFBc0IsQ0FBQyxLQUFLLFFBQVE7QUFDM0MsUUFBTSxFQUFFLFFBQVEsVUFBVSxJQUFJLElBQUk7QUFDbEMsUUFBTSxTQUFTLE1BQU0sS0FBSyxPQUFLLEVBQUUsT0FBTyxNQUFNO0FBQzlDLE1BQUksQ0FBQyxPQUFRLFFBQU8sSUFBSSxPQUFPLEdBQUcsRUFBRSxLQUFLLEVBQUUsT0FBTyxpQkFBaUIsQ0FBQztBQUVwRSxTQUFPLFVBQVU7QUFDakIsTUFBSSxLQUFLLEVBQUUsU0FBUyxNQUFNLE1BQU0sQ0FBQztBQUNuQyxDQUFDO0FBRUQsSUFBSSxLQUFLLG9CQUFvQixDQUFDLEtBQUssUUFBUTtBQUN6QyxRQUFNLEVBQUUsV0FBVyxTQUFTLGdCQUFnQixjQUFjLFdBQVcsVUFBVSxJQUFJLElBQUk7QUFDdkYsTUFBSSxVQUFXLGFBQVksWUFBWTtBQUN2QyxNQUFJLFlBQVksT0FBVyxhQUFZLFVBQVU7QUFDakQsTUFBSSxlQUFnQixhQUFZLGlCQUFpQjtBQUNqRCxNQUFJLGFBQWMsYUFBWSxlQUFlO0FBQzdDLE1BQUksY0FBYyxPQUFXLGFBQVksWUFBWTtBQUNyRCxNQUFJLGNBQWMsT0FBVyxhQUFZLFlBQVk7QUFFckQsTUFBSSxLQUFLLEVBQUUsU0FBUyxNQUFNLE9BQU8sWUFBWSxDQUFDO0FBQ2hELENBQUM7QUFFRCxJQUFJLElBQUksZUFBZSxDQUFDLEtBQUssUUFBUTtBQUNuQyxNQUFJLEtBQUssRUFBRSxPQUFPLENBQUM7QUFDckIsQ0FBQztBQUVELElBQUksS0FBSyxlQUFlLENBQUMsS0FBSyxRQUFRO0FBQ3BDLFFBQU0sRUFBRSxRQUFRLFlBQVksT0FBTyxTQUFTLFNBQVMsSUFBSSxJQUFJO0FBQzdELFFBQU0sV0FBVztBQUFBLElBQ2YsSUFBSSxTQUFTLEtBQUssSUFBSSxDQUFDO0FBQUEsSUFDdkIsUUFBUSxVQUFVO0FBQUEsSUFDbEIsWUFBWSxjQUFjO0FBQUEsSUFDMUIsT0FBTyxTQUFTO0FBQUEsSUFDaEIsU0FBUyxXQUFXO0FBQUEsSUFDcEIsVUFBVSxZQUFZO0FBQUEsSUFDdEIsT0FBTztBQUFBLElBQ1AsVUFBVSxDQUFDO0FBQUEsSUFDWCxXQUFXO0FBQUEsRUFDYjtBQUNBLFNBQU8sUUFBUSxRQUFRO0FBQ3ZCLE1BQUksS0FBSyxFQUFFLFNBQVMsTUFBTSxPQUFPLFNBQVMsQ0FBQztBQUM3QyxDQUFDO0FBRUQsSUFBSSxLQUFLLHdCQUF3QixDQUFDLEtBQUssUUFBUTtBQUM3QyxRQUFNLEVBQUUsR0FBRyxJQUFJLElBQUk7QUFDbkIsUUFBTSxRQUFRLE9BQU8sS0FBSyxPQUFLLEVBQUUsT0FBTyxFQUFFO0FBQzFDLE1BQUksT0FBTztBQUNULFVBQU0sU0FBUztBQUNmLFFBQUksS0FBSyxFQUFFLFNBQVMsTUFBTSxPQUFPLE1BQU0sTUFBTSxDQUFDO0FBQUEsRUFDaEQsT0FBTztBQUNMLFFBQUksT0FBTyxHQUFHLEVBQUUsS0FBSyxFQUFFLE9BQU8sa0JBQWtCLENBQUM7QUFBQSxFQUNuRDtBQUNGLENBQUM7QUFFRCxJQUFJLEtBQUssMkJBQTJCLENBQUMsS0FBSyxRQUFRO0FBQ2hELFFBQU0sRUFBRSxHQUFHLElBQUksSUFBSTtBQUNuQixRQUFNLEVBQUUsUUFBUSxLQUFLLElBQUksSUFBSTtBQUM3QixRQUFNLFFBQVEsT0FBTyxLQUFLLE9BQUssRUFBRSxPQUFPLEVBQUU7QUFDMUMsTUFBSSxPQUFPO0FBQ1QsVUFBTSxVQUFVLEVBQUUsSUFBSSxLQUFLLEtBQUssSUFBSSxDQUFDLElBQUksUUFBUSxVQUFVLFFBQVEsTUFBTSxNQUFNLFdBQVc7QUFDMUYsVUFBTSxTQUFTLEtBQUssT0FBTztBQUMzQixRQUFJLEtBQUssRUFBRSxTQUFTLE1BQU0sVUFBVSxNQUFNLFNBQVMsQ0FBQztBQUFBLEVBQ3RELE9BQU87QUFDTCxRQUFJLE9BQU8sR0FBRyxFQUFFLEtBQUssRUFBRSxPQUFPLGtCQUFrQixDQUFDO0FBQUEsRUFDbkQ7QUFDRixDQUFDO0FBR0QsZUFBZTsiLCJuYW1lcyI6W119